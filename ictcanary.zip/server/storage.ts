import { eq, desc, asc, and, sql } from "drizzle-orm";
import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "@shared/schema";
import type {
  User,
  InsertUser,
  Student,
  InsertStudent,
  Teacher,
  InsertTeacher,
  Picture,
  InsertPicture,
  Game,
  InsertGame,
  Message,
  InsertMessage,
  Announcement,
  InsertAnnouncement,
  Story,
  InsertStory,
  Like,
  InsertLike,
  Comment,
  InsertComment,
  Share,
  InsertShare,
  StoryReaction,
  InsertStoryReaction,
  StoryView,
  InsertStoryView,
  HiddenPost,
  InsertHiddenPost,
  ReportedPost,
  InsertReportedPost,
  Settings,
  InsertSettings,
  DirectMessage,
  InsertDirectMessage,
  AnonymousMessage,
  InsertAnonymousMessage,
  AnonymousMessageReaction,
  InsertAnonymousMessageReaction,
  AnonymousMessageComment,
  InsertAnonymousMessageComment,
} from "@shared/schema";

const sqlite = new Database("database.db");
const db = drizzle(sqlite, { schema });

const SCHEMA_VERSION = 14;

function initializeDatabase() {
  const addColumnIfNotExists = (table: string, column: string, type: string) => {
    const columns = sqlite.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
    const columnExists = columns.some(col => col.name === column);
    if (!columnExists) {
      sqlite.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`).run();
    }
  };

  const tableExists = (table: string): boolean => {
    const result = sqlite.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).get(table);
    return !!result;
  };

  let currentVersion = 0;
  try {
    const result = sqlite.prepare("PRAGMA user_version").get() as { user_version: number };
    currentVersion = result.user_version;
  } catch (e) {
    currentVersion = 0;
  }

  const isLegacyDatabase = currentVersion === 0 && tableExists("pictures");

  if (currentVersion === 0 && !isLegacyDatabase) {
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        google_id TEXT UNIQUE,
        name TEXT NOT NULL,
        email TEXT,
        role TEXT NOT NULL DEFAULT 'user',
        avatar TEXT
      );

      CREATE TABLE IF NOT EXISTS students (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        grade TEXT NOT NULL,
        image TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS teachers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        subject TEXT NOT NULL,
        image TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS pictures (
        id TEXT PRIMARY KEY,
        file_path TEXT NOT NULL,
        file_name TEXT NOT NULL,
        caption TEXT NOT NULL,
        author TEXT NOT NULL,
        author_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS games (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        logo_path TEXT NOT NULL,
        logo_name TEXT NOT NULL,
        description TEXT NOT NULL,
        game_url TEXT NOT NULL,
        game_orientation TEXT NOT NULL DEFAULT 'both',
        author TEXT NOT NULL,
        author_id TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        sender_id TEXT NOT NULL,
        sender_name TEXT NOT NULL,
        content TEXT,
        file_path TEXT,
        file_name TEXT,
        file_type TEXT,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS announcements (
        id TEXT PRIMARY KEY,
        text TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS stories (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        user_avatar TEXT,
        file_path TEXT NOT NULL,
        file_name TEXT NOT NULL,
        created_at INTEGER NOT NULL,
        expires_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS likes (
        id TEXT PRIMARY KEY,
        post_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        reaction TEXT NOT NULL DEFAULT 'like',
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY,
        post_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS shares (
        id TEXT PRIMARY KEY,
        post_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS story_reactions (
        id TEXT PRIMARY KEY,
        story_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        reaction TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS story_views (
        id TEXT PRIMARY KEY,
        story_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        user_avatar TEXT,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS hidden_posts (
        id TEXT PRIMARY KEY,
        post_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS reported_posts (
        id TEXT PRIMARY KEY,
        post_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS settings (
        id TEXT PRIMARY KEY,
        favicon_path TEXT,
        site_title TEXT NOT NULL DEFAULT 'ICT Canary',
        site_description TEXT NOT NULL DEFAULT 'A futuristic pixel-style platform for ICT Canary.',
        login_message TEXT NOT NULL DEFAULT 'Access the futuristic portal',
        game_orientation TEXT NOT NULL DEFAULT 'both',
        post_approval_required INTEGER NOT NULL DEFAULT 1,
        updated_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS direct_messages (
        id TEXT PRIMARY KEY,
        sender_id TEXT NOT NULL,
        sender_name TEXT NOT NULL,
        sender_avatar TEXT,
        receiver_id TEXT NOT NULL,
        receiver_name TEXT NOT NULL,
        receiver_avatar TEXT,
        content TEXT,
        file_path TEXT,
        file_name TEXT,
        file_type TEXT,
        is_read INTEGER NOT NULL DEFAULT 0,
        timestamp INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS anonymous_messages (
        id TEXT PRIMARY KEY,
        content TEXT NOT NULL,
        author_id TEXT NOT NULL,
        author_name TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS anonymous_message_reactions (
        id TEXT PRIMARY KEY,
        message_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        reaction TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS anonymous_message_comments (
        id TEXT PRIMARY KEY,
        message_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at INTEGER NOT NULL
      );

      PRAGMA user_version = ${SCHEMA_VERSION};
    `);
    console.log(`Database initialized with schema version ${SCHEMA_VERSION}`);
  } else if (currentVersion > 0 && currentVersion < SCHEMA_VERSION) {
    console.log(`Migrating database from version ${currentVersion} to ${SCHEMA_VERSION}...`);
    
    try {
      sqlite.exec('BEGIN TRANSACTION');
      
      const pictureColumns = sqlite.prepare(`PRAGMA table_info(pictures)`).all() as Array<{ name: string }>;
      const messageColumns = sqlite.prepare(`PRAGMA table_info(messages)`).all() as Array<{ name: string }>;
      
      const hasUrlColumn = pictureColumns.some(col => col.name === 'url');
      const hasSenderColumn = messageColumns.some(col => col.name === 'sender');
      
      addColumnIfNotExists("pictures", "file_path", "TEXT");
      addColumnIfNotExists("pictures", "file_name", "TEXT");
      addColumnIfNotExists("pictures", "author_id", "TEXT");
      
      if (hasUrlColumn) {
        sqlite.exec(`UPDATE pictures SET file_path = url WHERE file_path IS NULL;`);
      } else {
        sqlite.exec(`UPDATE pictures SET file_path = 'uploads/pictures/legacy.jpg' WHERE file_path IS NULL;`);
      }
      sqlite.exec(`
        UPDATE pictures SET file_name = 'legacy-image.jpg' WHERE file_name IS NULL;
        UPDATE pictures SET author_id = 'legacy' WHERE author_id IS NULL;
      `);

      if (!tableExists("games")) {
        sqlite.exec(`
          CREATE TABLE games (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            logo_path TEXT NOT NULL,
            logo_name TEXT NOT NULL,
            description TEXT NOT NULL,
            game_url TEXT NOT NULL,
            game_orientation TEXT NOT NULL DEFAULT 'both',
            author TEXT NOT NULL,
            author_id TEXT NOT NULL,
            timestamp INTEGER NOT NULL
          );
        `);
      }
      addColumnIfNotExists("games", "game_orientation", "TEXT NOT NULL DEFAULT 'both'");

      addColumnIfNotExists("messages", "sender_id", "TEXT");
      addColumnIfNotExists("messages", "sender_name", "TEXT");
      addColumnIfNotExists("messages", "file_path", "TEXT");
      addColumnIfNotExists("messages", "file_name", "TEXT");
      addColumnIfNotExists("messages", "file_type", "TEXT");
      
      sqlite.exec(`UPDATE messages SET sender_id = 'legacy' WHERE sender_id IS NULL;`);
      if (hasSenderColumn) {
        sqlite.exec(`UPDATE messages SET sender_name = sender WHERE sender_name IS NULL;`);
      } else {
        sqlite.exec(`UPDATE messages SET sender_name = 'Unknown' WHERE sender_name IS NULL;`);
      }

      if (!tableExists("stories")) {
        sqlite.exec(`
          CREATE TABLE stories (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            user_avatar TEXT,
            file_path TEXT NOT NULL,
            file_name TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            expires_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("likes")) {
        sqlite.exec(`
          CREATE TABLE likes (
            id TEXT PRIMARY KEY,
            post_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            reaction TEXT NOT NULL DEFAULT 'like',
            created_at INTEGER NOT NULL
          );
        `);
      }
      addColumnIfNotExists("likes", "reaction", "TEXT NOT NULL DEFAULT 'like'");

      if (!tableExists("comments")) {
        sqlite.exec(`
          CREATE TABLE comments (
            id TEXT PRIMARY KEY,
            post_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("shares")) {
        sqlite.exec(`
          CREATE TABLE shares (
            id TEXT PRIMARY KEY,
            post_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            user_id TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("story_reactions")) {
        sqlite.exec(`
          CREATE TABLE story_reactions (
            id TEXT PRIMARY KEY,
            story_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            reaction TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("settings")) {
        sqlite.exec(`
          CREATE TABLE settings (
            id TEXT PRIMARY KEY,
            favicon_path TEXT,
            site_title TEXT NOT NULL DEFAULT 'ICT Canary',
            site_description TEXT NOT NULL DEFAULT 'A futuristic pixel-style platform for ICT Canary.',
            login_message TEXT NOT NULL DEFAULT 'Access the futuristic portal',
            game_orientation TEXT NOT NULL DEFAULT 'both',
            post_approval_required INTEGER NOT NULL DEFAULT 1,
            updated_at INTEGER NOT NULL
          );
        `);
      }
      addColumnIfNotExists("settings", "game_orientation", "TEXT NOT NULL DEFAULT 'both'");
      addColumnIfNotExists("settings", "post_approval_required", "INTEGER NOT NULL DEFAULT 1");

      if (!tableExists("direct_messages")) {
        sqlite.exec(`
          CREATE TABLE direct_messages (
            id TEXT PRIMARY KEY,
            sender_id TEXT NOT NULL,
            sender_name TEXT NOT NULL,
            sender_avatar TEXT,
            receiver_id TEXT NOT NULL,
            receiver_name TEXT NOT NULL,
            receiver_avatar TEXT,
            content TEXT,
            file_path TEXT,
            file_name TEXT,
            file_type TEXT,
            is_read INTEGER NOT NULL DEFAULT 0,
            timestamp INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("story_views")) {
        sqlite.exec(`
          CREATE TABLE story_views (
            id TEXT PRIMARY KEY,
            story_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            user_avatar TEXT,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("hidden_posts")) {
        sqlite.exec(`
          CREATE TABLE hidden_posts (
            id TEXT PRIMARY KEY,
            post_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("reported_posts")) {
        sqlite.exec(`
          CREATE TABLE reported_posts (
            id TEXT PRIMARY KEY,
            post_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("anonymous_messages")) {
        sqlite.exec(`
          CREATE TABLE anonymous_messages (
            id TEXT PRIMARY KEY,
            content TEXT NOT NULL,
            author_id TEXT NOT NULL,
            author_name TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("anonymous_message_reactions")) {
        sqlite.exec(`
          CREATE TABLE anonymous_message_reactions (
            id TEXT PRIMARY KEY,
            message_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            reaction TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      if (!tableExists("anonymous_message_comments")) {
        sqlite.exec(`
          CREATE TABLE anonymous_message_comments (
            id TEXT PRIMARY KEY,
            message_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
          );
        `);
      }

      sqlite.prepare(`PRAGMA user_version = ${SCHEMA_VERSION}`).run();
      
      const verifyVersion = sqlite.prepare("PRAGMA user_version").get() as { user_version: number };
      if (verifyVersion.user_version !== SCHEMA_VERSION) {
        throw new Error("Failed to update schema version");
      }
      
      sqlite.exec('COMMIT');
      console.log(`Database successfully migrated to version ${SCHEMA_VERSION}`);
    } catch (error) {
      sqlite.exec('ROLLBACK');
      console.error("Migration failed, rolling back:", error);
      throw error;
    }
  }
}

initializeDatabase();

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  getAllStudents(): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  deleteStudent(id: string): Promise<void>;
  
  getAllTeachers(): Promise<Teacher[]>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  deleteTeacher(id: string): Promise<void>;
  
  getAllPictures(): Promise<Picture[]>;
  createPicture(picture: InsertPicture): Promise<Picture>;
  approvePicture(id: string): Promise<void>;
  deletePicture(id: string): Promise<void>;

  getAllGames(): Promise<Game[]>;
  createGame(game: InsertGame): Promise<Game>;
  deleteGame(id: string): Promise<void>;
  
  getAllMessages(): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  deleteMessage(id: string): Promise<void>;
  
  getAllAnnouncements(): Promise<Announcement[]>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  deleteAnnouncement(id: string): Promise<void>;
  
  getAllStories(): Promise<Story[]>;
  getActiveStories(): Promise<Story[]>;
  createStory(story: InsertStory): Promise<Story>;
  deleteStory(id: string): Promise<void>;
  deleteExpiredStories(): Promise<void>;
  
  getLikesByPostId(postId: string): Promise<Like[]>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(postId: string, userId: string): Promise<void>;
  deleteLikeById(id: string): Promise<void>;
  
  getCommentsByPostId(postId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: string): Promise<void>;
  
  getSharesByPostId(postId: string): Promise<Share[]>;
  createShare(share: InsertShare): Promise<Share>;
  
  getReactionsByStoryId(storyId: string): Promise<StoryReaction[]>;
  createStoryReaction(reaction: InsertStoryReaction): Promise<StoryReaction>;
  deleteStoryReaction(storyId: string, userId: string): Promise<void>;
  
  getViewsByStoryId(storyId: string): Promise<StoryView[]>;
  createStoryView(view: InsertStoryView): Promise<StoryView>;
  getStoryViewByUserAndStory(storyId: string, userId: string): Promise<StoryView | undefined>;
  
  getHiddenPostsByUserId(userId: string): Promise<HiddenPost[]>;
  createHiddenPost(hiddenPost: InsertHiddenPost): Promise<HiddenPost>;
  deleteHiddenPost(postId: string, userId: string): Promise<void>;
  
  getReportedPosts(): Promise<ReportedPost[]>;
  createReportedPost(report: InsertReportedPost): Promise<ReportedPost>;
  
  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
  
  getDirectMessagesBetweenUsers(userId1: string, userId2: string): Promise<DirectMessage[]>;
  getAllDirectMessagesForUser(userId: string): Promise<DirectMessage[]>;
  getConversationsForUser(userId: string): Promise<any[]>;
  createDirectMessage(message: InsertDirectMessage): Promise<DirectMessage>;
  markDirectMessageAsRead(messageId: string): Promise<void>;
  deleteDirectMessage(id: string): Promise<void>;

  getAllAnonymousMessages(): Promise<AnonymousMessage[]>;
  getAnonymousMessagesForAdmin(): Promise<AnonymousMessage[]>;
  createAnonymousMessage(message: InsertAnonymousMessage): Promise<AnonymousMessage>;
  deleteAnonymousMessage(id: string): Promise<void>;

  getAnonymousMessageReactions(messageId: string): Promise<AnonymousMessageReaction[]>;
  setAnonymousMessageReaction(reaction: InsertAnonymousMessageReaction): Promise<void>;
  removeAnonymousMessageReaction(messageId: string, userId: string): Promise<void>;

  getAnonymousMessageComments(messageId: string): Promise<AnonymousMessageComment[]>;
  createAnonymousMessageComment(comment: InsertAnonymousMessageComment): Promise<AnonymousMessageComment>;
  deleteAnonymousMessageComment(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return result[0];
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const result = await db.select().from(schema.users).where(eq(schema.users.googleId, googleId));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(schema.users).values(user).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(schema.users);
  }

  async getAllStudents(): Promise<Student[]> {
    return await db.select().from(schema.students);
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const result = await db.insert(schema.students).values(student).returning();
    return result[0];
  }

  async deleteStudent(id: string): Promise<void> {
    await db.delete(schema.students).where(eq(schema.students.id, id));
  }

  async getAllTeachers(): Promise<Teacher[]> {
    return await db.select().from(schema.teachers);
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const result = await db.insert(schema.teachers).values(teacher).returning();
    return result[0];
  }

  async deleteTeacher(id: string): Promise<void> {
    await db.delete(schema.teachers).where(eq(schema.teachers.id, id));
  }

  async getAllPictures(): Promise<Picture[]> {
    return await db.select().from(schema.pictures).orderBy(desc(schema.pictures.timestamp));
  }

  async createPicture(picture: InsertPicture): Promise<Picture> {
    const result = await db.insert(schema.pictures).values(picture).returning();
    return result[0];
  }

  async approvePicture(id: string): Promise<void> {
    await db.update(schema.pictures).set({ status: "approved" }).where(eq(schema.pictures.id, id));
  }

  async deletePicture(id: string): Promise<void> {
    await db.delete(schema.pictures).where(eq(schema.pictures.id, id));
  }

  async getAllGames(): Promise<Game[]> {
    return await db.select().from(schema.games).orderBy(desc(schema.games.timestamp));
  }

  async createGame(game: InsertGame): Promise<Game> {
    const result = await db.insert(schema.games).values(game).returning();
    return result[0];
  }

  async deleteGame(id: string): Promise<void> {
    await db.delete(schema.games).where(eq(schema.games.id, id));
  }

  async getAllMessages(): Promise<Message[]> {
    return await db.select().from(schema.messages).orderBy(asc(schema.messages.timestamp));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const result = await db.insert(schema.messages).values(message).returning();
    return result[0];
  }

  async deleteMessage(id: string): Promise<void> {
    await db.delete(schema.messages).where(eq(schema.messages.id, id));
  }

  async getAllAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(schema.announcements).orderBy(desc(schema.announcements.createdAt));
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const result = await db.insert(schema.announcements).values(announcement).returning();
    return result[0];
  }

  async deleteAnnouncement(id: string): Promise<void> {
    await db.delete(schema.announcements).where(eq(schema.announcements.id, id));
  }

  async getAllStories(): Promise<Story[]> {
    return await db.select().from(schema.stories).orderBy(desc(schema.stories.createdAt));
  }

  async getActiveStories(): Promise<Story[]> {
    return await db.select().from(schema.stories).orderBy(desc(schema.stories.createdAt));
  }

  async createStory(story: InsertStory): Promise<Story> {
    const result = await db.insert(schema.stories).values(story).returning();
    return result[0];
  }

  async deleteStory(id: string): Promise<void> {
    await db.delete(schema.stories).where(eq(schema.stories.id, id));
  }

  async deleteExpiredStories(): Promise<void> {
    return;
  }

  async getLikesByPostId(postId: string): Promise<Like[]> {
    const rows = await db
      .select()
      .from(schema.likes)
      .where(eq(schema.likes.postId, postId))
      .orderBy(desc(schema.likes.createdAt));

    // Keep only the newest reaction per user in case legacy duplicates exist.
    const seen = new Set<string>();
    const deduped: Like[] = [];
    for (const row of rows) {
      if (seen.has(row.userId)) continue;
      seen.add(row.userId);
      deduped.push(row);
    }
    return deduped;
  }

  async createLike(like: InsertLike): Promise<Like> {
    const existing = await db
      .select()
      .from(schema.likes)
      .where(
        and(
          eq(schema.likes.postId, like.postId),
          eq(schema.likes.userId, like.userId)
        )
      );

    if (existing.length > 0) {
      const updated = await db
        .update(schema.likes)
        .set({ reaction: like.reaction ?? "like", createdAt: new Date() })
        .where(eq(schema.likes.id, existing[0].id))
        .returning();

      // Cleanup legacy duplicate rows for the same user/post.
      for (let i = 1; i < existing.length; i++) {
        await db.delete(schema.likes).where(eq(schema.likes.id, existing[i].id));
      }
      return updated[0];
    }

    const result = await db.insert(schema.likes).values(like).returning();
    return result[0];
  }

  async deleteLike(postId: string, userId: string): Promise<void> {
    await db.delete(schema.likes).where(
      and(
        eq(schema.likes.postId, postId),
        eq(schema.likes.userId, userId)
      )
    );
  }

  async deleteLikeById(id: string): Promise<void> {
    await db.delete(schema.likes).where(eq(schema.likes.id, id));
  }

  async getCommentsByPostId(postId: string): Promise<Comment[]> {
    return await db.select().from(schema.comments).where(eq(schema.comments.postId, postId)).orderBy(asc(schema.comments.createdAt));
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const result = await db.insert(schema.comments).values(comment).returning();
    return result[0];
  }

  async deleteComment(id: string): Promise<void> {
    await db.delete(schema.comments).where(eq(schema.comments.id, id));
  }

  async getSharesByPostId(postId: string): Promise<Share[]> {
    return await db.select().from(schema.shares).where(eq(schema.shares.postId, postId));
  }

  async createShare(share: InsertShare): Promise<Share> {
    const result = await db.insert(schema.shares).values(share).returning();
    return result[0];
  }

  async getReactionsByStoryId(storyId: string): Promise<StoryReaction[]> {
    return await db.select().from(schema.storyReactions).where(eq(schema.storyReactions.storyId, storyId));
  }

  async createStoryReaction(reaction: InsertStoryReaction): Promise<StoryReaction> {
    const result = await db.insert(schema.storyReactions).values(reaction).returning();
    return result[0];
  }

  async deleteStoryReaction(storyId: string, userId: string): Promise<void> {
    await db.delete(schema.storyReactions).where(
      and(
        eq(schema.storyReactions.storyId, storyId),
        eq(schema.storyReactions.userId, userId)
      )
    );
  }

  async getViewsByStoryId(storyId: string): Promise<StoryView[]> {
    return await db.select().from(schema.storyViews).where(eq(schema.storyViews.storyId, storyId)).orderBy(desc(schema.storyViews.createdAt));
  }

  async createStoryView(view: InsertStoryView): Promise<StoryView> {
    const existing = await this.getStoryViewByUserAndStory(view.storyId, view.userId);
    if (existing) {
      return existing;
    }
    const result = await db.insert(schema.storyViews).values(view).returning();
    return result[0];
  }

  async getStoryViewByUserAndStory(storyId: string, userId: string): Promise<StoryView | undefined> {
    const result = await db.select().from(schema.storyViews).where(
      and(
        eq(schema.storyViews.storyId, storyId),
        eq(schema.storyViews.userId, userId)
      )
    );
    return result[0];
  }

  async getHiddenPostsByUserId(userId: string): Promise<HiddenPost[]> {
    return await db.select().from(schema.hiddenPosts).where(eq(schema.hiddenPosts.userId, userId));
  }

  async createHiddenPost(hiddenPost: InsertHiddenPost): Promise<HiddenPost> {
    const result = await db.insert(schema.hiddenPosts).values(hiddenPost).returning();
    return result[0];
  }

  async deleteHiddenPost(postId: string, userId: string): Promise<void> {
    await db.delete(schema.hiddenPosts).where(
      and(
        eq(schema.hiddenPosts.postId, postId),
        eq(schema.hiddenPosts.userId, userId)
      )
    );
  }

  async getReportedPosts(): Promise<ReportedPost[]> {
    return await db.select().from(schema.reportedPosts).orderBy(desc(schema.reportedPosts.createdAt));
  }

  async createReportedPost(report: InsertReportedPost): Promise<ReportedPost> {
    const result = await db.insert(schema.reportedPosts).values(report).returning();
    return result[0];
  }

  async getSettings(): Promise<Settings | undefined> {
    const result = await db.select().from(schema.settings).limit(1);
    if (result.length === 0) {
      const defaultSettings: InsertSettings = {
        faviconPath: null,
        siteTitle: "ICT Canary",
        siteDescription: "A futuristic pixel-style platform for ICT Canary.",
        loginMessage: "Access the futuristic portal",
        gameOrientation: "both",
        postApprovalRequired: true,
      };
      return await this.updateSettings(defaultSettings);
    }
    return result[0];
  }

  async updateSettings(settings: Partial<InsertSettings>): Promise<Settings> {
    const existing = await db.select().from(schema.settings).limit(1);
    
    if (existing.length === 0) {
      const fullSettings: InsertSettings = {
        faviconPath: settings.faviconPath !== undefined ? settings.faviconPath : null,
        siteTitle: settings.siteTitle || "ICT Canary",
        siteDescription: settings.siteDescription || "A futuristic pixel-style platform for ICT Canary.",
        loginMessage: settings.loginMessage || "Access the futuristic portal",
        gameOrientation: settings.gameOrientation || "both",
        postApprovalRequired: settings.postApprovalRequired !== undefined ? settings.postApprovalRequired : true,
      };
      const result = await db.insert(schema.settings).values(fullSettings).returning();
      return result[0];
    } else {
      const result = await db.update(schema.settings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(schema.settings.id, existing[0].id))
        .returning();
      return result[0];
    }
  }

  async getDirectMessagesBetweenUsers(userId1: string, userId2: string): Promise<DirectMessage[]> {
    const messages = await db.select().from(schema.directMessages).where(
      and(
        eq(schema.directMessages.senderId, userId1),
        eq(schema.directMessages.receiverId, userId2)
      )
    );
    const reverseMessages = await db.select().from(schema.directMessages).where(
      and(
        eq(schema.directMessages.senderId, userId2),
        eq(schema.directMessages.receiverId, userId1)
      )
    );
    return [...messages, ...reverseMessages].sort((a, b) => {
      const aTime = a.timestamp instanceof Date ? a.timestamp.getTime() : new Date(a.timestamp).getTime();
      const bTime = b.timestamp instanceof Date ? b.timestamp.getTime() : new Date(b.timestamp).getTime();
      return aTime - bTime;
    });
  }

  async getAllDirectMessagesForUser(userId: string): Promise<DirectMessage[]> {
    const sentMessages = await db.select().from(schema.directMessages).where(
      eq(schema.directMessages.senderId, userId)
    );
    const receivedMessages = await db.select().from(schema.directMessages).where(
      eq(schema.directMessages.receiverId, userId)
    );
    return [...sentMessages, ...receivedMessages].sort((a, b) => {
      const aTime = a.timestamp instanceof Date ? a.timestamp.getTime() : new Date(a.timestamp).getTime();
      const bTime = b.timestamp instanceof Date ? b.timestamp.getTime() : new Date(b.timestamp).getTime();
      return bTime - aTime;
    });
  }

  async getConversationsForUser(userId: string): Promise<any[]> {
    const allMessages = await this.getAllDirectMessagesForUser(userId);
    const conversationsMap = new Map<string, any>();

    for (const msg of allMessages) {
      const otherUserId = msg.senderId === userId ? msg.receiverId : msg.senderId;
      const otherUserName = msg.senderId === userId ? msg.receiverName : msg.senderName;
      const otherUserAvatar = msg.senderId === userId ? msg.receiverAvatar : msg.senderAvatar;

      if (!conversationsMap.has(otherUserId) || 
          (msg.timestamp instanceof Date ? msg.timestamp.getTime() : new Date(msg.timestamp).getTime()) > 
          (conversationsMap.get(otherUserId)!.lastMessage.timestamp instanceof Date ? 
            conversationsMap.get(otherUserId)!.lastMessage.timestamp.getTime() : 
            new Date(conversationsMap.get(otherUserId)!.lastMessage.timestamp).getTime())) {
        
        const unreadCount = allMessages.filter(m => 
          m.receiverId === userId && 
          m.senderId === otherUserId && 
          !m.isRead
        ).length;

        conversationsMap.set(otherUserId, {
          userId: otherUserId,
          userName: otherUserName,
          userAvatar: otherUserAvatar,
          lastMessage: msg,
          unreadCount,
        });
      }
    }

    return Array.from(conversationsMap.values()).sort((a, b) => {
      const aTime = a.lastMessage.timestamp instanceof Date ? a.lastMessage.timestamp.getTime() : new Date(a.lastMessage.timestamp).getTime();
      const bTime = b.lastMessage.timestamp instanceof Date ? b.lastMessage.timestamp.getTime() : new Date(b.lastMessage.timestamp).getTime();
      return bTime - aTime;
    });
  }

  async createDirectMessage(message: InsertDirectMessage): Promise<DirectMessage> {
    const result = await db.insert(schema.directMessages).values(message).returning();
    return result[0];
  }

  async markDirectMessageAsRead(messageId: string): Promise<void> {
    await db.update(schema.directMessages)
      .set({ isRead: true })
      .where(eq(schema.directMessages.id, messageId));
  }

  async deleteDirectMessage(id: string): Promise<void> {
    await db.delete(schema.directMessages).where(eq(schema.directMessages.id, id));
  }

  async getAllAnonymousMessages(): Promise<AnonymousMessage[]> {
    return await db
      .select({
        id: schema.anonymousMessages.id,
        content: schema.anonymousMessages.content,
        authorId: sql<string>`'anonymous'`.as("authorId"),
        authorName: sql<string>`'Anonymous'`.as("authorName"),
        createdAt: schema.anonymousMessages.createdAt,
      })
      .from(schema.anonymousMessages)
      .orderBy(desc(schema.anonymousMessages.createdAt));
  }

  async getAnonymousMessagesForAdmin(): Promise<AnonymousMessage[]> {
    return await db.select().from(schema.anonymousMessages).orderBy(desc(schema.anonymousMessages.createdAt));
  }

  async createAnonymousMessage(message: InsertAnonymousMessage): Promise<AnonymousMessage> {
    const result = await db.insert(schema.anonymousMessages).values(message).returning();
    return result[0];
  }

  async deleteAnonymousMessage(id: string): Promise<void> {
    await db
      .delete(schema.anonymousMessageReactions)
      .where(eq(schema.anonymousMessageReactions.messageId, id));
    await db
      .delete(schema.anonymousMessageComments)
      .where(eq(schema.anonymousMessageComments.messageId, id));
    await db.delete(schema.anonymousMessages).where(eq(schema.anonymousMessages.id, id));
  }

  async getAnonymousMessageReactions(messageId: string): Promise<AnonymousMessageReaction[]> {
    return await db
      .select()
      .from(schema.anonymousMessageReactions)
      .where(eq(schema.anonymousMessageReactions.messageId, messageId));
  }

  async setAnonymousMessageReaction(reaction: InsertAnonymousMessageReaction): Promise<void> {
    const existing = await db
      .select()
      .from(schema.anonymousMessageReactions)
      .where(
        and(
          eq(schema.anonymousMessageReactions.messageId, reaction.messageId),
          eq(schema.anonymousMessageReactions.userId, reaction.userId)
        )
      );

    if (existing.length > 0) {
      await db
        .update(schema.anonymousMessageReactions)
        .set({ reaction: reaction.reaction, createdAt: new Date() })
        .where(eq(schema.anonymousMessageReactions.id, existing[0].id));
      return;
    }

    await db.insert(schema.anonymousMessageReactions).values(reaction);
  }

  async removeAnonymousMessageReaction(messageId: string, userId: string): Promise<void> {
    await db
      .delete(schema.anonymousMessageReactions)
      .where(
        and(
          eq(schema.anonymousMessageReactions.messageId, messageId),
          eq(schema.anonymousMessageReactions.userId, userId)
        )
      );
  }

  async getAnonymousMessageComments(messageId: string): Promise<AnonymousMessageComment[]> {
    return await db
      .select()
      .from(schema.anonymousMessageComments)
      .where(eq(schema.anonymousMessageComments.messageId, messageId))
      .orderBy(asc(schema.anonymousMessageComments.createdAt));
  }

  async createAnonymousMessageComment(comment: InsertAnonymousMessageComment): Promise<AnonymousMessageComment> {
    const result = await db.insert(schema.anonymousMessageComments).values(comment).returning();
    return result[0];
  }

  async deleteAnonymousMessageComment(id: string): Promise<void> {
    await db.delete(schema.anonymousMessageComments).where(eq(schema.anonymousMessageComments.id, id));
  }
}

export const storage = new DatabaseStorage();
