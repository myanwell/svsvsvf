import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "@shared/schema";

const databaseUrl = process.env.DATABASE_URL!;
const sql = neon(databaseUrl);
const db = drizzle(sql, { schema });

async function seed() {
  console.log("Seeding database...");

  // Add initial students
  await db.insert(schema.students).values([
    { name: "Alex Pixel", grade: "10", image: "https://api.dicebear.com/7.x/pixel-art/svg?seed=Alex" },
    { name: "Sarah Bit", grade: "11", image: "https://api.dicebear.com/7.x/pixel-art/svg?seed=Sarah" },
    { name: "John Glitch", grade: "9", image: "https://api.dicebear.com/7.x/pixel-art/svg?seed=John" },
  ]);

  // Add initial teachers
  await db.insert(schema.teachers).values([
    { name: "Mr. Binary", subject: "Computer Science", image: "https://api.dicebear.com/7.x/pixel-art/svg?seed=Binary" },
    { name: "Mrs. Logic", subject: "Mathematics", image: "https://api.dicebear.com/7.x/pixel-art/svg?seed=Logic" },
  ]);

  // Add initial pictures
  await db.insert(schema.pictures).values([
    { url: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80", caption: "Server Room", author: "Admin", status: "approved" },
    { url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80", caption: "Coding Night", author: "User1", status: "approved" },
  ]);

  // Add initial announcements
  await db.insert(schema.announcements).values([
    { text: "Welcome to ICT Canary! Check out the new pictures." },
    { text: "Mid-term exams are starting next week." },
  ]);

  console.log("Database seeded successfully!");
}

seed().catch(console.error);
