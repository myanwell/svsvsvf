import { sql } from "drizzle-orm";
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = sqliteTable("users", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  googleId: text("google_id").unique(),
  name: text("name").notNull(),
  email: text("email"),
  role: text("role").notNull().default("user"),
  avatar: text("avatar"),
});

export const students = sqliteTable("students", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  grade: text("grade").notNull(),
  image: text("image").notNull(),
});

export const teachers = sqliteTable("teachers", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  image: text("image").notNull(),
});

export const pictures = sqliteTable("pictures", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  filePath: text("file_path").notNull(),
  fileName: text("file_name").notNull(),
  caption: text("caption").notNull(),
  author: text("author").notNull(),
  authorId: text("author_id").notNull(),
  status: text("status").notNull().default("pending"),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const games = sqliteTable("games", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  title: text("title").notNull(),
  logoPath: text("logo_path").notNull(),
  logoName: text("logo_name").notNull(),
  description: text("description").notNull(),
  gameUrl: text("game_url").notNull(),
  gameOrientation: text("game_orientation").notNull().default("both"),
  author: text("author").notNull(),
  authorId: text("author_id").notNull(),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const messages = sqliteTable("messages", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  senderId: text("sender_id").notNull(),
  senderName: text("sender_name").notNull(),
  content: text("content"),
  filePath: text("file_path"),
  fileName: text("file_name"),
  fileType: text("file_type"),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const announcements = sqliteTable("announcements", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  text: text("text").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const stories = sqliteTable("stories", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  userAvatar: text("user_avatar"),
  filePath: text("file_path").notNull(),
  fileName: text("file_name").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  expiresAt: integer("expires_at", { mode: "timestamp" }).notNull(),
});

export const likes = sqliteTable("likes", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  postId: text("post_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  reaction: text("reaction").notNull().default("like"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const comments = sqliteTable("comments", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  postId: text("post_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  content: text("content").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const shares = sqliteTable("shares", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  postId: text("post_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const storyReactions = sqliteTable("story_reactions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  storyId: text("story_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  reaction: text("reaction").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const storyViews = sqliteTable("story_views", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  storyId: text("story_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  userAvatar: text("user_avatar"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const hiddenPosts = sqliteTable("hidden_posts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  postId: text("post_id").notNull(),
  userId: text("user_id").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const reportedPosts = sqliteTable("reported_posts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  postId: text("post_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const settings = sqliteTable("settings", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  faviconPath: text("favicon_path"),
  siteTitle: text("site_title").notNull().default("ICT Canary"),
  siteDescription: text("site_description").notNull().default("A futuristic pixel-style platform for ICT Canary."),
  loginMessage: text("login_message").notNull().default("Access the futuristic portal"),
  gameOrientation: text("game_orientation").notNull().default("both"),
  postApprovalRequired: integer("post_approval_required", { mode: "boolean" }).notNull().default(true),
  updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const directMessages = sqliteTable("direct_messages", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  senderId: text("sender_id").notNull(),
  senderName: text("sender_name").notNull(),
  senderAvatar: text("sender_avatar"),
  receiverId: text("receiver_id").notNull(),
  receiverName: text("receiver_name").notNull(),
  receiverAvatar: text("receiver_avatar"),
  content: text("content"),
  filePath: text("file_path"),
  fileName: text("file_name"),
  fileType: text("file_type"),
  isRead: integer("is_read", { mode: "boolean" }).notNull().default(false),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const anonymousMessages = sqliteTable("anonymous_messages", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  content: text("content").notNull(),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const anonymousMessageReactions = sqliteTable("anonymous_message_reactions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  messageId: text("message_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  reaction: text("reaction").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const anonymousMessageComments = sqliteTable("anonymous_message_comments", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  messageId: text("message_id").notNull(),
  userId: text("user_id").notNull(),
  userName: text("user_name").notNull(),
  content: text("content").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export const insertTeacherSchema = createInsertSchema(teachers).omit({
  id: true,
});

export const insertPictureSchema = createInsertSchema(pictures).omit({
  id: true,
  timestamp: true,
});

export const insertGameSchema = createInsertSchema(games)
  .omit({
    id: true,
    timestamp: true,
  })
  .extend({
    gameUrl: z.string().url(),
    gameOrientation: z.enum(["portrait", "landscape", "both"]).default("both"),
  });

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  timestamp: true,
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
  createdAt: true,
});

export const insertStorySchema = createInsertSchema(stories).omit({
  id: true,
  createdAt: true,
});

export const insertLikeSchema = createInsertSchema(likes).omit({
  id: true,
  createdAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

export const insertShareSchema = createInsertSchema(shares).omit({
  id: true,
  createdAt: true,
});

export const insertStoryReactionSchema = createInsertSchema(storyReactions).omit({
  id: true,
  createdAt: true,
});

export const insertStoryViewSchema = createInsertSchema(storyViews).omit({
  id: true,
  createdAt: true,
});

export const insertHiddenPostSchema = createInsertSchema(hiddenPosts).omit({
  id: true,
  createdAt: true,
});

export const insertReportedPostSchema = createInsertSchema(reportedPosts).omit({
  id: true,
  createdAt: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

export const insertDirectMessageSchema = createInsertSchema(directMessages).omit({
  id: true,
  timestamp: true,
});

export const insertAnonymousMessageSchema = createInsertSchema(anonymousMessages).omit({
  id: true,
  createdAt: true,
});

export const insertAnonymousMessageReactionSchema = createInsertSchema(anonymousMessageReactions).omit({
  id: true,
  createdAt: true,
});

export const insertAnonymousMessageCommentSchema = createInsertSchema(anonymousMessageComments).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type Teacher = typeof teachers.$inferSelect;

export type InsertPicture = z.infer<typeof insertPictureSchema>;
export type Picture = typeof pictures.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;
export type Announcement = typeof announcements.$inferSelect;

export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof stories.$inferSelect;

export type InsertLike = z.infer<typeof insertLikeSchema>;
export type Like = typeof likes.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type InsertShare = z.infer<typeof insertShareSchema>;
export type Share = typeof shares.$inferSelect;

export type InsertStoryReaction = z.infer<typeof insertStoryReactionSchema>;
export type StoryReaction = typeof storyReactions.$inferSelect;

export type InsertStoryView = z.infer<typeof insertStoryViewSchema>;
export type StoryView = typeof storyViews.$inferSelect;

export type InsertHiddenPost = z.infer<typeof insertHiddenPostSchema>;
export type HiddenPost = typeof hiddenPosts.$inferSelect;

export type InsertReportedPost = z.infer<typeof insertReportedPostSchema>;
export type ReportedPost = typeof reportedPosts.$inferSelect;

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;
export type DirectMessage = typeof directMessages.$inferSelect;

export type InsertAnonymousMessage = z.infer<typeof insertAnonymousMessageSchema>;
export type AnonymousMessage = typeof anonymousMessages.$inferSelect;

export type InsertAnonymousMessageReaction = z.infer<typeof insertAnonymousMessageReactionSchema>;
export type AnonymousMessageReaction = typeof anonymousMessageReactions.$inferSelect;

export type InsertAnonymousMessageComment = z.infer<typeof insertAnonymousMessageCommentSchema>;
export type AnonymousMessageComment = typeof anonymousMessageComments.$inferSelect;
