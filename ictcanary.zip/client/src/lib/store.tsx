import React, { createContext, useContext } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "./api";

type UserRole = "guest" | "user" | "admin" | null;

interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
  email?: string;
}

interface AppContextType {
  user: User | null;
  isLoading: boolean;
  loginGoogle: () => void;
  loginGuest: () => Promise<void>;
  loginAdmin: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  
  const { data: userData, isLoading } = useQuery({
    queryKey: ["user"],
    queryFn: api.auth.getUser,
    retry: false,
  });

  const user = userData?.user || null;

  const loginGoogle = () => {
    api.auth.loginGoogle();
  };

  const loginGuestMutation = useMutation({
    mutationFn: api.auth.loginGuest,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user"] });
    },
  });

  const loginAdminMutation = useMutation({
    mutationFn: ({ username, password }: { username: string; password: string }) => 
      api.auth.loginAdmin(username, password),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user"] });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: api.auth.logout,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user"] });
    },
  });

  return (
    <AppContext.Provider value={{
      user,
      isLoading,
      loginGoogle,
      loginGuest: () => loginGuestMutation.mutateAsync(),
      loginAdmin: (username: string, password: string) => 
        loginAdminMutation.mutateAsync({ username, password }),
      logout: () => logoutMutation.mutateAsync(),
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within an AppProvider");
  return context;
}
