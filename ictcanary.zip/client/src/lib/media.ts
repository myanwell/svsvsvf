export function resolveMediaUrl(rawPath?: string | null): string {
  if (!rawPath) {
    return "";
  }

  const trimmed = rawPath.trim();
  if (!trimmed) {
    return "";
  }

  if (/^(https?:\/\/|data:|blob:)/i.test(trimmed)) {
    return trimmed;
  }

  const normalized = trimmed.replace(/\\/g, "/");
  if (normalized.startsWith("/uploads/")) {
    return normalized;
  }
  if (normalized.startsWith("uploads/")) {
    return `/${normalized}`;
  }

  const uploadsAbsoluteIdx = normalized.toLowerCase().indexOf("/uploads/");
  if (uploadsAbsoluteIdx >= 0) {
    return normalized.slice(uploadsAbsoluteIdx);
  }

  const uploadsRelativeIdx = normalized.toLowerCase().indexOf("uploads/");
  if (uploadsRelativeIdx >= 0) {
    return `/${normalized.slice(uploadsRelativeIdx)}`;
  }

  if (normalized.startsWith("/")) {
    return normalized;
  }

  return `/${normalized}`;
}
