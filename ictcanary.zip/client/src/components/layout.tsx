import { BottomNav } from "./bottom-nav";
import { TopBar } from "./top-bar";
import { useApp } from "@/lib/store";
import { useLocation } from "wouter";
import Login from "@/pages/login";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useEffect } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useApp();
  const [location] = useLocation();
  
  const { data: settings } = useQuery({
    queryKey: ["settings"],
    queryFn: api.settings.get,
  });

  useEffect(() => {
    if (settings) {
      document.title = settings.siteTitle || "ICT Canary";
      
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", settings.siteDescription || "A futuristic pixel-style platform for ICT Canary.");
      }
      
      const ogTitle = document.querySelector('meta[property="og:title"]');
      if (ogTitle) {
        ogTitle.setAttribute("content", settings.siteTitle || "ICT Canary");
      }
      
      const ogDescription = document.querySelector('meta[property="og:description"]');
      if (ogDescription) {
        ogDescription.setAttribute("content", settings.siteDescription || "A futuristic pixel-style platform for ICT Canary.");
      }
      
      const twitterTitle = document.querySelector('meta[name="twitter:title"]');
      if (twitterTitle) {
        twitterTitle.setAttribute("content", settings.siteTitle || "ICT Canary");
      }
      
      const twitterDescription = document.querySelector('meta[name="twitter:description"]');
      if (twitterDescription) {
        twitterDescription.setAttribute("content", settings.siteDescription || "A futuristic pixel-style platform for ICT Canary.");
      }
      
      if (settings.faviconPath) {
        const favicon = document.querySelector('link[rel="icon"]');
        if (favicon) {
          favicon.setAttribute("href", settings.faviconPath);
        }
      }
    }
  }, [settings]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="font-pixel text-primary">Loading System...</p>
        </div>
      </div>
    );
  }

  if (!user && location !== "/login") {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-body selection:bg-primary selection:text-white">
      {user && <TopBar />}
      
      <main className="flex-1 pt-28 pb-20 px-4 md:px-6 max-w-7xl mx-auto w-full animate-in fade-in duration-500">
        {children}
      </main>
      
      {user && <BottomNav />}
    </div>
  );
}
