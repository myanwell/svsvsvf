import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Paperclip, X, User, MessageSquare, ArrowLeft, Users } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";
import { useToast } from "@/hooks/use-toast";
import { resolveMediaUrl } from "@/lib/media";

export default function Chat() {
  const { user } = useApp();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();
  const { toast } = useToast();
  
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);


  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations"],
    queryFn: api.directMessages.getConversations,
    refetchInterval: 5000,
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ["allUsers"],
    queryFn: api.getAllUsers,
  });

  const { data: globalMessages = [] } = useQuery({
    queryKey: ["messages"],
    queryFn: api.messages.getAll,
    refetchInterval: 3000,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ["directMessages", selectedUserId],
    queryFn: () => selectedUserId === "everyone" ? Promise.resolve([]) : selectedUserId ? api.directMessages.getWithUser(selectedUserId) : Promise.resolve([]),
    enabled: !!selectedUserId && selectedUserId !== "everyone",
    refetchInterval: 2000,
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data: { receiverId: string; content?: string; file?: File }) => api.directMessages.send(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["directMessages", selectedUserId] });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
      setMessageText("");
      setAttachedFile(null);
    },
  });

  const sendGlobalMessageMutation = useMutation({
    mutationFn: api.messages.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
      setMessageText("");
      setAttachedFile(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Send Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteGlobalMessageMutation = useMutation({
    mutationFn: api.messages.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, globalMessages]);

  useEffect(() => {
    if (selectedUserId && selectedUserId !== "everyone" && messages.length > 0) {
      const unreadMessages = messages.filter((m: any) => 
        m.receiverId === user?.id && !m.isRead
      );
      unreadMessages.forEach((m: any) => {
        api.directMessages.markAsRead(m.id);
      });
    }
  }, [messages, selectedUserId, user]);

  const handleSendMessage = () => {
    if (selectedUserId === "everyone") {
      if (!messageText.trim() && !attachedFile) return;
      const formData = new FormData();
      if (messageText.trim()) {
        formData.append("content", messageText);
      }
      if (attachedFile) {
        formData.append("file", attachedFile);
      }
      sendGlobalMessageMutation.mutate(formData);
    } else {
      if (!selectedUserId) return;
      if (!messageText.trim() && !attachedFile) return;

      sendMessageMutation.mutate({
        receiverId: selectedUserId,
        content: messageText.trim() || undefined,
        file: attachedFile || undefined,
      });
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith("image/")) {
      return "🖼️";
    } else if (fileType.startsWith("video/")) {
      return "🎥";
    } else if (fileType.startsWith("audio/")) {
      return "🎵";
    } else if (fileType.includes("pdf")) {
      return "📄";
    }
    return "📎";
  };

  const selectedConversation = conversations.find((c: any) => c.userId === selectedUserId);
  const selectedUser = allUsers.find((u: any) => u.id === selectedUserId);

  if (!user || user.role === "guest") {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4 text-center">
        <MessageSquare className="w-16 h-16 text-muted-foreground" />
        <h1 className="text-2xl font-pixel">Chat</h1>
        <p className="font-mono text-muted-foreground">Please log in to access chat.</p>
        <Button onClick={() => setLocation("/login")} className="pixel-corners">Go to Login</Button>
      </div>
    );
  }

  const showList = !isMobile || !selectedUserId;
  const showChat = !isMobile || selectedUserId;

  return (
    <div className="h-[calc(100vh-10rem)] flex border border-primary/30 pixel-corners overflow-hidden">
      {showList && (
        <div className={cn(
          "border-r border-primary/30 flex flex-col bg-background",
          isMobile ? "w-full" : "w-80"
        )}>
          <div className="p-4 bg-primary/10 border-b border-primary/30">
            <h2 className="font-pixel text-lg">Messages</h2>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              <button
                onClick={() => setSelectedUserId("everyone")}
                className={cn(
                  "w-full p-3 flex items-center gap-3 hover:bg-muted/50 transition-colors pixel-corners text-left",
                  selectedUserId === "everyone" && "bg-primary/20"
                )}
                data-testid="conversation-everyone"
              >
                <div className="w-10 h-10 pixel-corners bg-secondary/20 flex items-center justify-center">
                  <Users className="w-5 h-5 text-secondary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-futuristic text-sm truncate">Everyone</p>
                  </div>
                  <p className="text-xs font-mono text-muted-foreground truncate">
                    Group chat with all users
                  </p>
                </div>
              </button>

              {conversations.length === 0 && allUsers.length === 0 && (
                <div className="p-4 text-center">
                  <p className="text-sm font-mono text-muted-foreground">No conversations yet</p>
                </div>
              )}

              {conversations.map((conv: any) => (
                <button
                  key={conv.userId}
                  onClick={() => setSelectedUserId(conv.userId)}
                  className={cn(
                    "w-full p-3 flex items-center gap-3 hover:bg-muted/50 transition-colors pixel-corners text-left",
                    selectedUserId === conv.userId && "bg-primary/20"
                  )}
                  data-testid={`conversation-${conv.userId}`}
                >
                  <Avatar className="w-10 h-10 pixel-corners">
                    <AvatarImage src={conv.userAvatar} />
                    <AvatarFallback className="pixel-corners bg-primary/20">
                      <User className="w-5 h-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-futuristic text-sm truncate">{conv.userName}</p>
                      {conv.unreadCount > 0 && (
                        <span className="bg-destructive text-destructive-foreground px-2 py-0.5 text-xs font-mono rounded-full ml-2" data-testid={`unread-count-${conv.userId}`}>
                          {conv.unreadCount}
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-mono text-muted-foreground truncate">
                      {conv.lastMessage.content || "Attachment"}
                    </p>
                  </div>
                </button>
              ))}

              {allUsers.filter((u: any) => !conversations.find((c: any) => c.userId === u.id)).map((user: any) => (
                <button
                  key={user.id}
                  onClick={() => setSelectedUserId(user.id)}
                  className={cn(
                    "w-full p-3 flex items-center gap-3 hover:bg-muted/50 transition-colors pixel-corners text-left",
                    selectedUserId === user.id && "bg-primary/20"
                  )}
                  data-testid={`user-${user.id}`}
                >
                  <Avatar className="w-10 h-10 pixel-corners">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback className="pixel-corners bg-primary/20">
                      <User className="w-5 h-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-futuristic text-sm truncate">{user.name}</p>
                    <p className="text-xs font-mono text-muted-foreground">Start a conversation</p>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {showChat && (
        <div className={cn("flex-1 flex flex-col", isMobile && "w-full")}>
          {selectedUserId ? (
            <>
              <div className="p-4 bg-secondary/10 border-b border-primary/30 flex items-center gap-3">
                {isMobile && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedUserId(null)}
                    className="mr-2"
                    data-testid="button-back"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                )}
                {selectedUserId === "everyone" ? (
                  <>
                    <div className="w-10 h-10 pixel-corners bg-secondary/20 flex items-center justify-center">
                      <Users className="w-5 h-5 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-futuristic">Everyone</h3>
                      <p className="text-xs font-mono text-muted-foreground">Group chat</p>
                    </div>
                  </>
                ) : (
                  <>
                    <Avatar className="w-10 h-10 pixel-corners">
                      <AvatarImage src={selectedConversation?.userAvatar || selectedUser?.avatar} />
                      <AvatarFallback className="pixel-corners bg-secondary/20">
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-futuristic">
                        {selectedConversation?.userName || selectedUser?.name}
                      </h3>
                    </div>
                  </>
                )}
              </div>

              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {selectedUserId === "everyone" ? (
                    globalMessages.map((msg: any) => {
                      const isSent = msg.senderId === user.id;
                      const isAdmin = msg.senderId === "admin";
                      return (
                        <div
                          key={msg.id}
                          className={cn(
                            "flex gap-2",
                            isSent ? "justify-end" : "justify-start"
                          )}
                          data-testid={`global-message-${msg.id}`}
                        >
                          <div className={cn("max-w-[85%] space-y-1", isSent && "items-end")}>
                            {!isSent && (
                              <p className="text-xs font-semibold text-muted-foreground px-1">
                                {msg.senderName}
                              </p>
                            )}
                            <div
                              className={cn(
                                "p-3 pixel-corners relative group",
                                isSent
                                  ? "bg-primary text-primary-foreground"
                                  : isAdmin
                                  ? "bg-accent/30 border-2 border-accent"
                                  : "bg-muted"
                              )}
                            >
                              {msg.content && (
                                <p className="font-mono text-sm break-words">{msg.content}</p>
                              )}
                              {msg.filePath && (
                                <div className="mt-2">
                                  {msg.fileType?.startsWith("image/") ? (
                                    <img
                                      src={resolveMediaUrl(msg.filePath)}
                                      alt={msg.fileName}
                                      className="max-w-full rounded border border-primary/30"
                                    />
                                  ) : (
                                    <a
                                      href={resolveMediaUrl(msg.filePath)}
                                      download={msg.fileName}
                                      className="flex items-center gap-2 text-xs underline hover:no-underline"
                                    >
                                      {getFileIcon(msg.fileType)} {msg.fileName}
                                    </a>
                                  )}
                                </div>
                              )}
                              {user?.role === "admin" && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="absolute -top-2 -right-2 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity bg-destructive hover:bg-destructive/80"
                                  onClick={() => deleteGlobalMessageMutation.mutate(msg.id)}
                                >
                                  <X className="w-3 h-3 text-destructive-foreground" />
                                </Button>
                              )}
                            </div>
                            <p className="text-xs font-mono text-muted-foreground px-1">
                              {new Date(msg.timestamp).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    messages.map((msg: any) => {
                      const isSent = msg.senderId === user.id;
                      return (
                        <div
                          key={msg.id}
                          className={cn(
                            "flex gap-2",
                            isSent ? "justify-end" : "justify-start"
                          )}
                          data-testid={`message-${msg.id}`}
                        >
                          <div
                            className={cn(
                              "max-w-[70%] space-y-1",
                              isSent && "items-end"
                            )}
                          >
                            <div
                              className={cn(
                                "p-3 pixel-corners",
                                isSent
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted"
                              )}
                            >
                              {msg.content && (
                                <p className="font-mono text-sm break-words">{msg.content}</p>
                              )}
                              {msg.filePath && (
                                <div className="mt-2">
                                  {msg.fileType?.startsWith("image/") ? (
                                    <img
                                      src={resolveMediaUrl(msg.filePath)}
                                      alt={msg.fileName}
                                      className="max-w-full rounded border border-primary/30"
                                      data-testid={`message-image-${msg.id}`}
                                    />
                                  ) : (
                                    <a
                                      href={resolveMediaUrl(msg.filePath)}
                                      download={msg.fileName}
                                      className="flex items-center gap-2 text-xs underline hover:no-underline"
                                      data-testid={`message-file-${msg.id}`}
                                    >
                                      <Paperclip className="w-3 h-3" />
                                      {msg.fileName}
                                    </a>
                                  )}
                                </div>
                              )}
                            </div>
                            <p className="text-xs font-mono text-muted-foreground px-1">
                              {new Date(msg.timestamp).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>

              <div className="p-4 border-t border-primary/30">
                {attachedFile && (
                  <div className="mb-2 flex items-center gap-2 p-2 bg-muted pixel-corners">
                    <Paperclip className="w-4 h-4" />
                    <span className="text-sm font-mono flex-1 truncate">{attachedFile.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setAttachedFile(null)}
                      className="h-6 w-6 p-0"
                      data-testid="button-remove-attachment"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    onChange={(e) => setAttachedFile(e.target.files?.[0] || null)}
                    data-testid="input-file-attachment"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => fileInputRef.current?.click()}
                    className="pixel-corners"
                    data-testid="button-attach-file"
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    className="pixel-corners"
                    data-testid="input-message-text"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!messageText.trim() && !attachedFile}
                    className="pixel-corners"
                    data-testid="button-send-message"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center space-y-4">
                <MessageSquare className="w-16 h-16 mx-auto text-muted-foreground" />
                <p className="font-mono text-muted-foreground">Select a conversation to start messaging</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
