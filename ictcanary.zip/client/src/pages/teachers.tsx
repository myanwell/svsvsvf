import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Teachers() {
  const { data: teachers = [], isLoading } = useQuery({
    queryKey: ["teachers"],
    queryFn: api.teachers.getAll,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-secondary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-secondary/30 pb-4">
        <h2 className="text-3xl font-pixel text-secondary drop-shadow-[0_0_5px_rgba(0,243,255,0.8)]">
          Faculty
        </h2>
        <span className="font-mono text-xs text-muted-foreground bg-muted px-2 py-1">
          Total: {teachers.length}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {teachers.map((teacher: any) => (
          <Card key={teacher.id} className="bg-card/80 border-2 border-muted hover:border-secondary transition-all duration-300 pixel-corners overflow-hidden group">
            <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
              <div className="relative w-24 h-24">
                <div className="absolute inset-0 bg-secondary/20 rounded-full blur-xl group-hover:blur-2xl transition-all opacity-0 group-hover:opacity-100" />
                <Avatar className="w-24 h-24 border-2 border-primary/50 pixel-corners rounded-none">
                  <AvatarImage src={teacher.image} alt={teacher.name} className="pixelated" />
                  <AvatarFallback className="rounded-none font-pixel text-xs">IMG</AvatarFallback>
                </Avatar>
              </div>
              
              <div className="space-y-1 w-full">
                <h3 className="font-futuristic font-bold text-lg truncate">{teacher.name}</h3>
                <p className="font-mono text-sm text-secondary">{teacher.subject}</p>
                <div className="h-1 w-full bg-muted mt-2 relative overflow-hidden">
                   <div className="absolute inset-0 bg-gradient-to-r from-secondary to-primary w-full" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
