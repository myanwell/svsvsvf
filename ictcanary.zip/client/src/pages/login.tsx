import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useApp } from "@/lib/store";
import { User, Shield } from "lucide-react";
import logo from "@assets/generated_images/pixel_art_canary_bird_logo.png";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export default function Login() {
  const { loginGoogle, loginGuest, loginAdmin } = useApp();
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [adminUsername, setAdminUsername] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [adminError, setAdminError] = useState("");
  
  const { data: settings } = useQuery({
    queryKey: ["settings"],
    queryFn: api.settings.get,
  });

  const handleAdminLogin = async () => {
    setAdminError("");
    try {
      await loginAdmin(adminUsername, adminPassword);
    } catch (error) {
      setAdminError(error instanceof Error ? error.message : "Login failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80')] bg-cover bg-center relative">
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />

      <Card className="w-full max-w-md z-10 border-2 border-primary/50 bg-card/90 shadow-[0_0_20px_rgba(191,0,255,0.3)] pixel-corners">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 relative group">
            <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl group-hover:blur-2xl transition-all" />
            <img src={logo} alt="Logo" className="w-full h-full pixel-corners relative z-10" />
          </div>
          <CardTitle className="text-3xl font-pixel text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">
            {settings?.siteTitle || "ICT Canary"}
          </CardTitle>
          <CardDescription className="font-mono text-muted-foreground">
            {settings?.loginMessage || "Access the futuristic portal"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            data-testid="button-login-google"
            className="w-full bg-white hover:bg-gray-50 text-gray-800 border-2 border-gray-300 font-futuristic tracking-wide pixel-corners h-12"
            onClick={loginGoogle}
          >
            <svg className="mr-2 w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Sign in with Google
          </Button>
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-muted" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground font-mono">Or continue as</span>
            </div>
          </div>

          <Button 
            data-testid="button-login-guest"
            variant="outline" 
            className="w-full border-primary/50 hover:bg-primary/10 hover:text-primary font-futuristic pixel-corners h-12"
            onClick={loginGuest}
          >
            <User className="mr-2 w-5 h-5" />
            Guest User
          </Button>

          {!showAdminForm ? (
            <div className="pt-4 text-center">
              <Button 
                data-testid="button-show-admin-form"
                variant="ghost" 
                className="text-xs text-muted-foreground hover:text-accent font-mono"
                onClick={() => setShowAdminForm(true)}
              >
                [Admin Access Protocol]
              </Button>
            </div>
          ) : (
            <div className="pt-4 space-y-3 border-t border-primary/20 mt-4">
              <div className="flex items-center justify-center gap-2 text-accent">
                <Shield className="w-4 h-4" />
                <span className="text-xs font-mono">ADMIN ACCESS</span>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="admin-username" className="text-xs font-mono text-muted-foreground">Username</Label>
                <Input
                  id="admin-username"
                  data-testid="input-admin-username"
                  type="text"
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="pixel-corners border-primary/30"
                  placeholder="Enter admin username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="admin-password" className="text-xs font-mono text-muted-foreground">Password</Label>
                <Input
                  id="admin-password"
                  data-testid="input-admin-password"
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="pixel-corners border-primary/30"
                  placeholder="Enter password"
                  onKeyDown={(e) => e.key === "Enter" && handleAdminLogin()}
                />
              </div>

              {adminError && (
                <p className="text-xs text-destructive font-mono text-center">{adminError}</p>
              )}

              <div className="flex gap-2">
                <Button
                  data-testid="button-cancel-admin"
                  variant="outline"
                  className="flex-1 pixel-corners"
                  onClick={() => {
                    setShowAdminForm(false);
                    setAdminUsername("");
                    setAdminPassword("");
                    setAdminError("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  data-testid="button-login-admin"
                  className="flex-1 bg-accent hover:bg-accent/90 pixel-corners"
                  onClick={handleAdminLogin}
                >
                  <Shield className="mr-2 w-4 h-4" />
                  Login
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
