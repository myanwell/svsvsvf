import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useApp } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useEffect, useRef } from "react";
import { Send, Paperclip, X, Download, FileIcon, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { resolveMediaUrl } from "@/lib/media";

export default function Messages() {
  const { user } = useApp();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [message, setMessage] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["messages"],
    queryFn: api.messages.getAll,
    refetchInterval: 3000,
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMutation = useMutation({
    mutationFn: api.messages.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
      setMessage("");
      setSelectedFile(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Send Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: api.messages.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
      toast({
        title: "Message Deleted",
        description: "The message has been removed.",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleSend = () => {
    if (!message.trim() && !selectedFile) return;

    const formData = new FormData();
    if (message.trim()) {
      formData.append("content", message);
    }
    if (selectedFile) {
      formData.append("file", selectedFile);
    }

    sendMutation.mutate(formData);
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith("image/")) {
      return "🖼️";
    } else if (fileType.startsWith("video/")) {
      return "🎥";
    } else if (fileType.startsWith("audio/")) {
      return "🎵";
    } else if (fileType.includes("pdf")) {
      return "📄";
    }
    return "📎";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-200px)] flex flex-col">
      <div className="flex items-center justify-between border-b border-accent/30 pb-4 mb-4">
        <div>
          <h2 className="text-3xl font-pixel text-accent drop-shadow-[0_0_5px_rgba(255,0,255,0.8)]">
            Messages
          </h2>
          <p className="font-mono text-muted-foreground text-sm mt-1">
            Real-time chat with all users
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          {messages.length} messages
        </div>
      </div>

      <Card className="flex-1 flex flex-col border-2 border-accent/30 bg-card/80 pixel-corners overflow-hidden">
        <div ref={scrollRef} className="flex-1 p-4 space-y-4 overflow-y-auto">
          {messages.map((msg: any) => {
            const isCurrentUser = msg.senderId === user?.id;
            const isAdmin = msg.senderId === "admin";

            return (
              <div
                key={msg.id}
                className={`flex ${isCurrentUser ? "justify-end" : "justify-start"} group`}
                data-testid={`message-${msg.id}`}
              >
                <div className={`max-w-[70%] ${isCurrentUser ? "items-end" : "items-start"} flex flex-col gap-1`}>
                  <div className="flex items-center gap-2 px-2">
                    <span className={`text-xs font-mono ${isAdmin ? "text-accent" : "text-muted-foreground"}`}>
                      {msg.senderName}
                      {isAdmin && " 👑"}
                    </span>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {new Date(msg.timestamp).toLocaleTimeString()}
                    </span>
                    {user?.role === "admin" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => deleteMutation.mutate(msg.id)}
                        data-testid={`button-delete-message-${msg.id}`}
                      >
                        <Trash2 className="w-3 h-3 text-destructive" />
                      </Button>
                    )}
                  </div>
                  <div
                    className={`px-4 py-2 rounded-lg ${
                      isCurrentUser
                        ? "bg-accent text-white"
                        : isAdmin
                          ? "bg-primary/20 border border-accent/30"
                          : "bg-muted"
                    }`}
                  >
                    {msg.content && (
                      <p className="font-mono text-sm whitespace-pre-wrap break-words" data-testid={`text-message-content-${msg.id}`}>
                        {msg.content}
                      </p>
                    )}
                    {msg.filePath && (
                      <div className="mt-2">
                        {msg.fileType?.startsWith("image/") ? (
                          <a href={resolveMediaUrl(msg.filePath)} target="_blank" rel="noopener noreferrer">
                            <img
                              src={resolveMediaUrl(msg.filePath)}
                              alt={msg.fileName}
                              className="max-w-full rounded border border-accent/30 cursor-pointer hover:opacity-90 transition-opacity"
                              data-testid={`img-message-attachment-${msg.id}`}
                            />
                          </a>
                        ) : (
                          <a
                            href={resolveMediaUrl(msg.filePath)}
                            download={msg.fileName}
                            className="flex items-center gap-2 p-2 bg-background/50 rounded border border-accent/30 hover:bg-background/70 transition-colors"
                            data-testid={`link-message-attachment-${msg.id}`}
                          >
                            <span className="text-2xl">{getFileIcon(msg.fileType || "")}</span>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-mono truncate">{msg.fileName}</p>
                              <p className="text-[10px] text-muted-foreground">Click to download</p>
                            </div>
                            <Download className="w-4 h-4 text-accent" />
                          </a>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="border-t border-accent/30 p-4 bg-card/50">
          {selectedFile && (
            <div className="mb-2 flex items-center gap-2 p-2 bg-muted rounded-lg">
              <FileIcon className="w-4 h-4 text-accent" />
              <span className="text-xs font-mono flex-1 truncate">{selectedFile.name}</span>
              <Button
                size="sm"
                variant="ghost"
                className="h-6 w-6 p-0"
                onClick={() => setSelectedFile(null)}
                data-testid="button-remove-attachment"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
          <div className="flex gap-2">
            <Input
              type="file"
              id="file-input"
              className="hidden"
              onChange={handleFileChange}
            />
            <Button
              size="sm"
              variant="outline"
              className="pixel-corners border-accent/50"
              onClick={() => document.getElementById("file-input")?.click()}
              data-testid="button-attach-file"
            >
              <Paperclip className="w-4 h-4" />
            </Button>
            <Input
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              className="flex-1 bg-background border-accent/50 focus:border-accent font-mono"
              data-testid="input-message"
            />
            <Button
              onClick={handleSend}
              disabled={!message.trim() && !selectedFile}
              className="bg-accent hover:bg-accent/90 text-white pixel-corners font-futuristic"
              data-testid="button-send"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
