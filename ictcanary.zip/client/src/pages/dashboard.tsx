import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useApp } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Image as ImageIcon, Film, BookOpen, Upload, X, Share2, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { resolveMediaUrl } from "@/lib/media";

const isVideoMedia = (filePath: string) => /\.(mp4|webm|mov)$/i.test(filePath || "");

export default function Dashboard() {
  const { user } = useApp();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [storyDialogOpen, setStoryDialogOpen] = useState(false);
  const [pictureDialogOpen, setPictureDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [storyFile, setStoryFile] = useState<File | null>(null);
  const [pictureFile, setPictureFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [postMode, setPostMode] = useState<"post" | "reel" | "media">("post");

  const { data: stories = [] } = useQuery({
    queryKey: ["stories"],
    queryFn: api.stories.getAll,
  });

  const { data: pictures = [] } = useQuery({
    queryKey: ["pictures"],
    queryFn: api.pictures.getAll,
  });

  const userStories = stories.filter((s: any) => s.userId === user?.id);
  const userPictures = pictures.filter((p: any) => p.authorId === user?.id);

  const createStoryMutation = useMutation({
    mutationFn: api.stories.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stories"] });
      setStoryDialogOpen(false);
      setStoryFile(null);
      toast({
        title: "Story posted!",
        description: "Your story has been shared successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createPictureMutation = useMutation({
    mutationFn: api.pictures.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pictures"] });
      setPictureDialogOpen(false);
      setPictureFile(null);
      setCaption("");
      toast({
        title: "Post uploaded!",
        description: "Your post is now live.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStoryUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyFile) return;
    const formData = new FormData();
    formData.append("file", storyFile);
    createStoryMutation.mutate(formData);
  };

  const handlePictureUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pictureFile) return;
    const formData = new FormData();
    formData.append("file", pictureFile);
    formData.append("caption", caption);
    createPictureMutation.mutate(formData);
  };

  const handleCopyLink = async () => {
    try {
      const profileUrl = `${window.location.origin}/dashboard?user=${user?.id}`;
      await navigator.clipboard.writeText(profileUrl);
      setLinkCopied(true);
      toast({
        title: "Link copied!",
        description: "Profile link has been copied to clipboard.",
      });
      setTimeout(() => setLinkCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again or copy the link manually.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get("user");
    if (!userId) return;

    const scrollToProfile = () => {
      const el = document.querySelector(`[data-testid="dashboard-profile-card"]`) as HTMLElement | null;
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      el.classList.add("ring-2", "ring-primary/70");
      setTimeout(() => el.classList.remove("ring-2", "ring-primary/70"), 1800);
    };

    setTimeout(scrollToProfile, 120);
  }, []);

  return (
    <div className="space-y-6">
      <Card className="border-primary/30" data-testid="dashboard-profile-card">
        <CardHeader className="flex flex-row flex-nowrap items-center gap-3 sm:gap-4">
          <Avatar className="w-16 h-16 sm:w-20 sm:h-20 border-2 border-primary flex-shrink-0">
            <AvatarImage src={user?.avatar} alt={user?.name} />
            <AvatarFallback className="bg-primary/20 text-primary text-xl sm:text-2xl">
              <User className="w-8 h-8 sm:w-10 sm:h-10" />
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 overflow-hidden">
            <CardTitle className="text-lg sm:text-2xl font-pixel truncate">{user?.name}</CardTitle>
            <p className="text-xs sm:text-sm text-muted-foreground truncate">{user?.email}</p>
            <p className="text-[10px] sm:text-xs text-primary font-mono mt-1">{user?.role?.toUpperCase()}</p>
          </div>
          <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon" className="flex-shrink-0 h-9 w-9 sm:h-10 sm:w-10" data-testid="button-share-profile">
                <Share2 className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Share Profile</DialogTitle>
              </DialogHeader>
              <div className="flex flex-col items-center gap-4 py-4">
                <Avatar className="w-24 h-24 border-4 border-primary">
                  <AvatarImage src={user?.avatar} alt={user?.name} />
                  <AvatarFallback className="bg-primary/20 text-primary text-3xl">
                    <User className="w-12 h-12" />
                  </AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h3 className="text-xl font-pixel">{user?.name}</h3>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
                <Button 
                  onClick={handleCopyLink} 
                  className="w-full gap-2"
                  data-testid="button-copy-link"
                >
                  {linkCopied ? (
                    <>
                      <Check className="w-4 h-4" />
                      Link Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy Link
                    </>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Dialog open={storyDialogOpen} onOpenChange={setStoryDialogOpen}>
          <DialogTrigger asChild>
            <Button className="h-20 flex flex-col gap-2" data-testid="button-create-story">
              <BookOpen className="w-6 h-6" />
              <span>Create Story</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Story</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleStoryUpload} className="space-y-4">
              <div>
                <Label htmlFor="story-file">Upload Image or Video</Label>
                <Input
                  id="story-file"
                  type="file"
                  accept="image/*,video/mp4"
                  onChange={(e) => setStoryFile(e.target.files?.[0] || null)}
                  required
                  data-testid="input-story-file"
                />
              </div>
              {storyFile && (
                <div className="relative">
                  {storyFile.type.startsWith('image/') ? (
                    <img
                      src={URL.createObjectURL(storyFile)}
                      alt="Preview"
                      className="w-full rounded-lg max-h-64 object-cover"
                    />
                  ) : (
                    <video
                      src={URL.createObjectURL(storyFile)}
                      className="w-full rounded-lg max-h-64"
                      controls
                    />
                  )}
                </div>
              )}
              <Button type="submit" disabled={createStoryMutation.isPending} data-testid="button-submit-story">
                {createStoryMutation.isPending ? "Posting..." : "Post Story"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={pictureDialogOpen} onOpenChange={setPictureDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="h-20 flex flex-col gap-2"
              variant="outline"
              onClick={() => setPostMode("post")}
              data-testid="button-create-post"
            >
              <ImageIcon className="w-6 h-6" />
              <span>Create Post</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {postMode === "reel" ? "Create Reel" : postMode === "media" ? "Upload Media" : "Create Post"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handlePictureUpload} className="space-y-4">
              <div>
                <Label htmlFor="picture-file">
                  {postMode === "reel" ? "Upload Reel Video" : "Upload Image/Video"}
                </Label>
                <Input
                  id="picture-file"
                  type="file"
                  accept={postMode === "reel" ? "video/mp4,video/webm,video/quicktime,.mov" : "image/*,video/mp4,video/webm,video/quicktime,.mov"}
                  onChange={(e) => setPictureFile(e.target.files?.[0] || null)}
                  required
                  data-testid="input-post-file"
                />
              </div>
              {pictureFile && (
                pictureFile.type.startsWith("video/") ? (
                  <video
                    src={URL.createObjectURL(pictureFile)}
                    className="w-full rounded-lg max-h-64"
                    controls
                  />
                ) : (
                  <img
                    src={URL.createObjectURL(pictureFile)}
                    alt="Preview"
                    className="w-full rounded-lg max-h-64 object-contain bg-muted/20"
                  />
                )
              )}
              <div>
                <Label htmlFor="caption">Caption</Label>
                <Textarea
                  id="caption"
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder={postMode === "reel" ? "Write a reel caption..." : "Write a caption..."}
                  data-testid="input-post-caption"
                />
              </div>
              <Button type="submit" disabled={createPictureMutation.isPending} data-testid="button-submit-post">
                {createPictureMutation.isPending ? "Posting..." : postMode === "reel" ? "Post Reel" : "Post"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <Button
          className="h-20 flex flex-col gap-2"
          variant="outline"
          onClick={() => {
            setPostMode("reel");
            setPictureDialogOpen(true);
          }}
          data-testid="button-create-reel"
        >
          <Film className="w-6 h-6" />
          <span>Create Reel</span>
        </Button>

        <Button
          className="h-20 flex flex-col gap-2"
          variant="outline"
          onClick={() => {
            setPostMode("media");
            setPictureDialogOpen(true);
          }}
          data-testid="button-upload-media"
        >
          <Upload className="w-6 h-6" />
          <span>Upload Media</span>
        </Button>
      </div>

      <Tabs defaultValue="stories" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="stories" data-testid="tab-stories">My Stories ({userStories.length})</TabsTrigger>
          <TabsTrigger value="posts" data-testid="tab-posts">My Posts ({userPictures.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="stories" className="space-y-4">
          {userStories.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                You haven't posted any stories yet.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {userStories.map((story: any) => (
                <Card key={story.id} className="overflow-hidden" data-testid={`story-${story.id}`}>
                  <div className="aspect-[9/16] relative">
                    {story.filePath.match(/\.(mp4|webm)$/i) ? (
                      <video
                        src={resolveMediaUrl(story.filePath)}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <img
                        src={resolveMediaUrl(story.filePath)}
                        alt="Story"
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="posts" className="space-y-4">
          {userPictures.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                You haven't posted anything yet.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {userPictures.map((pic: any) => (
                <Card key={pic.id} className="overflow-hidden" data-testid={`post-${pic.id}`}>
                  {isVideoMedia(pic.filePath) ? (
                    <video
                      src={resolveMediaUrl(pic.filePath)}
                      className="w-full aspect-video object-contain bg-black/50"
                      controls
                      preload="metadata"
                    />
                  ) : (
                    <img
                      src={resolveMediaUrl(pic.filePath)}
                      alt={pic.caption}
                      className="w-full aspect-video object-contain bg-muted/20"
                    />
                  )}
                  <CardContent className="p-4">
                    <p className="text-sm">{pic.caption}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
