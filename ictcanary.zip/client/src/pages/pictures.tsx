import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Gamepad2, Play } from "lucide-react";
import { resolveMediaUrl } from "@/lib/media";

export default function Games() {
  const { data: games = [], isLoading } = useQuery({
    queryKey: ["games"],
    queryFn: api.games.getAll,
  });
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 border-b border-accent/30 pb-4">
        <Gamepad2 className="w-8 h-8 text-accent" />
        <h2 className="text-3xl font-pixel text-accent">Games</h2>
      </div>

      {games.length === 0 ? (
        <Card className="pixel-corners border-accent/30">
          <CardContent className="p-6 text-center font-mono text-muted-foreground">
            No games yet. Admin can add games from the Admin panel.
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {games.map((game: any) => (
            <Card key={game.id} className="pixel-corners border-primary/30">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <img
                    src={resolveMediaUrl(game.logoPath)}
                    alt={game.title}
                    className="w-12 h-12 object-cover rounded border border-primary/30"
                  />
                  <CardTitle className="font-futuristic text-lg line-clamp-1">{game.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm font-mono text-muted-foreground line-clamp-3">{game.description}</p>
                <Button
                  className="w-full pixel-corners"
                  onClick={() => setLocation(`/games/${game.id}`)}
                  data-testid={`button-play-game-${game.id}`}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Play
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
