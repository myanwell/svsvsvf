﻿import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { useApp } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MessageCircle, Send, Share2, ThumbsUp, Trash2, User } from "lucide-react";
import { resolveMediaUrl } from "@/lib/media";

type ReactionKey = "like" | "heart" | "haha" | "sad" | "care" | "wow" | "angry";

const reactionOptions: Array<{ key: ReactionKey; emoji: string; label: string }> = [
  { key: "like", emoji: "👍", label: "Like" },
  { key: "heart", emoji: "❤️", label: "Heart" },
  { key: "haha", emoji: "😂", label: "Haha" },
  { key: "sad", emoji: "😢", label: "Sad" },
  { key: "care", emoji: "🤗", label: "Care" },
  { key: "wow", emoji: "😮", label: "Wow" },
  { key: "angry", emoji: "😡", label: "Angry" },
];

const normalizeReaction = (reaction: string | null | undefined): ReactionKey | undefined => {
  if (!reaction) return undefined;
  if (reaction === "love") return "heart";
  const allowed: ReactionKey[] = ["like", "heart", "haha", "sad", "care", "wow", "angry"];
  return allowed.includes(reaction as ReactionKey) ? (reaction as ReactionKey) : undefined;
};

export default function Students() {
  const { user } = useApp();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [content, setContent] = useState("");
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [reactionDetailsMessageId, setReactionDetailsMessageId] = useState<string | null>(null);
  const [commentsMessageId, setCommentsMessageId] = useState<string | null>(null);
  const [pickerMessageId, setPickerMessageId] = useState<string | null>(null);

  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressTriggeredRef = useRef(false);
  const pressHandledRef = useRef(false);

  const { data: confessions = [], isLoading } = useQuery({
    queryKey: ["anonymous-messages"],
    queryFn: api.anonymousMessages.getAll,
  });

  const { data: allReactions = [] } = useQuery({
    queryKey: ["anonymous-message-reactions", confessions.map((c: any) => c.id).join(",")],
    queryFn: async () => {
      const results = await Promise.all(
        confessions.map((c: any) => api.anonymousMessageReactions.getByMessageId(c.id))
      );
      return results.flat();
    },
    enabled: confessions.length > 0,
  });

  const { data: allComments = [] } = useQuery({
    queryKey: ["anonymous-message-comments", confessions.map((c: any) => c.id).join(",")],
    queryFn: async () => {
      const results = await Promise.all(
        confessions.map((c: any) => api.anonymousMessageComments.getByMessageId(c.id))
      );
      return results.flat();
    },
    enabled: confessions.length > 0,
  });

  const createConfessionMutation = useMutation({
    mutationFn: (text: string) => api.anonymousMessages.create(text),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["anonymous-messages"] });
      setContent("");
      toast({ title: "Confession posted", description: "Your identity is hidden from users." });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to post", description: error.message, variant: "destructive" });
    },
  });

  const reactionMutation = useMutation({
    mutationFn: ({ messageId, reaction }: { messageId: string; reaction: ReactionKey }) =>
      api.anonymousMessageReactions.set(messageId, reaction),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["anonymous-message-reactions"] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: ({ messageId, text }: { messageId: string; text: string }) =>
      api.anonymousMessageComments.create(messageId, text),
    onSuccess: (_data, vars) => {
      setCommentInputs((prev) => ({ ...prev, [vars.messageId]: "" }));
      queryClient.invalidateQueries({ queryKey: ["anonymous-message-comments"] });
    },
  });

  const deleteConfessionMutation = useMutation({
    mutationFn: (id: string) => api.anonymousMessages.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["anonymous-messages"] });
      queryClient.invalidateQueries({ queryKey: ["anonymous-message-reactions"] });
      queryClient.invalidateQueries({ queryKey: ["anonymous-message-comments"] });
      toast({ title: "Confession deleted", description: "Your confession was removed." });
    },
    onError: (error: Error) => {
      toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    },
  });

  const handleSendConfession = () => {
    if (!content.trim()) return;
    if (!user || user.role === "guest") {
      toast({
        title: "Login required",
        description: "Only logged in users can post anonymous confessions.",
        variant: "destructive",
      });
      return;
    }
    createConfessionMutation.mutate(content.trim());
  };

  const requireLoginForInteract = (): boolean => {
    if (!user || user.role === "guest") {
      toast({
        title: "Login required",
        description: "Only logged in users can use this feature.",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const handleReactionPressStart = (messageId: string) => {
    pressHandledRef.current = false;
    longPressTriggeredRef.current = false;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);

    longPressTimerRef.current = setTimeout(() => {
      longPressTriggeredRef.current = true;
      setPickerMessageId(messageId);
    }, 450);
  };

  const handleReactionPressEnd = (messageId: string) => {
    if (pressHandledRef.current) return;
    pressHandledRef.current = true;

    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }

    if (!longPressTriggeredRef.current) {
      if (!requireLoginForInteract()) return;
      const ownReaction = normalizeReaction(
        allReactions.find((r: any) => r.messageId === messageId && String(r.userId) === String(user?.id))?.reaction
      );
      reactionMutation.mutate({ messageId, reaction: ownReaction ?? "like" });
    }

    longPressTriggeredRef.current = false;
  };

  const handleReactionPressCancel = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    longPressTriggeredRef.current = false;
    pressHandledRef.current = true;
  };

  const handleShare = async (messageId: string) => {
    try {
      const url = `${window.location.origin}/anony?confession=${messageId}`;
      await navigator.clipboard.writeText(url);
      toast({ title: "Link copied", description: "Confession link copied to clipboard." });
    } catch {
      toast({ title: "Share failed", description: "Could not copy link.", variant: "destructive" });
    }
  };

  const activeComments = commentsMessageId
    ? allComments.filter((c: any) => c.messageId === commentsMessageId)
    : [];

  useEffect(() => {
    if (!confessions.length) return;
    const params = new URLSearchParams(window.location.search);
    const confessionId = params.get("confession");
    if (!confessionId) return;

    const scrollToConfession = () => {
      const el = document.querySelector(`[data-testid="confession-${confessionId}"]`) as HTMLElement | null;
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.add("ring-2", "ring-primary/70");
      setTimeout(() => el.classList.remove("ring-2", "ring-primary/70"), 1800);
    };

    setTimeout(scrollToConfession, 120);
  }, [confessions.length]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="rounded-2xl p-4 sm:p-8">
        <div className="mx-auto max-w-2xl space-y-4">
          <div className="rounded-[24px] border border-white/40 bg-transparent p-4 backdrop-blur-[2px] transition-all duration-300 hover:border-white/60">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="h-11 w-11 border border-white/40 bg-white/20">
                <AvatarImage src={resolveMediaUrl(user?.avatar)} alt={user?.name || "User"} />
                <AvatarFallback className="bg-white/20 text-white">
                  <User className="h-5 w-5" />
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-white">@{user?.name?.toLowerCase().replace(/\s+/g, "") || "anonymous"}</p>
                <p className="text-white font-bold">Send me anonymous messages!</p>
              </div>
            </div>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Type your confession..."
              className="min-h-[140px] bg-transparent border border-white/30 text-white placeholder:text-white/75 focus-visible:ring-white/50"
              data-testid="input-confession-content"
            />
          </div>

          <p className="text-center text-white font-medium">anonymous q&amp;a</p>
          <div
            className={`transition-all duration-300 ease-out ${
              content.trim() ? "opacity-100 translate-y-0 max-h-20" : "opacity-0 -translate-y-2 max-h-0 overflow-hidden"
            }`}
          >
            <Button
              onClick={handleSendConfession}
              disabled={createConfessionMutation.isPending || !user || user.role === "guest" || !content.trim()}
              className="w-full h-14 rounded-full bg-black text-white hover:bg-black/90 text-xl font-bold shadow-xl transition-transform duration-300 hover:scale-[1.01] active:scale-[0.99]"
              data-testid="button-send-confession"
            >
              {createConfessionMutation.isPending ? "Sending..." : "Send!"}
            </Button>
          </div>
          {(!user || user.role === "guest") && (
            <p className="text-center text-white/90 text-sm">Log in to send a confession.</p>
          )}
        </div>
      </div>

      {confessions.length === 0 ? (
        <Card className="mx-auto max-w-2xl rounded-3xl border border-primary/35 bg-transparent backdrop-blur-[1px]">
          <CardContent className="p-8 text-center text-muted-foreground">No confessions yet.</CardContent>
        </Card>
      ) : (
        <div className="mx-auto max-w-2xl space-y-4">
          {confessions.map((confession: any, index: number) => {
            const reactionsForMessage = allReactions.filter((r: any) => r.messageId === confession.id);
            const totalReactions = reactionsForMessage.length;
            const ownReaction = normalizeReaction(
              reactionsForMessage.find((r: any) => String(r.userId) === String(user?.id))?.reaction
            );
            const totalComments = allComments.filter((c: any) => c.messageId === confession.id).length;
            const ownReactionMeta = ownReaction
              ? reactionOptions.find((o) => o.key === ownReaction)
              : undefined;
            const reactionUsers = reactionsForMessage.map((r: any) => ({ id: r.userId, name: r.userName }));
            const uniqueReactionUsers = reactionUsers.filter(
              (u, i, arr) => arr.findIndex((x) => x.id === u.id) === i
            );

            const reactionSummary = (() => {
              const totalUsers = uniqueReactionUsers.length;
              if (totalUsers === 0) return "";
              const youReacted = !!user && uniqueReactionUsers.some((u) => u.id === user.id);
              const others = uniqueReactionUsers.filter((u) => u.id !== user?.id);
              if (youReacted) {
                if (totalUsers === 1) return "You";
                if (totalUsers === 2) return `You and ${others[0]?.name || "1 other"}`;
                return `You, ${others[0]?.name || "someone"} and ${totalUsers - 2} other${totalUsers - 2 > 1 ? "s" : ""}`;
              }
              if (totalUsers === 1) return uniqueReactionUsers[0].name;
              if (totalUsers === 2) return `${uniqueReactionUsers[0].name} and ${uniqueReactionUsers[1].name}`;
              return `${uniqueReactionUsers[0].name}, ${uniqueReactionUsers[1].name} and ${totalUsers - 2} others`;
            })();

            return (
              <Card
                key={confession.id}
                className="rounded-3xl border border-primary/35 bg-transparent backdrop-blur-[1px] shadow-[0_8px_22px_rgba(0,0,0,0.22)] transition-all duration-300 hover:border-primary/60 hover:shadow-[0_10px_26px_rgba(0,0,0,0.32)] animate-in fade-in-0 slide-in-from-bottom-3 duration-500"
                style={{ animationDelay: `${Math.min(index * 40, 240)}ms` }}
                data-testid={`confession-${confession.id}`}
              >
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-mono text-rose-600">Anonymous #{confessions.length - index}</CardTitle>
                  {(confession.isOwner || user?.role === "admin") && (
                    <button
                      onClick={() => deleteConfessionMutation.mutate(confession.id)}
                      className="h-8 w-8 rounded-full border border-destructive/40 text-destructive flex items-center justify-center hover:bg-destructive/10 transition-colors"
                      data-testid={`button-delete-confession-${confession.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </CardHeader>

                <CardContent className="space-y-2">
                  <p className="text-sm whitespace-pre-wrap break-words text-foreground/95">{confession.content}</p>
                  <p className="text-xs text-primary/70 font-mono">
                    {formatDistanceToNow(new Date(confession.createdAt), { addSuffix: true })}
                  </p>

                  {pickerMessageId === confession.id && (
                    <div className="inline-flex gap-1 p-1.5 rounded-full border border-primary/35 bg-background/90 backdrop-blur-sm animate-in fade-in-0 zoom-in-95 duration-200">
                      {reactionOptions.map((option) => (
                        <button
                          key={`${confession.id}-picker-${option.key}`}
                          className="h-8 w-8 rounded-full border border-primary/30 hover:border-primary/70 hover:scale-110 transition-all"
                          title={option.label}
                          onClick={() => {
                            if (!requireLoginForInteract()) return;
                            reactionMutation.mutate({ messageId: confession.id, reaction: option.key });
                            setPickerMessageId(null);
                          }}
                          data-testid={`button-picker-${option.key}-${confession.id}`}
                        >
                          {option.emoji}
                        </button>
                      ))}
                    </div>
                  )}

                  {totalReactions > 0 && (
                    <button
                      onClick={() => setReactionDetailsMessageId(confession.id)}
                      className="mt-2 inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
                      data-testid={`button-reaction-summary-${confession.id}`}
                    >
                      <span className="inline-flex items-center">
                        {Array.from(
                          new Set(
                            reactionsForMessage
                              .map((r: any) => normalizeReaction(r.reaction))
                              .filter(Boolean)
                          )
                        )
                          .slice(0, 3)
                          .map((key, i) => {
                            const reaction = reactionOptions.find((o) => o.key === key);
                            if (!reaction) return null;
                            return (
                              <span
                                key={`${confession.id}-summary-${key}`}
                                className={`h-4 w-4 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] ${i > 0 ? "-ml-1" : ""}`}
                              >
                                {reaction.emoji}
                              </span>
                            );
                          })}
                      </span>
                      <span>{reactionSummary} · {totalReactions}</span>
                    </button>
                  )}

                  <div className="mt-1 grid grid-cols-3 border-t border-primary/20 pt-1">
                    <button
                      onMouseDown={() => handleReactionPressStart(confession.id)}
                      onMouseUp={() => handleReactionPressEnd(confession.id)}
                      onMouseLeave={handleReactionPressCancel}
                      onTouchStart={() => handleReactionPressStart(confession.id)}
                      onTouchEnd={() => handleReactionPressEnd(confession.id)}
                      onTouchCancel={handleReactionPressCancel}
                      className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                      data-testid={`button-love-${confession.id}`}
                    >
                      {ownReactionMeta ? <span>{ownReactionMeta.emoji}</span> : <ThumbsUp className="h-4 w-4" />}
                      <span className={ownReactionMeta ? "text-primary font-semibold" : ""}>
                        {ownReactionMeta?.key === "heart" ? "Love" : ownReactionMeta?.label || "Like"}
                      </span>
                    </button>
                    <button
                      onClick={() => setCommentsMessageId(confession.id)}
                      className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                      data-testid={`button-comments-${confession.id}`}
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span>Comment{totalComments > 0 ? ` (${totalComments})` : ""}</span>
                    </button>
                    <button
                      onClick={() => handleShare(confession.id)}
                      className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                      data-testid={`button-share-${confession.id}`}
                    >
                      <Share2 className="h-4 w-4" />
                      <span>Share</span>
                    </button>
                  </div>

                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!reactionDetailsMessageId} onOpenChange={(open) => !open && setReactionDetailsMessageId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reactions</DialogTitle>
          </DialogHeader>
          {(() => {
            if (!reactionDetailsMessageId) return null;
            const reactionsForMessage = allReactions.filter((r: any) => r.messageId === reactionDetailsMessageId);
            const total = reactionsForMessage.length;
            const grouped = reactionOptions
              .map((option) => ({
                ...option,
                count: reactionsForMessage.filter((r: any) => r.reaction === option.key).length,
              }))
              .filter((g) => g.count > 0)
              .sort((a, b) => b.count - a.count);

            return (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground font-mono">Total reactions: {total}</p>
                <div className="flex flex-wrap gap-2">
                  {grouped.map((g) => (
                    <div key={`count-${g.key}`} className="rounded-full border border-primary/30 px-3 py-1 text-sm">
                      {g.emoji} {g.label} · {g.count}
                    </div>
                  ))}
                </div>
                <div className="max-h-72 overflow-y-auto space-y-2">
                  {reactionsForMessage.map((r: any) => {
                    const emoji = reactionOptions.find((o) => o.key === normalizeReaction(r.reaction))?.emoji || "🙂";
                    return (
                      <div key={r.id} className="flex items-center justify-between rounded-lg border border-primary/20 px-3 py-2">
                        <span className="text-sm">{r.userName}</span>
                        <span className="text-lg">{emoji}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={!!commentsMessageId} onOpenChange={(open) => !open && setCommentsMessageId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Comments</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="max-h-72 overflow-y-auto space-y-2">
              {activeComments.length === 0 && <p className="text-sm text-muted-foreground">No comments yet.</p>}
              {activeComments.map((comment: any) => (
                <div key={comment.id} className="rounded-lg border border-primary/20 px-3 py-2">
                  <p className="text-xs font-semibold text-primary/90">{comment.userName}</p>
                  <p className="text-sm">{comment.content}</p>
                  <p className="text-[10px] text-primary/70 font-mono">
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                  </p>
                </div>
              ))}
            </div>
            {commentsMessageId && (
              <div className="flex gap-2">
                <input
                  value={commentInputs[commentsMessageId] || ""}
                  onChange={(e) =>
                    setCommentInputs((prev) => ({
                      ...prev,
                      [commentsMessageId]: e.target.value,
                    }))
                  }
                  placeholder="Write a comment..."
                  className="flex-1 px-3 py-2 rounded-lg border border-primary/35 bg-transparent text-sm outline-none focus:border-primary"
                  data-testid="input-comment-modal"
                />
                <Button
                  size="icon"
                  disabled={!commentInputs[commentsMessageId]?.trim() || commentMutation.isPending}
                  onClick={() =>
                    commentMutation.mutate({
                      messageId: commentsMessageId,
                      text: (commentInputs[commentsMessageId] || "").trim(),
                    })
                  }
                  className="transition-transform duration-200 hover:scale-105 active:scale-95"
                  data-testid="button-comment-modal"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}



