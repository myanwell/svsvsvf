import { useApp } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Info, Phone, Shield, Github, LogOut } from "lucide-react";

export default function More() {
  const { logout } = useApp();

  const links = [
    { icon: Info, label: "About Us", href: "#" },
    { icon: Phone, label: "Contact", href: "#" },
    { icon: Shield, label: "Privacy Policy", href: "#" },
    { icon: Github, label: "Source Code", href: "#" },
  ];

  return (
    <div className="space-y-6 max-w-md mx-auto">
      <h2 className="text-3xl font-pixel text-secondary text-center mb-8 drop-shadow-[0_0_5px_rgba(0,243,255,0.8)]">
        System Menu
      </h2>

      <div className="grid gap-4">
        {links.map((link, i) => (
          <Card key={i} className="bg-card/50 border border-secondary/30 hover:border-secondary hover:bg-secondary/10 transition-all cursor-pointer pixel-corners group">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-2 bg-secondary/20 rounded-none group-hover:bg-secondary group-hover:text-background transition-colors">
                <link.icon className="w-5 h-5" />
              </div>
              <span className="font-futuristic text-lg flex-1">{link.label}</span>
              <span className="font-mono text-secondary opacity-0 group-hover:opacity-100 transition-opacity">&gt;&gt;</span>
            </CardContent>
          </Card>
        ))}

        <Button 
          variant="destructive" 
          className="w-full mt-8 pixel-corners font-futuristic h-12"
          onClick={logout}
        >
          <LogOut className="mr-2 w-4 h-4" /> Terminate Session
        </Button>
      </div>
      
      <div className="text-center mt-12">
        <p className="text-[10px] font-mono text-muted-foreground">
          ICT Canary System v1.0.4<br/>
          Pixel Protocol Active
        </p>
      </div>
    </div>
  );
}
