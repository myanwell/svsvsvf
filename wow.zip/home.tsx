import { useState, useEffect, useRef, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useApp } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, User, MessageCircle, Share2, Copy, Check, ChevronLeft, ChevronRight, Trash2, Send, Smile, MoreVertical, X, Eye, Flag, Edit, ThumbsUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { resolveMediaUrl } from "@/lib/media";

type ReactionKey = "like" | "heart" | "haha" | "sad" | "care" | "wow" | "angry";

const reactionOptions: Array<{ key: ReactionKey; emoji: string; label: string }> = [
  { key: "like", emoji: "👍", label: "Like" },
  { key: "heart", emoji: "❤️", label: "Heart" },
  { key: "haha", emoji: "😂", label: "Haha" },
  { key: "sad", emoji: "😢", label: "Sad" },
  { key: "care", emoji: "🤗", label: "Care" },
  { key: "wow", emoji: "😮", label: "Wow" },
  { key: "angry", emoji: "😡", label: "Angry" },
];

const normalizeReaction = (reaction: string | null | undefined): ReactionKey | undefined => {
  if (!reaction) return undefined;
  if (reaction === "love") return "heart";
  const allowed: ReactionKey[] = ["like", "heart", "haha", "sad", "care", "wow", "angry"];
  return allowed.includes(reaction as ReactionKey) ? (reaction as ReactionKey) : undefined;
};

const isVideoMedia = (filePath: string) => /\.(mp4|webm|mov)$/i.test(filePath || "");

export default function Home() {
  const { user } = useApp();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [createStoryOpen, setCreateStoryOpen] = useState(false);
  const [storyFile, setStoryFile] = useState<File | null>(null);
  const [selectedStory, setSelectedStory] = useState<any>(null);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [allStoriesForViewer, setAllStoriesForViewer] = useState<any[]>([]);
  const [commentDialogOpen, setCommentDialogOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [commentText, setCommentText] = useState("");
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [sharePost, setSharePost] = useState<any>(null);
  const [linkCopied, setLinkCopied] = useState(false);
  const [storyMessage, setStoryMessage] = useState("");
  const [recentlyHiddenPost, setRecentlyHiddenPost] = useState<string | null>(null);
  const [viewersDialogOpen, setViewersDialogOpen] = useState(false);
  const [selectedStoryForViewers, setSelectedStoryForViewers] = useState<any>(null);
  const [deleteStoryConfirmOpen, setDeleteStoryConfirmOpen] = useState(false);
  const [pickerPostId, setPickerPostId] = useState<string | null>(null);
  const [reactionDetailsPostId, setReactionDetailsPostId] = useState<string | null>(null);
  const [canScrollStoriesLeft, setCanScrollStoriesLeft] = useState(false);
  const [canScrollStoriesRight, setCanScrollStoriesRight] = useState(false);

  const longPressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressTriggeredRef = useRef(false);
  const pressHandledRef = useRef(false);
  const storiesStripRef = useRef<HTMLDivElement | null>(null);

  const { data: allStories = [] } = useQuery({
    queryKey: ["stories"],
    queryFn: api.stories.getAll,
  });

  const stories = allStories;

  const { data: pictures = [] } = useQuery({
    queryKey: ["pictures"],
    queryFn: api.pictures.getAll,
  });

  // Fetch user avatars for all post authors
  const uniqueAuthorIds: string[] = Array.from(new Set(pictures.map((p: any) => p.authorId as string)));
  const { data: authorData = {} } = useQuery({
    queryKey: ["authors", uniqueAuthorIds],
    queryFn: async () => {
      const authors: any = {};
      await Promise.all(
        uniqueAuthorIds.map(async (authorId: string) => {
          try {
            const userData = await api.users.getById(authorId);
            authors[authorId] = userData;
          } catch (error) {
            // User might not exist in database (e.g., guest users)
            authors[authorId] = null;
          }
        })
      );
      return authors;
    },
    enabled: uniqueAuthorIds.length > 0,
  });

  // Merge avatar data into pictures
  const picturesWithAvatars = pictures.map((pic: any) => ({
    ...pic,
    authorAvatar: authorData[pic.authorId]?.avatar,
  }));

  const { data: users = [] } = useQuery({
    queryKey: ["users-all"],
    queryFn: async () => {
      const uniqueUsers = new Map();
      pictures.forEach((pic: any) => {
        if (!uniqueUsers.has(pic.authorId)) {
          uniqueUsers.set(pic.authorId, {
            id: pic.authorId,
            name: pic.author,
            avatar: authorData[pic.authorId]?.avatar,
          });
        }
      });
      return Array.from(uniqueUsers.values());
    },
    enabled: pictures.length > 0 && Object.keys(authorData).length > 0,
  });

  const createStoryMutation = useMutation({
    mutationFn: api.stories.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stories"] });
      setCreateStoryOpen(false);
      setStoryFile(null);
      toast({
        title: "Story posted!",
        description: "Your story has been shared successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: ({ postId, reaction }: { postId: string; reaction: ReactionKey }) =>
      api.likes.create(postId, reaction),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["likes"] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: ({ postId, content }: { postId: string; content: string }) =>
      api.comments.create(postId, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comments"] });
      setCommentText("");
      toast({
        title: "Comment added",
        description: "Your comment has been posted.",
      });
    },
  });

  const shareMutation = useMutation({
    mutationFn: api.shares.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["shares"] });
      toast({
        title: "Post shared!",
        description: "This post has been shared.",
      });
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: api.pictures.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pictures"] });
      toast({
        title: "Post deleted",
        description: "Your post has been deleted successfully.",
      });
    },
  });

  const deleteStoryMutation = useMutation({
    mutationFn: api.stories.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["stories"] });
      setSelectedStory(null);
      toast({
        title: "Story deleted",
        description: "Your story has been deleted successfully.",
      });
    },
  });

  const reactToStoryMutation = useMutation({
    mutationFn: ({ storyId, reaction }: { storyId: string; reaction: string }) =>
      api.storyReactions.create(storyId, reaction),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["story-reactions"] });
      toast({
        title: "Reacted!",
        description: "Your reaction has been added.",
      });
    },
  });

  const { data: hiddenPosts = [] } = useQuery({
    queryKey: ["hidden-posts"],
    queryFn: api.hiddenPosts.getAll,
    enabled: !!user && user.role !== "guest",
  });

  const hidePostMutation = useMutation({
    mutationFn: api.hiddenPosts.create,
    onSuccess: (_data, postId) => {
      queryClient.invalidateQueries({ queryKey: ["hidden-posts"] });
      setRecentlyHiddenPost(postId);
      toast({
        title: "Post hidden",
        description: "You can undo this action.",
        action: <Button variant="outline" size="sm" onClick={() => undoHidePost(postId)} data-testid="button-undo-hide">Undo</Button>,
      });
      setTimeout(() => setRecentlyHiddenPost(null), 5000);
    },
    onError: (error) => {
      toast({
        title: "Failed to hide post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const unhidePostMutation = useMutation({
    mutationFn: api.hiddenPosts.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["hidden-posts"] });
      setRecentlyHiddenPost(null);
    },
  });

  const reportPostMutation = useMutation({
    mutationFn: api.reportedPosts.create,
    onSuccess: () => {
      toast({
        title: "Post reported",
        description: "Thank you for reporting this post.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to report post",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createStoryViewMutation = useMutation({
    mutationFn: api.storyViews.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["story-views"] });
    },
  });

  const { data: storyViews = [] } = useQuery({
    queryKey: ["story-views", selectedStory?.id],
    queryFn: () => selectedStory ? api.storyViews.getByStoryId(selectedStory.id) : Promise.resolve([]),
    enabled: !!selectedStory && selectedStory.userId === user?.id,
  });

  const { data: storyReactions = [] } = useQuery({
    queryKey: ["story-reactions", selectedStory?.id],
    queryFn: () => selectedStory ? api.storyReactions.getByStoryId(selectedStory.id) : Promise.resolve([]),
    enabled: !!selectedStory && selectedStory.userId === user?.id,
  });

  const { data: viewersStoryViews = [] } = useQuery({
    queryKey: ["story-views-viewers", selectedStoryForViewers?.id],
    queryFn: () => selectedStoryForViewers ? api.storyViews.getByStoryId(selectedStoryForViewers.id) : Promise.resolve([]),
    enabled: !!selectedStoryForViewers,
  });

  const { data: viewersStoryReactions = [] } = useQuery({
    queryKey: ["story-reactions-viewers", selectedStoryForViewers?.id],
    queryFn: () => selectedStoryForViewers ? api.storyReactions.getByStoryId(selectedStoryForViewers.id) : Promise.resolve([]),
    enabled: !!selectedStoryForViewers,
  });

  const undoHidePost = (postId: string) => {
    unhidePostMutation.mutate(postId);
  };

  const handleHidePost = (postId: string) => {
    hidePostMutation.mutate(postId);
  };

  const handleReportPost = (postId: string) => {
    reportPostMutation.mutate(postId);
  };

  const handleStoryUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyFile) return;
    const formData = new FormData();
    formData.append("file", storyFile);
    createStoryMutation.mutate(formData);
  };

  const userStoriesMap = useMemo(() => {
    const map = new Map<string, any[]>();
    stories.forEach((story: any) => {
      if (!map.has(story.userId)) {
        map.set(story.userId, []);
      }
      map.get(story.userId)!.push(story);
    });
    return map;
  }, [stories]);

  const approvedPosts = useMemo(() => {
    const hidden = new Set((hiddenPosts as any[]).map((hp: any) => hp.postId));
    return picturesWithAvatars.filter((p: any) => !hidden.has(p.id));
  }, [picturesWithAvatars, hiddenPosts]);

  const allUsers = users || [];
  const usersWithoutStories = useMemo(
    () => allUsers.filter((u: any) => !userStoriesMap.has(u.id) && u.id !== user?.id),
    [allUsers, userStoriesMap, user?.id]
  );

  const { data: allLikes = [] } = useQuery({
    queryKey: ["likes"],
    queryFn: async () => {
      const likesData = await Promise.all(
        approvedPosts.map((post: any) => api.likes.getByPostId(post.id))
      );
      return likesData.flat();
    },
    enabled: approvedPosts.length > 0,
  });

  const { data: allComments = [] } = useQuery({
    queryKey: ["comments"],
    queryFn: async () => {
      const commentsData = await Promise.all(
        approvedPosts.map((post: any) => api.comments.getByPostId(post.id))
      );
      return commentsData.flat();
    },
    enabled: approvedPosts.length > 0,
  });

  const { data: allShares = [] } = useQuery({
    queryKey: ["shares"],
    queryFn: async () => {
      const sharesData = await Promise.all(
        approvedPosts.map((post: any) => api.shares.getByPostId(post.id))
      );
      return sharesData.flat();
    },
    enabled: approvedPosts.length > 0,
  });

  const likesByPostId = useMemo(() => {
    const map: Record<string, any[]> = {};
    for (const like of allLikes as any[]) {
      const key = like.postId;
      if (!map[key]) map[key] = [];
      map[key].push(like);
    }
    return map;
  }, [allLikes]);

  const commentsByPostId = useMemo(() => {
    const map: Record<string, any[]> = {};
    for (const comment of allComments as any[]) {
      const key = comment.postId;
      if (!map[key]) map[key] = [];
      map[key].push(comment);
    }
    return map;
  }, [allComments]);

  const requireLoginForInteract = (): boolean => {
    if (!user || user.role === "guest") {
      toast({
        title: "Login required",
        description: "Only logged in users can use this feature.",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const handleReactionPressStart = (postId: string) => {
    pressHandledRef.current = false;
    longPressTriggeredRef.current = false;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      longPressTriggeredRef.current = true;
      setPickerPostId(postId);
    }, 450);
  };

  const handleReactionPressEnd = (postId: string) => {
    if (pressHandledRef.current) return;
    pressHandledRef.current = true;
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    if (pickerPostId === postId) {
      return;
    }
    if (!longPressTriggeredRef.current) {
      if (!requireLoginForInteract()) return;
      const ownReaction = normalizeReaction(
        (likesByPostId[postId] || []).find((like: any) => String(like.userId) === String(user?.id))?.reaction
      );
      likeMutation.mutate({ postId, reaction: ownReaction ?? "like" });
    }
    longPressTriggeredRef.current = false;
  };

  const handleReactionPressCancel = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    longPressTriggeredRef.current = false;
    pressHandledRef.current = true;
  };

  const handleComment = (post: any) => {
    setSelectedPost(post);
    setCommentDialogOpen(true);
  };

  const handleShare = (post: any) => {
    setSharePost(post);
    setShareDialogOpen(true);
  };

  const handleCopyLink = async () => {
    try {
      const postUrl = `${window.location.origin}/?post=${sharePost?.id}`;
      await navigator.clipboard.writeText(postUrl);
      setLinkCopied(true);
      toast({
        title: "Link copied!",
        description: "Post link has been copied to clipboard.",
      });
      setTimeout(() => setLinkCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  const submitComment = () => {
    if (!selectedPost || !commentText.trim()) return;
    commentMutation.mutate({ postId: selectedPost.id, content: commentText });
  };

  const handleStoryClick = (story: any, userStories: any[]) => {
    setSelectedStory(story);
    setAllStoriesForViewer(userStories);
    setCurrentStoryIndex(userStories.findIndex((s: any) => s.id === story.id));
  };

  useEffect(() => {
    if (selectedStory && selectedStory.userId !== user?.id && user) {
      createStoryViewMutation.mutate(selectedStory.id);
    }
  }, [selectedStory?.id]);

  const handleShowViewers = async (story: any) => {
    setSelectedStoryForViewers(story);
    setViewersDialogOpen(true);
  };

  const goToNextStory = () => {
    if (currentStoryIndex < allStoriesForViewer.length - 1) {
      const nextIndex = currentStoryIndex + 1;
      setCurrentStoryIndex(nextIndex);
      setSelectedStory(allStoriesForViewer[nextIndex]);
    }
  };

  const goToPrevStory = () => {
    if (currentStoryIndex > 0) {
      const prevIndex = currentStoryIndex - 1;
      setCurrentStoryIndex(prevIndex);
      setSelectedStory(allStoriesForViewer[prevIndex]);
    }
  };

  const handleStoryReaction = (reaction: string) => {
    if (!selectedStory || !user) return;
    reactToStoryMutation.mutate({ storyId: selectedStory.id, reaction });
  };

  const handleSendMessage = () => {
    if (!storyMessage.trim() || !selectedStory) return;
    // Redirect to messages page with pre-filled content
    toast({
      title: "Opening Messages",
      description: `Sending message to ${selectedStory.userName}`,
    });
    setStoryMessage("");
    // You could navigate to messages page here if needed
  };

  const updateStoryScrollState = () => {
    const el = storiesStripRef.current;
    if (!el) return;
    const maxLeft = el.scrollWidth - el.clientWidth;
    setCanScrollStoriesLeft(el.scrollLeft > 4);
    setCanScrollStoriesRight(maxLeft - el.scrollLeft > 4);
  };

  const scrollStories = (direction: "left" | "right") => {
    const el = storiesStripRef.current;
    if (!el) return;
    const amount = Math.max(260, Math.floor(el.clientWidth * 0.6));
    el.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    updateStoryScrollState();
    const onResize = () => updateStoryScrollState();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [stories.length, usersWithoutStories.length, userStoriesMap.size]);

  useEffect(() => {
    if (!approvedPosts.length) return;
    const params = new URLSearchParams(window.location.search);
    const postId = params.get("post");
    if (!postId) return;

    const scrollToPost = () => {
      const el = document.querySelector(`[data-testid="post-${postId}"]`) as HTMLElement | null;
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.classList.add("ring-2", "ring-primary/70");
      setTimeout(() => el.classList.remove("ring-2", "ring-primary/70"), 1800);
    };

    setTimeout(scrollToPost, 120);
  }, [approvedPosts.length]);

  return (
    <div className="space-y-6 mx-auto w-full max-w-[760px] px-2 sm:px-3 lg:px-4">
      <div className="relative">
        <div
          ref={storiesStripRef}
          onScroll={updateStoryScrollState}
          className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:h-0 [&::-webkit-scrollbar]:w-0"
        >
        <Card
          className="min-w-[120px] w-[120px] h-[200px] cursor-pointer border-2 border-dashed border-primary/50 hover:border-primary transition-colors flex-shrink-0"
          onClick={() => setCreateStoryOpen(true)}
          data-testid="card-create-story"
        >
          <CardContent className="p-0 h-full flex flex-col items-center justify-center gap-2">
            <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
              <Plus className="w-6 h-6 text-primary-foreground" />
            </div>
            <p className="text-xs font-semibold text-center px-2">Create Story</p>
          </CardContent>
        </Card>

        {user && !userStoriesMap.has(user.id) && (
          <Card
            className="min-w-[120px] w-[120px] h-[200px] border border-muted flex-shrink-0 opacity-50"
            data-testid="card-placeholder-own"
          >
            <CardContent className="p-0 h-full relative">
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <Avatar className="w-16 h-16 border-2 border-background">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>
                    <User className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-background/80 backdrop-blur">
                <p className="text-xs font-semibold text-center truncate">You</p>
              </div>
            </CardContent>
          </Card>
        )}

        {Array.from(userStoriesMap.entries()).map(([userId, userStories]: [string, any[]]) => {
          const latestStory = userStories[0];
          return (
            <Card
              key={userId}
              className="min-w-[120px] w-[120px] h-[200px] cursor-pointer border-2 border-primary hover:scale-105 transition-transform flex-shrink-0 overflow-hidden"
              onClick={() => handleStoryClick(latestStory, userStories)}
              data-testid={`story-box-${userId}`}
            >
              <CardContent className="p-0 h-full relative">
                {latestStory.filePath.match(/\.(mp4|webm)$/i) ? (
                  <video
                    src={resolveMediaUrl(latestStory.filePath)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <img
                    src={resolveMediaUrl(latestStory.filePath)}
                    alt="Story"
                    className="w-full h-full object-cover"
                  />
                )}
                <div className="absolute top-2 left-2">
                  <Avatar className="w-10 h-10 border-2 border-primary">
                    <AvatarImage src={latestStory.userAvatar} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      <User className="w-5 h-5" />
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent">
                  <p className="text-xs font-semibold text-white truncate">{latestStory.userName}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {usersWithoutStories.map((u: any) => (
          <Card
            key={u.id}
            className="min-w-[120px] w-[120px] h-[200px] border border-muted flex-shrink-0 opacity-50"
            data-testid={`placeholder-${u.id}`}
          >
            <CardContent className="p-0 h-full relative">
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <Avatar className="w-16 h-16 border-2 border-background">
                  <AvatarImage src={u.avatar} />
                  <AvatarFallback>
                    <User className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-2 bg-background/80 backdrop-blur">
                <p className="text-xs font-semibold text-center truncate">{u.name}</p>
              </div>
            </CardContent>
          </Card>
        ))}
        </div>
        {canScrollStoriesLeft && (
          <Button
            variant="secondary"
            size="icon"
            className="hidden md:flex absolute left-1 top-[40%] -translate-y-1/2 rounded-full shadow-lg border border-border/60"
            onClick={() => scrollStories("left")}
            data-testid="button-stories-scroll-left"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
        )}
        {canScrollStoriesRight && (
          <Button
            variant="secondary"
            size="icon"
            className="hidden md:flex absolute right-1 top-[40%] -translate-y-1/2 rounded-full shadow-lg border border-border/60"
            onClick={() => scrollStories("right")}
            data-testid="button-stories-scroll-right"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        )}
      </div>

      <div className="space-y-6">
        <h2 className="text-xl font-pixel text-foreground">Posts</h2>
        {approvedPosts.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              No posts yet. Be the first to share something!
            </CardContent>
          </Card>
        ) : (
          approvedPosts.map((post: any) => {
            const reactionsForPost = likesByPostId[post.id] || [];
            const totalReactions = reactionsForPost.length;
            const totalComments = (commentsByPostId[post.id] || []).length;
            const ownReactionRow = reactionsForPost.find((like: any) => String(like.userId) === String(user?.id));
            const ownReaction = normalizeReaction(ownReactionRow?.reaction) ?? (ownReactionRow ? "like" : undefined);
            const ownReactionMeta = ownReaction ? reactionOptions.find((o) => o.key === ownReaction) : undefined;

            const reactionUsers = reactionsForPost.map((r: any) => ({ id: r.userId, name: r.userName }));
            const uniqueReactionUsers = reactionUsers.filter(
              (u, i, arr) => arr.findIndex((x) => x.id === u.id) === i
            );
            const reactionSummary = (() => {
              const totalUsers = uniqueReactionUsers.length;
              if (totalUsers === 0) return "";
              const youReacted = !!user && uniqueReactionUsers.some((u) => u.id === user.id);
              const others = uniqueReactionUsers.filter((u) => u.id !== user?.id);
              if (youReacted) {
                if (totalUsers === 1) return "You";
                if (totalUsers === 2) return `You and ${others[0]?.name || "1 other"}`;
                return `You, ${others[0]?.name || "someone"} and ${totalUsers - 2} other${totalUsers - 2 > 1 ? "s" : ""}`;
              }
              if (totalUsers === 1) return uniqueReactionUsers[0].name;
              if (totalUsers === 2) return `${uniqueReactionUsers[0].name} and ${uniqueReactionUsers[1].name}`;
              return `${uniqueReactionUsers[0].name}, ${uniqueReactionUsers[1].name} and ${totalUsers - 2} others`;
            })();

            return (
            <Card key={post.id} className="overflow-hidden border-primary/20" data-testid={`post-${post.id}`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10 border border-primary/30">
                      <AvatarImage src={post.authorAvatar} />
                      <AvatarFallback className="bg-primary/20 text-primary text-xs">
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-sm">{post.author}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {user && user.role !== "guest" && post.authorId !== user.id && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleHidePost(post.id)}
                        data-testid={`button-hide-post-${post.id}`}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                    {user && user.role !== "guest" && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" data-testid={`button-menu-post-${post.id}`}>
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {post.authorId === user.id ? (
                            <>
                              <DropdownMenuItem
                                onClick={() => deletePostMutation.mutate(post.id)}
                                data-testid={`menu-delete-post-${post.id}`}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete Post
                              </DropdownMenuItem>
                              <DropdownMenuItem data-testid={`menu-edit-post-${post.id}`}>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit Post
                              </DropdownMenuItem>
                            </>
                          ) : (
                            <>
                              <DropdownMenuItem data-testid={`menu-interested-${post.id}`}>
                                Interested
                              </DropdownMenuItem>
                              <DropdownMenuItem data-testid={`menu-not-interested-${post.id}`}>
                                Not Interested
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleReportPost(post.id)}
                                data-testid={`menu-report-post-${post.id}`}
                              >
                                <Flag className="w-4 h-4 mr-2" />
                                Report Post
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
                
                <p className="mb-4 text-sm">{post.caption}</p>
                
                <div className="mt-1 rounded-lg overflow-hidden bg-black/40">
                  {isVideoMedia(post.filePath) ? (
                    <video
                      src={resolveMediaUrl(post.filePath)}
                      className="w-full max-h-[75vh] object-contain"
                      controls
                      preload="metadata"
                    />
                  ) : (
                    <img
                      src={resolveMediaUrl(post.filePath)}
                      alt={post.caption}
                      className="w-full max-h-[75vh] object-contain"
                      loading="lazy"
                    />
                  )}
                </div>

                {pickerPostId === post.id && (
                  <div className="mt-3 inline-flex gap-1 p-1.5 rounded-full border border-primary/35 bg-background/90 backdrop-blur-sm animate-in fade-in-0 zoom-in-95 duration-200">
                    {reactionOptions.map((option) => (
                      <button
                        key={`${post.id}-picker-${option.key}`}
                        className="h-8 w-8 rounded-full border border-primary/30 hover:border-primary/70 hover:scale-110 transition-all"
                        title={option.label}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          pressHandledRef.current = true;
                          longPressTriggeredRef.current = true;
                          if (!requireLoginForInteract()) return;
                          likeMutation.mutate({ postId: post.id, reaction: option.key });
                          setPickerPostId(null);
                        }}
                        onTouchStart={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          pressHandledRef.current = true;
                          longPressTriggeredRef.current = true;
                          if (!requireLoginForInteract()) return;
                          likeMutation.mutate({ postId: post.id, reaction: option.key });
                          setPickerPostId(null);
                        }}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                        }}
                        data-testid={`button-picker-post-${option.key}-${post.id}`}
                      >
                        {option.emoji}
                      </button>
                    ))}
                  </div>
                )}

                {totalReactions > 0 && (
                  <button
                    onClick={() => setReactionDetailsPostId(post.id)}
                    className="mt-3 inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
                    data-testid={`button-post-reaction-summary-${post.id}`}
                  >
                    <span className="inline-flex items-center">
                      {Array.from(
                        new Set(
                          reactionsForPost
                            .map((r: any) => normalizeReaction(r.reaction) ?? "like")
                            .filter(Boolean)
                        )
                      )
                        .slice(0, 3)
                        .map((key, i) => {
                          const reaction = reactionOptions.find((o) => o.key === key);
                          if (!reaction) return null;
                          return (
                            <span
                              key={`${post.id}-summary-${key}`}
                              className={`h-4 w-4 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] ${i > 0 ? "-ml-1" : ""}`}
                            >
                              {reaction.emoji}
                            </span>
                          );
                        })}
                    </span>
                    <span>{reactionSummary} · {totalReactions}</span>
                  </button>
                )}

                <div className="mt-2 grid grid-cols-3 border-t border-border pt-1">
                  <button
                    onMouseDown={() => handleReactionPressStart(post.id)}
                    onMouseUp={() => handleReactionPressEnd(post.id)}
                    onMouseLeave={handleReactionPressCancel}
                    onTouchStart={() => handleReactionPressStart(post.id)}
                    onTouchEnd={() => handleReactionPressEnd(post.id)}
                    onTouchCancel={handleReactionPressCancel}
                    className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                    data-testid={`button-like-${post.id}`}
                  >
                    {ownReactionMeta ? <span>{ownReactionMeta.emoji}</span> : <ThumbsUp className="h-4 w-4" />}
                    <span className={ownReactionMeta ? "text-primary font-semibold" : ""}>
                      {ownReactionMeta?.key === "heart" ? "Love" : ownReactionMeta?.label || "Like"}
                    </span>
                  </button>
                  <button
                    onClick={() => handleComment(post)}
                    className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                    data-testid={`button-comment-${post.id}`}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Comment{totalComments > 0 ? ` (${totalComments})` : ""}</span>
                  </button>
                  <button
                    onClick={() => handleShare(post)}
                    className="h-9 text-sm text-muted-foreground hover:text-foreground transition-colors inline-flex items-center justify-center gap-1"
                    data-testid={`button-share-${post.id}`}
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          );
        })
        )}
      </div>

      <Dialog open={createStoryOpen} onOpenChange={setCreateStoryOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Story</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleStoryUpload} className="space-y-4">
            <div>
              <Input
                type="file"
                accept="image/*,video/mp4"
                onChange={(e) => setStoryFile(e.target.files?.[0] || null)}
                required
                data-testid="input-create-story-file"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Story dimensions: 1080×1920 (9:16 aspect ratio).
              </p>
            </div>
            {storyFile && (
              <div className="relative max-w-[200px] mx-auto">
                {storyFile.type.startsWith('image/') ? (
                  <img
                    src={URL.createObjectURL(storyFile)}
                    alt="Preview"
                    className="w-full rounded-lg aspect-[9/16] object-cover"
                  />
                ) : (
                  <video
                    src={URL.createObjectURL(storyFile)}
                    className="w-full rounded-lg aspect-[9/16]"
                    controls
                  />
                )}
              </div>
            )}
            <Button type="submit" disabled={createStoryMutation.isPending} className="w-full" data-testid="button-submit-create-story">
              {createStoryMutation.isPending ? "Posting..." : "Post Story"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedStory} onOpenChange={() => setSelectedStory(null)}>
        <DialogContent className="max-w-md p-0 overflow-hidden">
          {selectedStory && (() => {
            const reactionCounts = storyReactions.reduce((acc: any, r: any) => {
              acc[r.reaction] = (acc[r.reaction] || 0) + 1;
              return acc;
            }, {});
            const topReactions = Object.entries(reactionCounts)
              .sort(([, a]: any, [, b]: any) => b - a)
              .slice(0, 5)
              .map(([emoji]) => emoji);

            return (
              <div className="relative">
                {selectedStory.filePath.match(/\.(mp4|webm)$/i) ? (
                  <video
                    src={resolveMediaUrl(selectedStory.filePath)}
                    className="w-full aspect-[9/16] object-cover"
                    controls
                    autoPlay
                  />
                ) : (
                  <img
                    src={resolveMediaUrl(selectedStory.filePath)}
                    alt="Story"
                    className="w-full aspect-[9/16] object-cover"
                  />
                )}
                
                {/* Navigation */}
                {currentStoryIndex > 0 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70"
                    onClick={goToPrevStory}
                    data-testid="button-prev-story"
                  >
                    <ChevronLeft className="w-6 h-6 text-white" />
                  </Button>
                )}
                {currentStoryIndex < allStoriesForViewer.length - 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70"
                    onClick={goToNextStory}
                    data-testid="button-next-story"
                  >
                    <ChevronRight className="w-6 h-6 text-white" />
                  </Button>
                )}
                
                {/* Header */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-10 h-10 border-2 border-white">
                      <AvatarImage src={selectedStory.userAvatar} />
                      <AvatarFallback>
                        <User className="w-5 h-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-white font-semibold text-sm drop-shadow-lg">{selectedStory.userName}</p>
                      <p className="text-white/80 text-xs drop-shadow-lg">
                        {formatDistanceToNow(new Date(selectedStory.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Combined Views and Reactions or Reaction Buttons */}
                {selectedStory.userId === user?.id ? (
                  <div className="absolute bottom-20 left-4 right-4 flex items-center justify-between">
                    <Button
                      variant="ghost"
                      className="bg-black/50 hover:bg-black/70 text-white gap-2 flex items-center"
                      onClick={() => handleShowViewers(selectedStory)}
                      data-testid="button-show-viewers"
                    >
                      <Eye className="w-5 h-5" />
                      <span>{storyViews.length}</span>
                      {topReactions.length > 0 && (
                        <div className="flex gap-1 ml-2">
                          {topReactions.map((emoji, idx) => (
                            <span key={idx} className="text-lg" data-testid={`reaction-emoji-${idx}`}>{emoji}</span>
                          ))}
                        </div>
                      )}
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="bg-black/50 hover:bg-black/70"
                          data-testid="button-story-menu"
                        >
                          <MoreVertical className="w-5 h-5 text-white" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => setDeleteStoryConfirmOpen(true)}
                          data-testid="menu-delete-story"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete Story
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ) : (
                  <>
                    <div className="absolute bottom-20 left-4 flex gap-2">
                      {['❤️', '😂', '😮', '😢', '👏'].map((emoji) => (
                        <Button
                          key={emoji}
                          variant="ghost"
                          size="sm"
                          className="bg-black/50 hover:bg-black/70 text-xl"
                          onClick={() => handleStoryReaction(emoji)}
                          data-testid={`button-reaction-${emoji}`}
                        >
                          {emoji}
                        </Button>
                      ))}
                    </div>
                    {/* Message Input */}
                    <div className="absolute bottom-4 left-4 right-4 flex gap-2">
                      <Input
                        placeholder={`Message ${selectedStory.userName}...`}
                        value={storyMessage}
                        onChange={(e) => setStoryMessage(e.target.value)}
                        className="bg-black/50 border-white/30 text-white placeholder:text-white/60"
                        data-testid="input-story-message"
                      />
                      <Button
                        size="icon"
                        onClick={handleSendMessage}
                        disabled={!storyMessage.trim()}
                        className="bg-primary hover:bg-primary/90"
                        data-testid="button-send-message"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={viewersDialogOpen} onOpenChange={setViewersDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Story Views & Reactions</DialogTitle>
          </DialogHeader>
          {selectedStoryForViewers && (() => {
            const userReactionsMap = new Map();
            viewersStoryReactions.forEach((reaction: any) => {
              if (!userReactionsMap.has(reaction.userId)) {
                userReactionsMap.set(reaction.userId, []);
              }
              userReactionsMap.get(reaction.userId).push(reaction.reaction);
            });

            return (
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-sm mb-2">Viewers ({viewersStoryViews.length})</h3>
                  <ScrollArea className="h-[400px]">
                    <div className="space-y-2">
                      {viewersStoryViews.map((view: any) => {
                        const userReactions = userReactionsMap.get(view.userId) || [];
                        return (
                          <div key={view.id} className="flex items-center gap-3 p-2" data-testid={`viewer-${view.userId}`}>
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={view.userAvatar} />
                              <AvatarFallback>
                                <User className="w-4 h-4" />
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{view.userName}</p>
                              <p className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(view.createdAt), { addSuffix: true })}
                              </p>
                            </div>
                            {userReactions.length > 0 && (
                              <div className="flex gap-1">
                                {userReactions.map((reaction: string, idx: number) => (
                                  <span key={idx} className="text-xl" data-testid={`user-reaction-${view.userId}-${idx}`}>
                                    {reaction}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                      {viewersStoryViews.length === 0 && (
                        <p className="text-center text-muted-foreground text-sm py-4">No views yet</p>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteStoryConfirmOpen} onOpenChange={setDeleteStoryConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Story</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this story? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedStory) {
                  deleteStoryMutation.mutate(selectedStory.id);
                  setDeleteStoryConfirmOpen(false);
                }
              }}
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!reactionDetailsPostId} onOpenChange={(open) => !open && setReactionDetailsPostId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reactions</DialogTitle>
          </DialogHeader>
          {(() => {
            if (!reactionDetailsPostId) return null;
            const reactionsForPost = likesByPostId[reactionDetailsPostId] || [];
            const total = reactionsForPost.length;
            const grouped = reactionOptions
              .map((option) => ({
                ...option,
                count: reactionsForPost.filter((r: any) => (normalizeReaction(r.reaction) ?? "like") === option.key).length,
              }))
              .filter((g) => g.count > 0)
              .sort((a, b) => b.count - a.count);

            return (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground font-mono">Total reactions: {total}</p>
                <div className="flex flex-wrap gap-2">
                  {grouped.map((g) => (
                    <div key={`post-count-${g.key}`} className="rounded-full border border-primary/30 px-3 py-1 text-sm">
                      {g.emoji} {g.label} · {g.count}
                    </div>
                  ))}
                </div>
                <div className="max-h-72 overflow-y-auto space-y-2">
                  {reactionsForPost.map((r: any) => {
                    const emoji = reactionOptions.find((o) => o.key === (normalizeReaction(r.reaction) ?? "like"))?.emoji || "🙂";
                    return (
                      <div key={r.id} className="flex items-center justify-between rounded-lg border border-primary/20 px-3 py-2">
                        <span className="text-sm">{r.userName}</span>
                        <span className="text-lg">{emoji}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={commentDialogOpen} onOpenChange={setCommentDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Comments</DialogTitle>
          </DialogHeader>
          {selectedPost && (
            <div className="space-y-4">
              <ScrollArea className="h-[300px] pr-4">
                <div className="space-y-3">
                  {(commentsByPostId[selectedPost.id] || []).map((comment: any) => (
                      <div key={comment.id} className="flex gap-3 p-3 bg-muted rounded-lg" data-testid={`comment-${comment.id}`}>
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-primary/20 text-primary text-xs">
                            <User className="w-4 h-4" />
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-semibold text-sm">{comment.userName}</p>
                          <p className="text-sm mt-1">{comment.content}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                    ))}
                  {(commentsByPostId[selectedPost.id] || []).length === 0 && (
                    <p className="text-center text-muted-foreground text-sm py-8">No comments yet. Be the first to comment!</p>
                  )}
                </div>
              </ScrollArea>
              <div className="flex gap-2 pt-4 border-t">
                <Textarea
                  placeholder="Write a comment..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="min-h-[60px]"
                  data-testid="input-comment"
                />
                <Button 
                  onClick={submitComment} 
                  disabled={!commentText.trim() || commentMutation.isPending}
                  data-testid="button-submit-comment"
                >
                  Post
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Post</DialogTitle>
          </DialogHeader>
          {sharePost && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={sharePost.authorAvatar} />
                  <AvatarFallback>
                    <User className="w-5 h-5" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{sharePost.author}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">{sharePost.caption}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Input
                  value={`${window.location.origin}/?post=${sharePost.id}`}
                  readOnly
                  data-testid="input-share-link"
                />
                <Button onClick={handleCopyLink} data-testid="button-copy-link">
                  {linkCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <Button
                className="w-full"
                onClick={() => {
                  shareMutation.mutate(sharePost.id);
                  setShareDialogOpen(false);
                }}
                data-testid="button-share-confirm"
              >
                Share to Feed
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
