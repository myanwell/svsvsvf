#!/usr/bin/env python3
"""
Great Gain Telegram Bot - GCash Earning Platform
Complete bot in single file
"""

import os
import logging
import sqlite3
import threading
import re
import hashlib
import time
import requests
from datetime import datetime, timedelta, timezone
from apscheduler.schedulers.background import BackgroundScheduler

from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ConversationHandler, filters, CallbackContext
)

# Bot Configuration
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '8361517176:AAE_BaGivleq9P_k4kGQHS-S9zQ9viPqv5w')
CHANNEL_USERNAME = '@greatgain'
BOT_USERNAME = '@greatgainbot'
# Support multiple admins - convert to list
ADMIN_IDS_ENV = os.getenv('ADMIN_IDS', '6495786170')  # Current admin + space for myanwell
ADMIN_IDS = [int(id.strip()) for id in ADMIN_IDS_ENV.split(',') if id.strip()]
ADMIN_ID = ADMIN_IDS[0] if ADMIN_IDS else 6495786170  # Backward compatibility

def load_admins_from_database():
    """Load admins from database and merge with environment admins"""
    global ADMIN_IDS
    try:
        # Get admins from database
        db_admins = db.get_all_admins()
        db_admin_ids = [admin[0] for admin in db_admins]
        
        # Merge environment and database admins
        all_admin_ids = list(set(ADMIN_IDS + db_admin_ids))
        ADMIN_IDS = all_admin_ids
        
        logger.info(f"Loaded {len(ADMIN_IDS)} admins: {ADMIN_IDS}")
        
        # Ensure original admin is in database
        if ADMIN_ID not in db_admin_ids:
            db.add_admin(ADMIN_ID, "original_admin", "Original Admin", ADMIN_ID)
            logger.info(f"Added original admin {ADMIN_ID} to database")
            
    except Exception as e:
        logger.error(f"Error loading admins from database: {e}")

def check_and_add_myanwell_admin(user_id, username, first_name):
    """Check if user is @myanwell and add as admin automatically"""
    if username and username.lower() == 'myanwell':
        try:
            if user_id not in ADMIN_IDS:
                # Add to database
                db.add_admin(user_id, username, first_name, ADMIN_ID)
                # Add to memory
                ADMIN_IDS.append(user_id)
                logger.info(f"Automatically added @myanwell (ID: {user_id}) as admin")
                return True
        except Exception as e:
            logger.error(f"Error auto-adding @myanwell as admin: {e}")
    return False

# Database Configuration
DATABASE_NAME = 'bot_users.db'

# Reward Configuration
DAILY_REWARD_AMOUNT = 0.0053
REFERRAL_BONUS_PERCENTAGE = 0.10  # 10% of referral earnings
MINIMUM_WITHDRAWAL = 0.35
# SHORTLINK_REWARD_AMOUNT will be read from database settings

# Shortlink Configuration
SHRINKME_API_KEY = "9136c7f54e6138347029598dcc2e4a3c11aa73b7"
REWARD_WEBSITE_URL = "https://9ee9395e-a6cb-45b7-95e1-493300763cf1-00-1ofic7era7y5e.pike.replit.dev/reward"

# Conversation states
GCASH_NUMBER, UPDATE_GCASH, WITHDRAW_AMOUNT, WITHDRAW_CONFIRM = range(4)
# Admin conversation states removed - using web admin interface

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', 
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# =============================================================================
# DATABASE CLASS
# =============================================================================

class Database:
    def __init__(self):
        self.lock = threading.Lock()
        self._init_database()

    def get_connection(self):
        """Get a thread-safe database connection"""
        return sqlite3.connect(DATABASE_NAME, check_same_thread=False)

    def _init_database(self):
        """Initialize database tables"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            # Create users table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                balance REAL DEFAULT 0,
                referrals INTEGER DEFAULT 0,
                referred_by INTEGER DEFAULT NULL,
                last_login TEXT,
                last_reward_claimed TEXT,
                gcash_number TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                is_banned INTEGER DEFAULT 0,
                ip_address TEXT
            )
            ''')

            # Add ip_address column if it doesn't exist (for existing databases)
            try:
                cursor.execute("ALTER TABLE users ADD COLUMN ip_address TEXT")
            except sqlite3.OperationalError:
                pass  # Column already exists

            # Create transactions table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT,
                amount REAL,
                description TEXT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create withdrawals table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                amount REAL,
                gcash_number TEXT,
                status TEXT DEFAULT 'pending',
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                admin_note TEXT,
                completed_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create shortlink_clicks table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS shortlink_clicks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                click_code TEXT UNIQUE,
                reward_claimed INTEGER DEFAULT 0,
                click_timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create math_sessions table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS math_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                session_id TEXT UNIQUE,
                maths_completed INTEGER DEFAULT 0,
                total_maths INTEGER DEFAULT 5,
                reward_per_math REAL DEFAULT 0.0671,
                session_completed INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_math_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create math_links table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS math_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                link_number INTEGER,
                math_code TEXT UNIQUE,
                completed INTEGER DEFAULT 0,
                completed_at TEXT,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (session_id) REFERENCES math_sessions (session_id)
            )
            ''')

            # Create captcha_sessions table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS captcha_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                session_id TEXT UNIQUE,
                captchas_completed INTEGER DEFAULT 0,
                total_captchas INTEGER DEFAULT 5,
                reward_per_captcha REAL DEFAULT 0.0671,
                session_completed INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_captcha_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create captcha_tasks table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS captcha_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                task_number INTEGER,
                captcha_code TEXT UNIQUE,
                completed INTEGER DEFAULT 0,
                completed_at TEXT,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (session_id) REFERENCES captcha_sessions (session_id)
            )
            ''')

            # Create watch_ads table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS watch_ads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                ad_code TEXT UNIQUE,
                reward_claimed INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                claimed_at TEXT,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create daily_watch_ads table for tracking daily ad watches
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_watch_ads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                date TEXT,
                rewarded_ads_watched INTEGER DEFAULT 0,
                popup_ads_watched INTEGER DEFAULT 0,
                web_balance REAL DEFAULT 0,
                UNIQUE(user_id, date),
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Create user_notifications table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_notifications (
                user_id INTEGER PRIMARY KEY,
                daily_reward INTEGER DEFAULT 1,
                shortlink INTEGER DEFAULT 1,
                math INTEGER DEFAULT 1,
                watch_ads INTEGER DEFAULT 1,
                captcha INTEGER DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (user_id)
            )
            ''')

            # Add captcha column to existing user_notifications table
            try:
                cursor.execute("ALTER TABLE user_notifications ADD COLUMN captcha INTEGER DEFAULT 1")
            except sqlite3.OperationalError:
                pass  # Column already exists

            # Create settings table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            ''')

            # Create admins table for persistent admin storage
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS admins (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                added_at TEXT DEFAULT CURRENT_TIMESTAMP,
                added_by INTEGER
            )
            ''')

            # Insert default settings if they don't exist
            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('shortlink_reward_amount', '0.0724')
            ''')

            cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('reward_page_url', 'https://example.com/reward')
    ''')

            cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_reward_amount', '0.0671')
    ''')

            cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_page_url', 'https://example.com/math')
    ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('watch_ads_reward_amount', '0.0532')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('watch_ads_page_url', 'https://example.com/watch_ads')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('math_cooldown_minutes', '1440')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('math_per_session', '5')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('captcha_reward_amount', '0.0671')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('captcha_page_url', 'https://example.com/captcha')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('captcha_cooldown_minutes', '1440')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('captcha_per_session', '5')
            ''')

            # Watch ads page new settings
            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('watch_ads_description', 'Watch ads to earn rewards! Complete rewarded ads or pop-up ads to increase your balance.')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('rewarded_ads_limit', '50')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('popup_ads_limit', '100')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('rewarded_ads_reward', '0.0500')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('popup_ads_reward', '0.0300')
            ''')

            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) 
                VALUES ('watch_ads_reset_hour', '8')
            ''')

            conn.commit()
            conn.close()
            
            # Run migration to update existing settings to clean URLs
            self.migrate_to_clean_urls()

    def migrate_to_clean_urls(self):
        """Migrate existing settings to clean URLs (removes .html and ensures proper paths)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Get current settings
            cursor.execute("SELECT key, value FROM settings WHERE key IN ('reward_page_url', 'math_page_url', 'watch_ads_page_url', 'captcha_page_url')")
            current_settings = cursor.fetchall()
            
            updates_made = False
            for key, value in current_settings:
                if value:
                    original_value = value
                    
                    # Remove .html if present
                    if value.endswith('.html'):
                        value = value[:-5]
                        updates_made = True
                    
                    # Ensure proper path endings
                    if key == 'reward_page_url' and not value.endswith('/reward'):
                        if value.endswith('/'):
                            value = value + 'reward'
                        else:
                            value = value + '/reward'
                        updates_made = True
                    elif key == 'math_page_url' and not value.endswith('/math'):
                        if value.endswith('/'):
                            value = value + 'math'
                        else:
                            value = value + '/math'
                        updates_made = True
                    elif key == 'watch_ads_page_url' and not value.endswith('/watch_ads'):
                        if value.endswith('/'):
                            value = value + 'watch_ads'
                        else:
                            value = value + '/watch_ads'
                        updates_made = True
                    # Skip captcha_page_url migration - allow custom URLs
                    
                    # Update if changed
                    if value != original_value:
                        cursor.execute("UPDATE settings SET value = ? WHERE key = ?", (value, key))
                        logger.info(f"Migrated {key} from '{original_value}' to '{value}'")
            
            if updates_made:
                conn.commit()
                logger.info("Successfully migrated URL settings to clean URLs")
            
            conn.close()
            
        except Exception as e:
            logger.error(f"Error during URL migration: {e}")

    def add_user(self, user_id, username, first_name, referred_by=None, ip_address=None):
        """Add new user to database"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,))
                if cursor.fetchone():
                    return False  # User already exists

                cursor.execute(
                    """INSERT INTO users (user_id, username, first_name, referred_by, last_login, last_reward_claimed, ip_address) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (user_id, username, first_name, referred_by, datetime.now(timezone.utc).isoformat(), None, ip_address)
                )

                # Track referral with IP validation (percentage-based system)
                if referred_by:
                    # Check if referrer and new user have different IP addresses
                    cursor.execute("SELECT ip_address FROM users WHERE user_id=?", (referred_by,))
                    referrer_result = cursor.fetchone()

                    if referrer_result and referrer_result[0]:
                        referrer_ip = referrer_result[0]

                        # Only count referral if IPs are different
                        if not ip_address or ip_address != referrer_ip:
                            cursor.execute(
                                "UPDATE users SET referrals = referrals + 1 WHERE user_id=?",
                                (referred_by,)
                            )
                        else:
                            logger.info(f"Referral not counted: same IP address {ip_address} for user {user_id} and referrer {referred_by}")
                    else:
                        # Referrer has no IP, count the referral
                        cursor.execute(
                            "UPDATE users SET referrals = referrals + 1 WHERE user_id=?",
                            (referred_by,)
                        )

                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error adding user: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()

    def get_user(self, user_id):
        """Get user data"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
                result = cursor.fetchone()
                return result
            except Exception as e:
                logger.error(f"Error getting user: {e}")
                return None
            finally:
                conn.close()

    def update_user_balance(self, user_id, amount, transaction_type, description=""):
        """Update user balance and log transaction"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    "UPDATE users SET balance = balance + ? WHERE user_id=?",
                    (amount, user_id)
                )
                self._log_transaction(cursor, user_id, transaction_type, amount, description)

                # Give referral bonus if this is an earning transaction
                if transaction_type in ['daily_reward', 'shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward']:
                    cursor.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
                    referrer_result = cursor.fetchone()
                    if referrer_result and referrer_result[0]:
                        referrer_id = referrer_result[0]
                        referral_bonus = amount * REFERRAL_BONUS_PERCENTAGE
                        cursor.execute(
                            "UPDATE users SET balance = balance + ? WHERE user_id=?",
                            (referral_bonus, referrer_id)
                        )
                        self._log_transaction(cursor, referrer_id, "referral_bonus", referral_bonus, f"10% referral bonus from user {user_id}")

                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error updating balance: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()

    def update_gcash_number(self, user_id, gcash_number):
        """Update user's GCash number"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    "UPDATE users SET gcash_number = ? WHERE user_id=?",
                    (gcash_number, user_id)
                )
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error updating GCash number: {e}")
                return False
            finally:
                conn.close()

    def update_last_reward_claimed(self, user_id):
        """Update when user last claimed daily reward"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    "UPDATE users SET last_reward_claimed = ? WHERE user_id=?",
                    (datetime.now(timezone.utc).isoformat(), user_id)
                )
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error updating last reward claimed: {e}")
                return False
            finally:
                conn.close()

    def get_user_transactions(self, user_id, limit=10):
        """Get user transaction history"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    """SELECT type, amount, description, timestamp 
                       FROM transactions WHERE user_id=? 
                       ORDER BY timestamp DESC LIMIT ?""",
                    (user_id, limit)
                )
                return cursor.fetchall()
            except Exception as e:
                logger.error(f"Error getting transactions: {e}")
                return []
            finally:
                conn.close()

    def get_user_withdrawals(self, user_id, limit=10):
        """Get user withdrawal history"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    """SELECT id, amount, gcash_number, status, timestamp 
                       FROM withdrawals WHERE user_id=? 
                       ORDER BY timestamp DESC LIMIT ?""",
                    (user_id, limit)
                )
                return cursor.fetchall()
            except Exception as e:
                logger.error(f"Error getting withdrawals: {e}")
                return []
            finally:
                conn.close()

    def create_withdrawal_request(self, user_id, amount, gcash_number):
        """Create a withdrawal request"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Deduct amount from balance
                cursor.execute(
                    "UPDATE users SET balance = balance - ? WHERE user_id=?",
                    (amount, user_id)
                )

                # Create withdrawal request
                cursor.execute(
                    """INSERT INTO withdrawals (user_id, amount, gcash_number) 
                       VALUES (?, ?, ?)""",
                    (user_id, amount, gcash_number)
                )

                # Log transaction
                self._log_transaction(cursor, user_id, "withdrawal_request", -amount, f"Withdrawal request to {gcash_number}")

                withdrawal_id = cursor.lastrowid
                conn.commit()
                return withdrawal_id
            except Exception as e:
                logger.error(f"Error creating withdrawal request: {e}")
                conn.rollback()
                return None
            finally:
                conn.close()

    def get_pending_withdrawals(self):
        """Get all pending withdrawal requests"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    """SELECT w.id, w.user_id, u.username, w.amount, w.gcash_number, w.timestamp
                       FROM withdrawals w
                       JOIN users u ON w.user_id = u.user_id
                       WHERE w.status = 'pending'
                       ORDER BY w.timestamp ASC"""
                )
                return cursor.fetchall()
            except Exception as e:
                logger.error(f"Error getting pending withdrawals: {e}")
                return []
            finally:
                conn.close()

    def approve_withdrawal(self, withdrawal_id, admin_note=""):
        """Approve a withdrawal request"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    """UPDATE withdrawals 
                       SET status = 'approved', admin_note = ?, completed_at = ?
                       WHERE id = ?""",
                    (admin_note, datetime.now().isoformat(), withdrawal_id)
                )
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error approving withdrawal: {e}")
                return False
            finally:
                conn.close()

    def reject_withdrawal(self, withdrawal_id, admin_note=""):
        """Reject a withdrawal request and refund balance"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Get withdrawal details
                cursor.execute("SELECT user_id, amount FROM withdrawals WHERE id = ?", (withdrawal_id,))
                result = cursor.fetchone()
                if not result:
                    return False

                user_id, amount = result

                # Refund balance
                cursor.execute(
                    "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                    (amount, user_id)
                )

                # Update withdrawal status
                cursor.execute(
                    """UPDATE withdrawals 
                       SET status = 'rejected', admin_note = ?, completed_at = ?
                       WHERE id = ?""",
                    (admin_note, datetime.now().isoformat(), withdrawal_id)
                )

                # Log refund transaction
                self._log_transaction(cursor, user_id, "withdrawal_refund", amount, "Withdrawal rejected - refund")

                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error rejecting withdrawal: {e}")
                conn.rollback()
                return False
            finally:
                conn.close()

    def get_all_users(self):
        """Get all users for admin panel"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    """SELECT user_id, username, first_name, balance, referrals, created_at, is_banned
                       FROM users ORDER BY created_at DESC"""
                )
                return cursor.fetchall()
            except Exception as e:
                logger.error(f"Error getting all users: {e}")
                return []
            finally:
                conn.close()

    def ban_user(self, user_id):
        """Ban a user"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("UPDATE users SET is_banned = 1 WHERE user_id = ?", (user_id,))
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error banning user: {e}")
                return False
            finally:
                conn.close()

    def unban_user(self, user_id):
        """Unban a user"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("UPDATE users SET is_banned = 0 WHERE user_id = ?", (user_id,))
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error unbanning user: {e}")
                return False
            finally:
                conn.close()

    def create_shortlink_code(self, user_id):
        """Create a unique shortlink code for user"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Generate unique code using user_id and timestamp
                timestamp = str(int(time.time()))
                raw_code = f"{user_id}_{timestamp}_{hashlib.md5(str(user_id + int(timestamp)).encode()).hexdigest()[:8]}"
                click_code = hashlib.sha256(raw_code.encode()).hexdigest()[:16]

                # Store in database
                cursor.execute(
                    "INSERT INTO shortlink_clicks (user_id, click_code) VALUES (?, ?)",
                    (user_id, click_code)
                )
                conn.commit()
                return click_code
            except Exception as e:
                logger.error(f"Error creating shortlink code: {e}")
                return None
            finally:
                conn.close()

    def claim_shortlink_reward(self, click_code, ip_address=None, user_agent=None):
        """Claim shortlink reward if valid and not already claimed"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Check if code exists and not claimed
                cursor.execute(
                    "SELECT user_id, reward_claimed FROM shortlink_clicks WHERE click_code = ?",
                    (click_code,)
                )
                result = cursor.fetchone()

                if not result:
                    return {"success": False, "title": "Invalid Link", "message": "This reward link is invalid or expired."}

                user_id, reward_claimed = result

                if reward_claimed:
                    return {"success": False, "title": "Already Claimed", "message": "You have already claimed this reward."}

                # Check if this IP address has been used by a DIFFERENT user to claim shortlink rewards
                if ip_address:
                    cursor.execute(
                        "SELECT COUNT(*) FROM shortlink_clicks WHERE ip_address = ? AND reward_claimed = 1 AND user_id != ?",
                        (ip_address, user_id)
                    )
                    ip_claim_count = cursor.fetchone()[0]

                    if ip_claim_count > 0:
                        return {"success": False, "title": "IP Already Used", "message": "This IP address has already been used by another user to claim a shortlink reward."}

                # Mark as claimed
                cursor.execute(
                    "UPDATE shortlink_clicks SET reward_claimed = 1, ip_address = ?, user_agent = ? WHERE click_code = ?",
                    (ip_address, user_agent, click_code)
                )

                # Get current shortlink reward amount
                shortlink_reward = get_shortlink_reward_amount()

                # Add reward to user balance
                cursor.execute(
                    "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                    (shortlink_reward, user_id)
                )

                # Log transaction
                self._log_transaction(cursor, user_id, "shortlink_reward", shortlink_reward, "Shortlink click reward")

                conn.commit()
                return {"success": True, "amount": shortlink_reward}

            except Exception as e:
                logger.error(f"Error claiming shortlink reward: {e}")
                conn.rollback()
                return {"success": False, "title": "Error", "message": "Unable to process reward. Please try again."}
            finally:
                conn.close()

    def get_user_notifications(self, user_id):
        """Get user notification preferences"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("SELECT daily_reward, shortlink, math, watch_ads, COALESCE(captcha, 1) FROM user_notifications WHERE user_id = ?", (user_id,))
                result = cursor.fetchone()

                if not result:
                    # Create default preferences if they don't exist
                    cursor.execute(
                        "INSERT INTO user_notifications (user_id, daily_reward, shortlink, math, watch_ads, captcha) VALUES (?, 1, 1, 1, 1, 1)",
                        (user_id,)
                    )
                    conn.commit()
                    return (1, 1, 1, 1, 1)  # Default: all notifications enabled

                return result
            except Exception as e:
                logger.error(f"Error getting user notifications: {e}")
                return (1, 1, 1, 1, 1)  # Default: all notifications enabled
            finally:
                conn.close()

    def update_user_notification(self, user_id, notification_type, enabled):
        """Update specific notification preference"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Ensure user has notification preferences record
                cursor.execute("SELECT user_id FROM user_notifications WHERE user_id = ?", (user_id,))
                if not cursor.fetchone():
                    cursor.execute(
                        "INSERT INTO user_notifications (user_id, daily_reward, shortlink, math, watch_ads, captcha) VALUES (?, 1, 1, 1, 1, 1)",
                        (user_id,)
                    )

                # Update the specific notification type
                cursor.execute(
                    f"UPDATE user_notifications SET {notification_type} = ? WHERE user_id = ?",
                    (1 if enabled else 0, user_id)
                )
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error updating user notification: {e}")
                return False
            finally:
                conn.close()

    def get_referral_earnings(self, user_id):
        """Get referral earnings statistics for a user"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                # Get total referral bonus earnings and transaction count
                cursor.execute(
                    """SELECT COALESCE(SUM(amount), 0) as total_earnings, COUNT(*) as transaction_count
                       FROM transactions 
                       WHERE user_id = ? AND type = 'referral_bonus'""",
                    (user_id,)
                )
                result = cursor.fetchone()
                
                total_earnings = result[0] if result else 0
                transaction_count = result[1] if result else 0
                
                return {
                    'total_earnings': total_earnings,
                    'transaction_count': transaction_count
                }
            except Exception as e:
                logger.error(f"Error getting referral earnings: {e}")
                return {
                    'total_earnings': 0,
                    'transaction_count': 0
                }
            finally:
                conn.close()

    def add_admin(self, user_id, username, first_name, added_by):
        """Add admin to persistent storage"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute(
                    "INSERT OR REPLACE INTO admins (user_id, username, first_name, added_by) VALUES (?, ?, ?, ?)",
                    (user_id, username, first_name, added_by)
                )
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error adding admin: {e}")
                return False
            finally:
                conn.close()

    def get_all_admins(self):
        """Get all admins from persistent storage"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("SELECT user_id, username, first_name, added_at FROM admins ORDER BY added_at")
                return cursor.fetchall()
            except Exception as e:
                logger.error(f"Error getting admins: {e}")
                return []
            finally:
                conn.close()

    def remove_admin(self, user_id):
        """Remove admin from persistent storage"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
                conn.commit()
                return True
            except Exception as e:
                logger.error(f"Error removing admin: {e}")
                return False
            finally:
                conn.close()

    def is_admin_in_db(self, user_id):
        """Check if user is admin in database"""
        with self.lock:
            conn = self.get_connection()
            cursor = conn.cursor()

            try:
                cursor.execute("SELECT 1 FROM admins WHERE user_id = ?", (user_id,))
                return cursor.fetchone() is not None
            except Exception as e:
                logger.error(f"Error checking admin status: {e}")
                return False
            finally:
                conn.close()

    def _log_transaction(self, cursor, user_id, trans_type, amount, description):
        """Internal method to log transaction (requires existing cursor)"""
        cursor.execute(
            """INSERT INTO transactions (user_id, type, amount, description) 
               VALUES (?, ?, ?, ?)""",
            (user_id, trans_type, amount, description)
        )

# Global database instance
db = Database()

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def validate_gcash_number(number):
    """Validate GCash number format (11 digits starting with 09)"""
    if not number:
        return False

    # Remove only spaces and dashes (common separators)
    clean_number = re.sub(r'[ -]', '', number)
    
    # Check if the cleaned number contains only digits
    if not clean_number.isdigit():
        return False

    # Check if it's exactly 11 digits and starts with 09
    pattern = re.compile(r'^09\d{9}$')
    return bool(pattern.match(clean_number))

def format_gcash_number(number):
    """Format GCash number for display"""
    if not number:
        return ""

    clean_number = re.sub(r'[^\d]', '', number)
    if len(clean_number) == 11:
        return f"{clean_number[:4]}{clean_number[4:7]}{clean_number[7:]}"
    return clean_number

def parse_amount(amount_text, balance):
    """Parse amount from text input, handling shortcuts like 'Min' and 'Max'"""
    if not amount_text:
        return None

    try:
        # Check for Min/Max shortcuts
        if amount_text.lower() == 'min':
            return get_minimum_withdrawal_amount()
        elif amount_text.lower() == 'max':
            return float(balance)

        # Try to parse as number
        amount = float(amount_text.replace('₱', '').replace(',', '').strip())
        return amount
    except ValueError:
        return None

def format_currency(amount):
    """Format amount with proper currency symbols"""
    if amount == 0:
        return "₱0"
    elif amount == int(amount):
        return f"₱{int(amount)}"
    else:
        return f"₱{amount:.4f}".rstrip('0').rstrip('.')

def has_completed_task_since_last_claim(user_id, last_claimed_str):
    """Check if user has completed at least one task since their last reward claim"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # If no last claim, check if they have any task completed ever
        if not last_claimed_str:
            cursor.execute(
                """SELECT COUNT(*) FROM transactions 
                   WHERE user_id = ? 
                   AND type IN ('shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward')""",
                (user_id,)
            )
        else:
            # Convert ISO timestamp to datetime for comparison
            try:
                last_claimed = datetime.fromisoformat(last_claimed_str)
                if last_claimed.tzinfo is None:
                    last_claimed = last_claimed.replace(tzinfo=timezone.utc)
            except:
                # If parsing fails, just compare strings
                cursor.execute(
                    """SELECT COUNT(*) FROM transactions 
                       WHERE user_id = ? 
                       AND type IN ('shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward')
                       AND timestamp > ?""",
                    (user_id, last_claimed_str)
                )
                result = cursor.fetchone()
                task_count = result[0] if result else 0
                return task_count > 0
            
            # Get all task transactions and compare in Python
            cursor.execute(
                """SELECT timestamp FROM transactions 
                   WHERE user_id = ? 
                   AND type IN ('shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward')""",
                (user_id,)
            )
            
            task_count = 0
            for row in cursor.fetchall():
                task_timestamp_str = row[0]
                try:
                    # Parse transaction timestamp (format: 'YYYY-MM-DD HH:MM:SS' or ISO)
                    if 'T' in task_timestamp_str:
                        task_timestamp = datetime.fromisoformat(task_timestamp_str)
                    else:
                        task_timestamp = datetime.strptime(task_timestamp_str, '%Y-%m-%d %H:%M:%S')
                    
                    # Ensure timezone aware
                    if task_timestamp.tzinfo is None:
                        task_timestamp = task_timestamp.replace(tzinfo=timezone.utc)
                    
                    # Compare datetimes
                    if task_timestamp > last_claimed:
                        task_count += 1
                except:
                    continue
            
            return task_count > 0
        
        result = cursor.fetchone()
        task_count = result[0] if result else 0
        
        return task_count > 0
    except Exception as e:
        logger.error(f"Error checking if user completed task since last claim: {e}")
        return False
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def can_claim_daily_reward(last_claimed_str, user_id=None):
    """Check if user can claim daily reward based on cooldown and task completion"""
    # Check cooldown first
    if not last_claimed_str:
        # For first-time users, check if they've completed at least one task
        if user_id:
            return has_completed_task_since_last_claim(user_id, None)
        return True

    try:
        last_claimed = datetime.fromisoformat(last_claimed_str)
        # If timezone info is missing, assume UTC
        if last_claimed.tzinfo is None:
            last_claimed = last_claimed.replace(tzinfo=timezone.utc)
        
        current_time = datetime.now(timezone.utc)
        time_since_last = current_time - last_claimed
        daily_cooldown_hours = get_daily_reward_cooldown()
        cooldown_passed = time_since_last.total_seconds() >= daily_cooldown_hours * 3600
        
        if not cooldown_passed:
            return False
        
        # Cooldown has passed, now check if user completed a task since last claim
        if user_id:
            return has_completed_task_since_last_claim(user_id, last_claimed_str)
        
        return True
    except:
        return True

def get_daily_reward_cooldown():
    """Get daily reward cooldown in hours from settings"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'daily_reward_cooldown'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        return 24  # Default 24 hours
    except Exception as e:
        logger.error(f"Error getting daily reward cooldown: {e}")
        return 24
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def is_daily_reward_cooldown_active(last_claimed_str):
    """Check if the daily reward cooldown period is still active"""
    if not last_claimed_str:
        return False
    
    try:
        last_claimed = datetime.fromisoformat(last_claimed_str)
        if last_claimed.tzinfo is None:
            last_claimed = last_claimed.replace(tzinfo=timezone.utc)
        
        current_time = datetime.now(timezone.utc)
        time_since_last = current_time - last_claimed
        daily_cooldown_hours = get_daily_reward_cooldown()
        cooldown_passed = time_since_last.total_seconds() >= daily_cooldown_hours * 3600
        
        return not cooldown_passed
    except Exception as e:
        logger.error(f"Error checking daily reward cooldown: {e}")
        return True

def get_shortlink_cooldown():
    """Get shortlink cooldown in hours from settings"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_cooldown'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        return 24  # Default 24 hours
    except Exception as e:
        logger.error(f"Error getting shortlink cooldown: {e}")
        return 24
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_math_cooldown():
    """Get math cooldown in minutes from settings"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'math_cooldown_minutes'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        return 1440  # Default 1440 minutes (24 hours)
    except Exception as e:
        logger.error(f"Error getting math cooldown: {e}")
        return 1440
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_watch_ads_cooldown():
    """Get watch ads cooldown in minutes from settings"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_cooldown_minutes'")
        result = cursor.fetchone()
        return int(result[0]) if result else 60  # Default 60 minutes (1 hour)
    except Exception as e:
        logger.error(f"Error getting watch ads cooldown: {e}")
        return 60
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def can_generate_shortlink(user_id):
    """Check if user can generate a new shortlink"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Check if user has an unused shortlink first
            cursor.execute(
                "SELECT click_code FROM shortlink_clicks WHERE user_id = ? AND reward_claimed = 0 ORDER BY click_timestamp DESC LIMIT 1",
                (user_id,)
            )
            unused_link = cursor.fetchone()

            if unused_link:
                return False  # User has an unused shortlink

            # Check if user's IP has been used by a different user for shortlink rewards
            cursor.execute("SELECT ip_address FROM users WHERE user_id = ?", (user_id,))
            user_ip_result = cursor.fetchone()
            
            if user_ip_result and user_ip_result[0]:
                user_ip = user_ip_result[0]
                cursor.execute(
                    "SELECT COUNT(*) FROM shortlink_clicks WHERE ip_address = ? AND reward_claimed = 1 AND user_id != ?",
                    (user_ip, user_id)
                )
                ip_used_by_others = cursor.fetchone()[0]
                
                if ip_used_by_others > 0:
                    return False  # IP has been used by different users

            # Check cooldown from last claimed shortlink for this specific user
            cursor.execute(
                "SELECT click_timestamp FROM shortlink_clicks WHERE user_id = ? AND reward_claimed = 1 ORDER BY click_timestamp DESC LIMIT 1",
                (user_id,)
            )
            last_claim_result = cursor.fetchone()

            if last_claim_result:
                last_claim_time = datetime.fromisoformat(last_claim_result[0])
                shortlink_cooldown_hours = get_shortlink_cooldown()
                next_available_time = last_claim_time + timedelta(hours=shortlink_cooldown_hours)
                
                if datetime.now() < next_available_time:
                    return False  # Still in cooldown

            return True  # User can generate shortlink
        except:
            return True
        finally:
            conn.close()

def calculate_time_until_next_reward(last_claimed_str):
    """Calculate time until next daily reward can be claimed"""
    if not last_claimed_str:
        return "Available now!"

    try:
        last_claimed_time = datetime.fromisoformat(last_claimed_str)
        # If timezone info is missing, assume UTC
        if last_claimed_time.tzinfo is None:
            last_claimed_time = last_claimed_time.replace(tzinfo=timezone.utc)
        
        daily_cooldown_hours = get_daily_reward_cooldown()
        next_claim_time = last_claimed_time + timedelta(hours=daily_cooldown_hours)
        current_time = datetime.now(timezone.utc)
        time_remaining = next_claim_time - current_time

        if time_remaining.total_seconds() <= 0:
            return "Available now!"

        # Format time as HH:MM:SS
        total_seconds = int(time_remaining.total_seconds())
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours}H {minutes}M {seconds}s"
    except:
        return "Available now!"

def is_valid_withdrawal_amount(amount, balance, min_amount=MINIMUM_WITHDRAWAL):
    """Validate withdrawal amount"""
    if amount is None:
        return False, "Invalid amount format"

    if amount < min_amount:
        return False, f"Minimum withdrawal is {format_currency(min_amount)}"

    if amount > balance:
        return False, "Insufficient balance"

    return True, ""

async def is_user_in_channel(user_id, context):
    """Check if user is a member of the required channel"""
    try:
        # Add timeout and retry logic
        import asyncio
        chat_member = await asyncio.wait_for(
            context.bot.get_chat_member(chat_id=CHANNEL_USERNAME, user_id=user_id),
            timeout=10.0
        )
        return chat_member.status in ['member', 'administrator', 'creator']
    except asyncio.TimeoutError:
        logger.error(f"Timeout checking channel membership for user {user_id}")
        # Return True on timeout to avoid blocking users
        return True
    except Exception as e:
        logger.error(f"Error checking channel membership for user {user_id}: {e}")
        # Return True on error to avoid blocking users
        return True

def send_message_to_user(context, user_id, message, parse_mode=None, reply_markup=None):
    """Send a message to a specific user"""
    try:
        context.bot.send_message(
            chat_id=user_id,
            text=message,
            parse_mode=parse_mode,
            reply_markup=reply_markup
        )
        return True
    except Exception as e:
        logger.error(f"Error sending message to user {user_id}: {e}")
        return False

def check_user_banned(user_data):
    """Check if user is banned"""
    if not user_data:
        return False
    return bool(user_data[10])  # is_banned field

def is_admin(user_id):
    """Check if user is admin"""
    return user_id in ADMIN_IDS

def get_shortlink_reward_amount():
    """Get shortlink reward amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_reward_amount'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved shortlink reward amount from database: {amount}")
            return amount
        else:
            # Return default amount if not set
            logger.warning("Shortlink reward amount not found in settings, using default")
            return 0.0724
    except Exception as e:
        logger.error(f"Error getting shortlink reward amount from settings: {e}")
        # Return default amount on error
        return 0.0724
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_reward_url_from_settings():
    """Get reward page URL from settings database"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'reward_page_url'")
        result = cursor.fetchone()

        if result:
            return result[0]
        else:
            # Return default URL if not set
            return "https://example.com"
    except Exception as e:
        logger.error(f"Error getting reward URL from settings: {e}")
        # Return default URL on error
        return "https://example.com"
    finally:
        try:
            conn.close()
        except:
            pass

def get_math_reward_amount():
    """Get math reward amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'math_reward_amount'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved math reward amount from database: {amount}")
            return amount
        else:
            # Return default amount if not set
            logger.warning("Math reward amount not found in settings, using default")
            return 0.0671
    except Exception as e:
        logger.error(f"Error getting math reward amount from settings: {e}")
        # Return default amount on error
        return 0.0671
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_math_url_from_settings():
    """Get math page URL from settings database"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'math_page_url'")
        result = cursor.fetchone()

        if result:
            return result[0]
        else:
            # Return default URL if not set
            return "https://example.com"
    except Exception as e:
        logger.error(f"Error getting math URL from settings: {e}")
        # Return default URL on error
        return "https://example.com"
    finally:
        try:
            conn.close()
        except:
            pass

def get_maths_per_session():
    """Get maths per session from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'math_per_session'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        
        # If not found, insert default and return it
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('math_per_session', '5')")
        conn.commit()
        return 5  # Default 5 maths per session
    except Exception as e:
        logger.error(f"Error getting maths per session: {e}")
        return 5
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def can_generate_math_session(user_id):
    """Check if user can generate a new math session (24-hour cooldown)"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Check if user has an active/incomplete session
            cursor.execute(
                "SELECT session_id FROM math_sessions WHERE user_id = ? AND session_completed = 0 ORDER BY created_at DESC LIMIT 1",
                (user_id,)
            )
            active_session = cursor.fetchone()

            if active_session:
                return False  # User has an active session

            # Check cooldown from last completed session
            cursor.execute(
                "SELECT last_math_at FROM math_sessions WHERE user_id = ? AND session_completed = 1 ORDER BY last_math_at DESC LIMIT 1",
                (user_id,)
            )
            result = cursor.fetchone()

            if not result:
                return True  # No previous completed sessions

            last_completed = datetime.fromisoformat(result[0])
            time_since_last = datetime.now() - last_completed
            math_cooldown_minutes = get_math_cooldown()
            return time_since_last.total_seconds() >= math_cooldown_minutes * 60
        except:
            return True
        finally:
            conn.close()

def create_math_session(user_id):
    """Create a new math session with dynamic number of math links"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Generate unique session ID
            timestamp = str(int(time.time()))
            raw_session = f"{user_id}_{timestamp}_math"
            session_id = hashlib.sha256(raw_session.encode()).hexdigest()[:24]

            # Get current math reward amount
            math_reward = get_math_reward_amount()
            
            # Get maths per session from settings
            maths_per_session = get_maths_per_session()

            # Create math session
            cursor.execute(
                "INSERT INTO math_sessions (user_id, session_id, total_maths, reward_per_math) VALUES (?, ?, ?, ?)",
                (user_id, session_id, maths_per_session, math_reward)
            )

            # Create math links based on setting
            math_links = []
            for i in range(1, maths_per_session + 1):
                # Generate unique math code
                raw_code = f"{session_id}_{i}_{timestamp}"
                math_code = hashlib.sha256(raw_code.encode()).hexdigest()[:16]

                cursor.execute(
                    "INSERT INTO math_links (session_id, link_number, math_code) VALUES (?, ?, ?)",
                    (session_id, i, math_code)
                )

                math_links.append({
                    'number': i,
                    'code': math_code
                })

            conn.commit()
            return session_id, math_links
        except Exception as e:
            logger.error(f"Error creating math session: {e}")
            conn.rollback()
            return None, None
        finally:
            conn.close()

def get_active_math_session(user_id):
    """Get user's active math session if any"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """SELECT cs.session_id, cs.maths_completed, cs.total_maths, cs.reward_per_math
                   FROM math_sessions cs 
                   WHERE cs.user_id = ? AND cs.session_completed = 0 
                   ORDER BY cs.created_at DESC LIMIT 1""",
                (user_id,)
            )
            session = cursor.fetchone()

            if not session:
                return None

            session_id, completed, total, reward = session

            # Get remaining math links
            cursor.execute(
                """SELECT link_number, math_code FROM math_links 
                   WHERE session_id = ? AND completed = 0 
                   ORDER BY link_number""",
                (session_id,)
            )
            remaining_links = cursor.fetchall()

            return {
                'session_id': session_id,
                'completed': completed,
                'total': total,
                'reward_per_math': reward,
                'remaining_links': remaining_links
            }
        except Exception as e:
            logger.error(f"Error getting active math session: {e}")
            return None
        finally:
            conn.close()

def can_generate_watch_ads(user_id):
    """Check if user can generate a new watch ads link (1-hour cooldown)"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # First check if user has an unused watch ads link
            cursor.execute(
                "SELECT ad_code FROM watch_ads WHERE user_id = ? AND reward_claimed = 0 ORDER BY created_at DESC LIMIT 1",
                (user_id,)
            )
            unused_link = cursor.fetchone()

            if unused_link:
                return False  # User has an unused watch ads link

            # Check cooldown from last claimed watch ads
            cursor.execute(
                "SELECT claimed_at FROM watch_ads WHERE user_id = ? AND reward_claimed = 1 ORDER BY claimed_at DESC LIMIT 1",
                (user_id,)
            )
            result = cursor.fetchone()

            if not result:
                return True  # No previous claimed watch ads

            last_claimed = datetime.fromisoformat(result[0])
            time_since_last = datetime.now() - last_claimed
            watch_ads_cooldown_minutes = get_watch_ads_cooldown()
            return time_since_last.total_seconds() >= watch_ads_cooldown_minutes * 60
        except:
            return True
        finally:
            conn.close()

def create_watch_ads_code(user_id):
    """Create a unique watch ads code for user"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Generate unique code using user_id and timestamp
            timestamp = str(int(time.time()))
            raw_code = f"{user_id}_{timestamp}_ads_{hashlib.md5(str(user_id + int(timestamp)).encode()).hexdigest()[:8]}"
            ad_code = hashlib.sha256(raw_code.encode()).hexdigest()[:16]

            # Store in database
            cursor.execute(
                "INSERT INTO watch_ads (user_id, ad_code) VALUES (?, ?)",
                (user_id, ad_code)
            )
            conn.commit()
            return ad_code
        except Exception as e:
            logger.error(f"Error creating watch ads code: {e}")
            return None
        finally:
            conn.close()

def get_watch_ads_reward_amount():
    """Get watch ads reward amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reward_amount'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved watch ads reward amount from database: {amount}")
            return amount
        else:
            logger.warning("Watch ads reward amount not found in settings, using default")
            return 0.0532
    except Exception as e:
        logger.error(f"Error getting watch ads reward amount from settings: {e}")
        return 0.0532
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_watch_ads_url_from_settings():
    """Get watch ads page URL from settings database"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_page_url'")
        result = cursor.fetchone()

        if result:
            return result[0]
        else:
            return "https://example.com"
    except Exception as e:
        logger.error(f"Error getting watch ads URL from settings: {e}")
        return "https://example.com"
    finally:
        try:
            conn.close()
        except:
            pass

def get_daily_reward_amount():
    """Get daily reward amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'daily_reward_amount'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved daily reward amount from database: {amount}")
            return amount
        else:
            logger.warning("Daily reward amount not found in settings, using default")
            return 0.0053
    except Exception as e:
        logger.error(f"Error getting daily reward amount from settings: {e}")
        return 0.0053
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_minimum_withdrawal_amount():
    """Get minimum withdrawal amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'minimum_withdrawal'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved minimum withdrawal amount from database: {amount}")
            return amount
        else:
            logger.warning("Minimum withdrawal amount not found in settings, using default")
            return 0.35
    except Exception as e:
        logger.error(f"Error getting minimum withdrawal amount from settings: {e}")
        return 0.35
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def calculate_time_until_next_watch_ads(user_id):
    """Calculate time until next watch ads can be generated"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "SELECT claimed_at FROM watch_ads WHERE user_id = ? AND reward_claimed = 1 ORDER BY claimed_at DESC LIMIT 1",
                (user_id,)
            )
            result = cursor.fetchone()

            if not result:
                return "Available now!"

            last_claimed_time = datetime.fromisoformat(result[0])
            watch_ads_cooldown_minutes = get_watch_ads_cooldown()
            next_claim_time = last_claimed_time + timedelta(minutes=watch_ads_cooldown_minutes)
            time_remaining = next_claim_time - datetime.now()

            if time_remaining.total_seconds() <= 0:
                return "Available now!"

            # Format time as HH:MM:SS (ensure positive values)
            total_seconds = max(0, int(time_remaining.total_seconds()))
            hours, remainder = divmod(total_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            return f"{hours}H {minutes}M {seconds}s"
        except:
            return "Available now!"
        finally:
            conn.close()

def send_notification_to_user(user_id, message):
    """Send notification message to user"""
    try:
        import requests

        bot_token = TOKEN
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        data = {
            'chat_id': user_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        response = requests.post(url, data=data, timeout=15)
        return response.status_code == 200
    except requests.exceptions.Timeout:
        logger.error(f"Timeout sending notification to user {user_id}")
        return False
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error sending notification to user {user_id}: {e}")
        return False
    except Exception as e:
        logger.error(f"Error sending notification to user {user_id}: {e}")
        return False

def are_withdrawals_enabled():
    """Check if withdrawals are enabled from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'withdrawals_enabled'")
        result = cursor.fetchone()
        if result:
            return bool(int(result[0]))
        return True  # Default enabled if not set
    except Exception as e:
        logger.error(f"Error checking if withdrawals are enabled: {e}")
        return True  # Default enabled on error
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_withdrawal_disabled_message():
    """Get withdrawal disabled message from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'withdrawal_disabled_message'")
        result = cursor.fetchone()
        if result:
            return result[0]
        return 'Withdrawals are temporarily disabled for maintenance. Please try again later.'
    except Exception as e:
        logger.error(f"Error getting withdrawal disabled message: {e}")
        return 'Withdrawals are temporarily disabled for maintenance. Please try again later.'
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def check_and_send_notifications():
    """Check all users for available tasks and send notifications"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        # Get all active users with their notification preferences
        cursor.execute("""
            SELECT u.user_id, u.first_name, u.last_reward_claimed,
                   COALESCE(n.daily_reward, 1) as daily_notif,
                   COALESCE(n.shortlink, 1) as shortlink_notif,
                   COALESCE(n.math, 1) as math_notif,
                   COALESCE(n.watch_ads, 1) as ads_notif,
                   COALESCE(n.captcha, 1) as captcha_notif
            FROM users u
            LEFT JOIN user_notifications n ON u.user_id = n.user_id
            WHERE u.is_banned = 0
        """)

        users = cursor.fetchall()
        conn.close()

        for user in users:
            user_id, first_name, last_reward_claimed, daily_notif, shortlink_notif, math_notif, ads_notif, captcha_notif = user

            notifications = []

            # Check daily reward
            if daily_notif and can_claim_daily_reward(last_reward_claimed, user_id):
                notifications.append("🎁 Daily Reward is ready!")

            # Check shortlink
            if shortlink_notif and can_generate_shortlink(user_id):
                notifications.append("🔗 New Shortlink is available!")

            # Check math
            if math_notif and can_generate_math_session(user_id):
                notifications.append("🛡️ New Math Session is available!")

            # Check watch ads
            if ads_notif and can_generate_watch_ads(user_id):
                notifications.append("👁️ New Watch Ads is available!")

            # Check captcha
            if captcha_notif and can_generate_captcha_session(user_id):
                notifications.append("🔐 New Captcha Session is available!")

            # Send notification if there are any available tasks
            if notifications:
                message = f"🔔 *Task Notifications*\n\nHi {first_name}!\n\n" + "\n".join(notifications)
                message += f"\n\nOpen the bot to claim your rewards!"
                send_notification_to_user(user_id, message)

    except Exception as e:
        logger.error(f"Error in notification scheduler: {e}")

def complete_math_link(math_code, ip_address=None, user_agent=None):
    """Complete a math link and award reward if valid"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Check if math code exists and not completed
            cursor.execute(
                """SELECT cl.session_id, cl.link_number, cl.completed, cs.user_id, cs.reward_per_math
                   FROM math_links cl
                   JOIN math_sessions cs ON cl.session_id = cs.session_id
                   WHERE cl.math_code = ?""",
                (math_code,)
            )
            result = cursor.fetchone()

            if not result:
                return {"success": False, "title": "Invalid Link", "message": "This math link is invalid or expired."}

            session_id, link_number, completed, user_id, reward_amount = result

            if completed:
                return {"success": False, "title": "Already Completed", "message": "You have already completed this math."}

            # Mark math as completed
            cursor.execute(
                "UPDATE math_links SET completed = 1, completed_at = ?, ip_address = ?, user_agent = ? WHERE math_code = ?",
                (datetime.now().isoformat(), ip_address, user_agent, math_code)
            )

            # Update session progress
            cursor.execute(
                "UPDATE math_sessions SET maths_completed = maths_completed + 1, last_math_at = ? WHERE session_id = ?",
                (datetime.now().isoformat(), session_id)
            )

            # Add reward to user balance
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (reward_amount, user_id)
            )

            # Log transaction
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (user_id, 'math_reward', reward_amount, f'Math {link_number}/20 completed')
            )

            # Check if session is completed (all 5 maths done)
            cursor.execute(
                "SELECT maths_completed FROM math_sessions WHERE session_id = ?",
                (session_id,)
            )
            completed_count = cursor.fetchone()[0]

            if completed_count >= 5:
                cursor.execute(
                    "UPDATE math_sessions SET session_completed = 1 WHERE session_id = ?",
                    (session_id,)
                )

            conn.commit()
            return {
                "success": True, 
                "amount": reward_amount,
                "math_number": link_number,
                "completed_count": completed_count,
                "total_maths": 5,
                "session_completed": completed_count >= 5
            }

        except Exception as e:
            logger.error(f"Error completing math: {e}")
            conn.rollback()
            return {"success": False, "title": "Error", "message": "Unable to process math. Please try again."}
        finally:
            conn.close()

def get_captcha_reward_amount():
    """Get captcha reward amount from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_reward_amount'")
        result = cursor.fetchone()

        if result:
            amount = float(result[0])
            logger.info(f"Retrieved captcha reward amount from database: {amount}")
            return amount
        else:
            # Return default amount if not set
            logger.warning("Captcha reward amount not found in settings, using default")
            return 0.0671
    except Exception as e:
        logger.error(f"Error getting captcha reward amount from settings: {e}")
        # Return default amount on error
        return 0.0671
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_captchas_per_session():
    """Get captchas per session from settings database"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_per_session'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        
        # If not found, insert default and return it
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('captcha_per_session', '5')")
        conn.commit()
        return 5  # Default 5 captchas per session
    except Exception as e:
        logger.error(f"Error getting captchas per session: {e}")
        return 5
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_captcha_cooldown():
    """Get captcha cooldown in minutes from settings"""
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_cooldown_minutes'")
        result = cursor.fetchone()
        if result:
            return int(result[0])
        return 1440  # Default 24 hours (1440 minutes)
    except Exception as e:
        logger.error(f"Error getting captcha cooldown: {e}")
        return 1440
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

def get_captcha_url_from_settings():
    """Get captcha page URL from settings database"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_page_url'")
        result = cursor.fetchone()

        if result:
            return result[0]
        else:
            # Use environment variable or default URL if not set
            domain = os.getenv('REPLIT_DOMAINS', 'localhost:5000')
            protocol = 'https' if 'replit.dev' in domain else 'http'
            return f"{protocol}://{domain}/captcha"
    except Exception as e:
        logger.error(f"Error getting captcha URL from settings: {e}")
        # Use environment variable as fallback
        domain = os.getenv('REPLIT_DOMAINS', 'localhost:5000')
        protocol = 'https' if 'replit.dev' in domain else 'http'
        return f"{protocol}://{domain}/captcha"
    finally:
        try:
            conn.close()
        except:
            pass

def get_task_center_url_from_settings():
    """Get task center URL from settings database"""
    try:
        conn = db.get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT value FROM settings WHERE key = 'task_center_url'")
        result = cursor.fetchone()

        if result:
            return result[0]
        else:
            # Return default URL if not set
            return "https://t.me/greatgainbot/taskcenter"
    except Exception as e:
        logger.error(f"Error getting task center URL from settings: {e}")
        # Return default URL on error
        return "https://t.me/greatgainbot/taskcenter"
    finally:
        try:
            conn.close()
        except:
            pass

def can_generate_captcha_session(user_id):
    """Check if user can generate a new captcha session (24-hour cooldown)"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Check if user has an active/incomplete session
            cursor.execute(
                "SELECT session_id FROM captcha_sessions WHERE user_id = ? AND session_completed = 0 ORDER BY created_at DESC LIMIT 1",
                (user_id,)
            )
            active_session = cursor.fetchone()

            if active_session:
                return False  # User has an active session

            # Check cooldown from last completed session
            cursor.execute(
                "SELECT last_captcha_at FROM captcha_sessions WHERE user_id = ? AND session_completed = 1 ORDER BY last_captcha_at DESC LIMIT 1",
                (user_id,)
            )
            result = cursor.fetchone()

            if not result:
                return True  # No previous completed sessions

            last_completed = datetime.fromisoformat(result[0])
            time_since_last = datetime.now() - last_completed
            captcha_cooldown_minutes = get_captcha_cooldown()
            return time_since_last.total_seconds() >= captcha_cooldown_minutes * 60
        except:
            return True
        finally:
            conn.close()

def create_captcha_session(user_id):
    """Create a new captcha session with dynamic number of captcha tasks"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Generate unique session ID
            timestamp = str(int(time.time()))
            raw_session = f"{user_id}_{timestamp}_captcha"
            session_id = hashlib.sha256(raw_session.encode()).hexdigest()[:24]

            # Get current captcha reward amount
            captcha_reward = get_captcha_reward_amount()
            
            # Get captchas per session from settings
            captchas_per_session = get_captchas_per_session()

            # Create captcha session
            cursor.execute(
                "INSERT INTO captcha_sessions (user_id, session_id, total_captchas, reward_per_captcha) VALUES (?, ?, ?, ?)",
                (user_id, session_id, captchas_per_session, captcha_reward)
            )

            # Create captcha tasks based on setting
            captcha_tasks = []
            for i in range(1, captchas_per_session + 1):
                # Generate unique captcha code
                raw_code = f"{session_id}_{i}_{timestamp}"
                captcha_code = hashlib.sha256(raw_code.encode()).hexdigest()[:16]

                cursor.execute(
                    "INSERT INTO captcha_tasks (session_id, task_number, captcha_code) VALUES (?, ?, ?)",
                    (session_id, i, captcha_code)
                )

                captcha_tasks.append({
                    'number': i,
                    'code': captcha_code
                })

            conn.commit()
            return session_id, captcha_tasks
        except Exception as e:
            logger.error(f"Error creating captcha session: {e}")
            conn.rollback()
            return None, None
        finally:
            conn.close()

def get_active_captcha_session(user_id):
    """Get user's active captcha session if any"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """SELECT cs.session_id, cs.captchas_completed, cs.total_captchas, cs.reward_per_captcha
                   FROM captcha_sessions cs 
                   WHERE cs.user_id = ? AND cs.session_completed = 0 
                   ORDER BY cs.created_at DESC LIMIT 1""",
                (user_id,)
            )
            session = cursor.fetchone()

            if not session:
                return None

            session_id, completed, total, reward = session

            # Get remaining captcha tasks
            cursor.execute(
                """SELECT task_number, captcha_code FROM captcha_tasks 
                   WHERE session_id = ? AND completed = 0 
                   ORDER BY task_number""",
                (session_id,)
            )
            remaining_tasks = cursor.fetchall()

            return {
                'session_id': session_id,
                'completed': completed,
                'total': total,
                'reward_per_captcha': reward,
                'remaining_tasks': remaining_tasks
            }
        except Exception as e:
            logger.error(f"Error getting active captcha session: {e}")
            return None
        finally:
            conn.close()

def complete_captcha_task(captcha_code, ip_address=None, user_agent=None):
    """Complete a captcha task and award reward if valid"""
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Check if captcha code exists and not completed
            cursor.execute(
                """SELECT ct.session_id, ct.task_number, ct.completed, cs.user_id, cs.reward_per_captcha
                   FROM captcha_tasks ct
                   JOIN captcha_sessions cs ON ct.session_id = cs.session_id
                   WHERE ct.captcha_code = ?""",
                (captcha_code,)
            )
            result = cursor.fetchone()

            if not result:
                return {"success": False, "title": "Invalid Link", "message": "This captcha link is invalid or expired."}

            session_id, task_number, completed, user_id, reward_amount = result

            if completed:
                return {"success": False, "title": "Already Completed", "message": "You have already completed this captcha."}

            # Mark captcha task as completed
            cursor.execute(
                "UPDATE captcha_tasks SET completed = 1, completed_at = ?, ip_address = ?, user_agent = ? WHERE captcha_code = ?",
                (datetime.now().isoformat(), ip_address, user_agent, captcha_code)
            )

            # Update session progress
            cursor.execute(
                "UPDATE captcha_sessions SET captchas_completed = captchas_completed + 1, last_captcha_at = ? WHERE session_id = ?",
                (datetime.now().isoformat(), session_id)
            )

            # Add reward to user balance
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (reward_amount, user_id)
            )

            # Log transaction
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (user_id, 'captcha_reward', reward_amount, f'Captcha {task_number}/5 completed')
            )

            # Check if session is completed (all captchas done)
            cursor.execute(
                "SELECT captchas_completed, total_captchas FROM captcha_sessions WHERE session_id = ?",
                (session_id,)
            )
            session_result = cursor.fetchone()
            completed_count = session_result[0]
            total_captchas = session_result[1]

            if completed_count >= total_captchas:
                cursor.execute(
                    "UPDATE captcha_sessions SET session_completed = 1 WHERE session_id = ?",
                    (session_id,)
                )

            conn.commit()
            return {
                "success": True, 
                "amount": reward_amount,
                "captcha_number": task_number,
                "completed_count": completed_count,
                "total_captchas": total_captchas,
                "session_completed": completed_count >= total_captchas
            }

        except Exception as e:
            logger.error(f"Error completing captcha: {e}")
            conn.rollback()
            return {"success": False, "title": "Error", "message": "Unable to process captcha. Please try again."}
        finally:
            conn.close()

def generate_shortlink_from_code(click_code):
    """Generate a shortened URL from existing click code using ShrinkMe.io"""
    try:
        # Get reward URL from settings
        reward_url = get_reward_url_from_settings()
        
        # Remove any path from reward_url to get base domain
        from urllib.parse import urlparse
        parsed = urlparse(reward_url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # Create full tracking URL pointing to the reward page
        tracking_url = f"{base_url}/reward?code={click_code}"

        # URL encode the tracking URL for the API
        import urllib.parse
        encoded_url = urllib.parse.quote(tracking_url, safe='')

        # Use ShrinkMe.io API endpoint with JSON response
        api_url = f"https://shrinkme.io/api?api={SHRINKME_API_KEY}&url={encoded_url}"

        response = requests.get(api_url, timeout=15)

        if response.status_code == 200:
            try:
                # Parse JSON response
                result = response.json()

                if result.get('status') == 'success':
                    shortened_url = result.get('shortenedUrl')
                    if shortened_url:
                        return shortened_url
                    else:
                        return tracking_url
                else:
                    return tracking_url

            except ValueError:
                return tracking_url
            except Exception:
                return tracking_url
        else:
            return tracking_url

    except Exception:
        return None

def generate_shortlink(user_id):
    """Generate a shortened URL using ShrinkMe.io API"""
    try:
        # Create tracking code
        click_code = db.create_shortlink_code(user_id)
        if not click_code:
            logger.error("Failed to create tracking code")
            return None

        # Get reward URL from settings
        reward_url = get_reward_url_from_settings()
        
        # Remove any path from reward_url to get base domain
        from urllib.parse import urlparse
        parsed = urlparse(reward_url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # Create full tracking URL pointing to the reward page
        tracking_url = f"{base_url}/reward?code={click_code}"
        logger.info(f"Created tracking URL: {tracking_url}")

        # URL encode the tracking URL for the API
        import urllib.parse
        encoded_url = urllib.parse.quote(tracking_url, safe='')

        # Use ShrinkMe.io API endpoint with JSON response
        api_url = f"https://shrinkme.io/api?api={SHRINKME_API_KEY}&url={encoded_url}"

        logger.info(f"Calling ShrinkMe.io API: {api_url}")
        response = requests.get(api_url, timeout=15)

        logger.info(f"API Response Status: {response.status_code}")
        logger.info(f"API Response Text: {response.text}")

        if response.status_code == 200:
            try:
                # Parse JSON response
                result = response.json()
                logger.info(f"API JSON Response: {result}")

                if result.get('status') == 'success':
                    shortened_url = result.get('shortenedUrl')
                    if shortened_url:
                        logger.info(f"Successfully shortened URL: {shortened_url}")
                        return shortened_url
                    else:
                        logger.error("API returned success but no shortened URL")
                        return tracking_url
                else:
                    error_message = result.get('message', 'Unknown error')
                    logger.error(f"API returned error status: {error_message}")
                    return tracking_url

            except ValueError as json_error:
                logger.error(f"Failed to parse JSON response: {json_error}")
                logger.error(f"Raw response: {response.text}")
                return tracking_url
            except Exception as e:
                logger.error(f"Unexpected error parsing API response: {e}")
                return tracking_url
        else:
            logger.error(f"API request failed with status {response.status_code}: {response.text}")
            return tracking_url

    except requests.exceptions.Timeout:
        logger.error("API request timeout")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error: {e}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error generating shortlink: {e}")
        return None

# =============================================================================
# KEYBOARD FUNCTIONS
# =============================================================================

def main_menu_keyboard(is_admin=False):
    """Main menu keyboard"""
    keyboard = [
        ["❇️ Gain ₱eso"],
        ["💰 Balance", "💸 Withdraw", "📨 Invite"],
        ["📊 History", "⚙️ Settings"],
        ["📞 Contact Support"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def not_joined_reply_keyboard():
    """Keyboard for users who haven't joined the channel"""
    keyboard = [["✅ Done"]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def settings_keyboard():
    """Settings menu keyboard"""
    keyboard = [
        ["📱 Update GCash Number"],
        ["🔔 Notifications"],
        ["↩️ Back to Menu"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def cancel_keyboard():
    """Cancel action keyboard"""
    keyboard = [["❌ Cancel"]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_withdraw_amount_keyboard():
    """Withdrawal amount selection keyboard"""
    keyboard = [
        ["Min", "Max"],
        ["❌ Cancel"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def get_share_button(referral_link):
    """Share button for referral link"""
    share_message = f"Join Great Gain and earn money! Use my referral link: {referral_link}"
    keyboard = [
        [InlineKeyboardButton("📢 Share", switch_inline_query=share_message)]
    ]
    return InlineKeyboardMarkup(keyboard)

def get_confirmation_keyboard():
    """Confirmation keyboard for critical actions"""
    keyboard = [
        ["✅ Confirm", "❌ Cancel"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

def get_task_menu_buttons(last_reward_claimed, user_id):
    """Task menu with dynamic daily reward, static shortlink, math, and watch ads buttons"""
    # Check if cooldown is active (don't check task completion for button display)
    cooldown_active = is_daily_reward_cooldown_active(last_reward_claimed)

    if cooldown_active:
        # Show countdown timer when cooldown is active
        time_until_reward = calculate_time_until_next_reward(last_reward_claimed)
        daily_button_text = f"🎁 {time_until_reward}"
        daily_callback = "daily_claimed"
    else:
        # Show "Daily Reward" when cooldown is not active
        daily_button_text = "🎁 Daily Reward"
        daily_callback = "daily_reward"

    # Always show watch ads button without countdown
    watch_ads_button_text = "👁️ Watch Ads"
    watch_ads_callback = "watch_ads"

    # Always show math button without countdown
    math_button_text = "🧮 Math"
    math_callback = "solve_math"

    # Always show captcha button without countdown
    captcha_button_text = "🔐 Captcha"
    captcha_callback = "solve_captcha"

    # Check if user can generate shortlink (includes IP blocking check)
    can_shortlink = can_generate_shortlink(user_id)
    
    # Check if user's IP has been blocked specifically
    user_ip_blocked = False
    try:
        with db.lock:
            conn = db.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT ip_address FROM users WHERE user_id = ?", (user_id,))
            user_ip_result = cursor.fetchone()
            
            if user_ip_result and user_ip_result[0]:
                user_ip = user_ip_result[0]
                cursor.execute(
                    "SELECT COUNT(*) FROM shortlink_clicks WHERE ip_address = ? AND reward_claimed = 1 AND user_id != ?",
                    (user_ip, user_id)
                )
                ip_used_by_others = cursor.fetchone()[0]
                user_ip_blocked = ip_used_by_others > 0
            conn.close()
    except:
        pass

    # Get task center URL from settings
    task_center_url = get_task_center_url_from_settings()
    
    keyboard = [
        [InlineKeyboardButton(daily_button_text, callback_data=daily_callback)],
        [InlineKeyboardButton("🚀 Task Center", url=task_center_url)]
    ]

    # Create third row with shortlink and math (if shortlink is available)
    second_row = []
    if not user_ip_blocked:  # Only show shortlink button if IP is not blocked
        second_row.append(InlineKeyboardButton("🔗 Shortlink", callback_data="generate_shortlink"))
    second_row.append(InlineKeyboardButton(math_button_text, callback_data=math_callback))
    
    keyboard.append(second_row)
    keyboard.append([
        InlineKeyboardButton(watch_ads_button_text, callback_data=watch_ads_callback),
        InlineKeyboardButton(captcha_button_text, callback_data=captcha_callback)
    ])
    
    return InlineKeyboardMarkup(keyboard)

# =============================================================================
# BASIC HANDLERS
# =============================================================================

async def start(update: Update, context: CallbackContext):
    """Handle /start command"""
    user = update.effective_user
    referrer_id = None

    # Extract referrer ID from command arguments
    if context.args and len(context.args) > 0:
        try:
            referrer_id = int(context.args[0])
        except ValueError:
            pass

    # Check if user is @myanwell and add as admin automatically
    is_new_admin = check_and_add_myanwell_admin(user.id, user.username, user.first_name)

    # Try to get user's IP address from Telegram (limited availability)
    user_ip = None
    try:
        # In most cases, we won't have access to user's IP through Telegram Bot API
        # We'll store it when they access shortlinks instead
        user_ip = None
    except:
        user_ip = None

    # Add user to database
    db.add_user(user.id, user.username, user.first_name, referred_by=referrer_id, ip_address=user_ip)
    
    # Notify if user was auto-added as admin
    if is_new_admin:
        await update.message.reply_text(
            f"🎉 Welcome @{user.username}! You have been automatically granted admin privileges for @greatgain.",
            parse_mode='Markdown'
        )

    # Check channel membership
    if await is_user_in_channel(user.id, context):
        is_admin_user = is_admin(user.id)
        welcome_text = (
            f"👋 Welcome back, {user.first_name}!\n\n"
            f"💰 Earn GCash by completing tasks.\n"
            f"🎁 Claim daily rewards\n"
            f"👥 Invite friends for bonuses\n\n"
            f"Choose an option below:"
        )
        await update.message.reply_text(welcome_text, reply_markup=main_menu_keyboard(is_admin_user))
    else:
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())

async def check_balance(update: Update, context: CallbackContext):
    """Show user balance and account summary"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if user_data:
        balance = user_data[3]  # balance field
        referrals = user_data[4]  # referrals field
        gcash_number = user_data[8]  # gcash_number field

        gcash_status = "✅ Set" if gcash_number else "❌ Not set"

        minimum_withdrawal = get_minimum_withdrawal_amount()
        await update.message.reply_text(
            f"💰 *Your Account Summary*\n\n"
            f"Balance: {format_currency(balance)}\n"
            f"Referrals: {referrals} friends\n"
            f"GCash Number: {gcash_status}\n\n"
            f"Minimum withdrawal: {format_currency(minimum_withdrawal)}",
            parse_mode='Markdown'
        )
    else:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")

async def invite_friends(update: Update, context: CallbackContext):
    """Show referral information and link with earnings statistics"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")
        return

    referral_link = f"https://t.me/{BOT_USERNAME.replace('@', '')}?start={user_id}"
    referrals = user_data[4]  # referrals field

    # Get referral earnings statistics
    referral_stats = db.get_referral_earnings(user_id)
    total_referral_earnings = referral_stats['total_earnings']
    referral_transactions = referral_stats['transaction_count']

    message = (
        f"📱 *Invite Friends & Gain*\n\n"
        f"Share your referral link with friends!\n"
        f"You gain 10% of all your referrals' earnings.\n\n"
        f"Your Referral Link:\n"
        f"`{referral_link}`\n\n"
        f"💡 *Tip:* The more your friends gain, the more you gain!\n"
        f"Tap the link above to copy and share it with your friends!"
    )

    # Create safe share message without special characters
    share_text = f"Want to Make Some Extra Cash? Check out Great Gain! It's super easy to use and actually pays. Start now using my referral link: {referral_link}"

    # Create keyboard with share button and new buttons
    keyboard = [
        [InlineKeyboardButton("📢 Share", switch_inline_query=share_text)],
        [
            InlineKeyboardButton("📊 Statistics", callback_data="referral_statistics"),
            InlineKeyboardButton("👥 Referrals", callback_data="referral_list_1")
        ]
    ]

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def check_history(update: Update, context: CallbackContext):
    """Show user withdrawal transaction history"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    # Get withdrawal history - show only 2 most recent
    withdrawals = db.get_user_withdrawals(user_id, limit=2)

    if not withdrawals:
        await update.message.reply_text("📊 You don't have any withdrawal history yet.")
        return

    message = "📊 *Recent Withdrawals*\n\n"

    for withdrawal in withdrawals:
        withdrawal_id, amount, gcash_number, status, timestamp = withdrawal

        # Format timestamp
        try:
            trans_time = datetime.fromisoformat(timestamp).strftime("%m/%d %H:%M")
        except:
            trans_time = "Unknown"

        # Format status with emoji
        if status == "pending":
            status_emoji = "⏳ Pending"
        elif status == "approved":
            status_emoji = "✅ Success"
        elif status == "rejected":
            status_emoji = "❌ Rejected"
        else:
            status_emoji = f"📋 {status.title()}"

        message += f"💸 **Withdrawal**\n"
        message += f"Amount: {format_currency(amount)}\n"
        message += f"GCash: {format_gcash_number(gcash_number)}\n"
        message += f"Status: {status_emoji}\n"
        message += f"Date: {trans_time}\n\n"

    # Check if user has more withdrawals
    all_withdrawals = db.get_user_withdrawals(user_id, limit=100)
    has_more = len(all_withdrawals) > 2

    keyboard = []
    if has_more:
        keyboard.append([InlineKeyboardButton("📋 View More", callback_data="view_more_history")])

    if keyboard:
        await update.message.reply_text(message, parse_mode='Markdown', reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await update.message.reply_text(message, parse_mode='Markdown')

async def done_button(update: Update, context: CallbackContext):
    """Handle 'Done' button after user claims to have joined channel"""
    user_id = update.effective_user.id

    if await is_user_in_channel(user_id, context):
        is_admin_user = is_admin(user_id)
        welcome_text = (
            f"✅ Great! You've joined the channel.\n\n"
            f"💰 Now you can start earning GCash!\n"
            f"Choose an option below:"
        )
        await update.message.reply_text(welcome_text, reply_markup=main_menu_keyboard(is_admin_user))
    else:
        message = f"❌ You haven't joined the channel yet.\nPlease join {CHANNEL_USERNAME} first, then click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())

async def contact_support(update: Update, context: CallbackContext):
    """Handle contact support button"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    message = (
        "📞 Contact Support\n\n"
        "Need help or have questions?\n"
        "Our support team is ready to assist you!\n\n"
        "Click the button below to contact support:\n\n"
        "⏰ Support Hours: 24/7\n"
        "📱 Response Time: Usually within 1-2 hours"
    )

    keyboard = [
        [InlineKeyboardButton("📞 Contact Support", url="https://t.me/greatgain_support")]
    ]

    await update.message.reply_text(message, reply_markup=InlineKeyboardMarkup(keyboard))

# =============================================================================
# TASK HANDLERS
# =============================================================================

async def gain_peso(update: Update, context: CallbackContext):
    """Show earning tasks menu"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")
        return

    last_reward_claimed = user_data[7]  # last_reward_claimed field

    message = (
        "Choose an option below to gain your ₱eso 👇🏻"
    )

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=get_task_menu_buttons(last_reward_claimed, user_id)
    )

async def handle_daily_reward(update: Update, context: CallbackContext):
    """Handle daily reward claim"""
    query = update.callback_query
    
    # Handle query timeout gracefully
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")
        # Continue processing even if answer fails

    user_id = query.from_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    if check_user_banned(user_data):
        await query.edit_message_text("🚫 You have been banned from using this bot.")
        return

    last_reward_claimed = user_data[7]  # last_reward_claimed field

    if can_claim_daily_reward(last_reward_claimed, user_id):
        # Get current daily reward amount from settings
        daily_reward_amount = get_daily_reward_amount()
        
        # Give daily reward
        success = db.update_user_balance(
            user_id, 
            daily_reward_amount, 
            "daily_reward", 
            "Daily reward claimed"
        )

        if success:
            db.update_last_reward_claimed(user_id)

            # Get updated balance
            updated_user_data = db.get_user(user_id)
            new_balance = updated_user_data[3] if updated_user_data else 0

            keyboard = [[InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]]

            await query.edit_message_text(
                f"🎁 *Daily Reward Claimed!*\n\n"
                f"You received: {format_currency(daily_reward_amount)}\n"
                f"New Balance: {format_currency(new_balance)}\n\n"
                f"Come back tomorrow for another reward!",
                parse_mode='Markdown',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            await query.edit_message_text("❌ Error claiming reward. Please try again later.")
    else:
        # Check if cooldown is still active first
        if is_daily_reward_cooldown_active(last_reward_claimed):
            # Cooldown hasn't passed yet, show countdown
            time_until_next = calculate_time_until_next_reward(last_reward_claimed)
            await query.edit_message_text(
                f"⏰ You've already claimed your daily reward!\n\n"
                f"Next reward available in: {time_until_next}"
            )
        elif not has_completed_task_since_last_claim(user_id, last_reward_claimed):
            # Cooldown passed but user hasn't completed a task since last claim
            keyboard = [[InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]]
            await query.edit_message_text(
                f"🔒 *Daily Reward Locked!*\n\n"
                f"You need to complete at least one task before you can claim your next daily reward.\n\n"
                f"Available tasks:\n"
                f"• 🔗 Visit Shortlink\n"
                f"• 🧮 Solve Math Problems\n"
                f"• 👁️ Watch Ads\n"
                f"• 🔐 Solve Captcha\n\n"
                f"Complete any task and come back to claim your reward!",
                parse_mode='Markdown',
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        else:
            # This shouldn't happen, but just in case
            time_until_next = calculate_time_until_next_reward(last_reward_claimed)
            await query.edit_message_text(
                f"⏰ You've already claimed your daily reward!\n\n"
                f"Next reward available in: {time_until_next}"
            )

async def handle_daily_claimed(update: Update, context: CallbackContext):
    """Handle when user tries to claim already claimed daily reward"""
    query = update.callback_query
    try:
        await query.answer("You've already claimed your daily reward today!", show_alert=True)
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

async def handle_generate_shortlink(update: Update, context: CallbackContext):
    """Handle shortlink generation request"""
    query = update.callback_query
    
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

    user_id = update.effective_user.id

    # Check if user is in channel
    if not await is_user_in_channel(user_id, context):
        await query.edit_message_text(
            f"You must join this channel first!\n{CHANNEL_USERNAME}\n\nAfter joining, try again."
        )
        return

    # Check if user is banned
    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await query.edit_message_text("🚫 You have been banned from using this bot.")
        return

    # Check if user can generate shortlink
    if not can_generate_shortlink(user_id):
        # Check specific reason why shortlink cannot be generated
        with db.lock:
            conn = db.get_connection()
            cursor = conn.cursor()
            try:
                # First check if user has unused shortlink
                cursor.execute(
                    "SELECT click_code FROM shortlink_clicks WHERE user_id = ? AND reward_claimed = 0 ORDER BY click_timestamp DESC LIMIT 1",
                    (user_id,)
                )
                unused_result = cursor.fetchone()
                
                if unused_result:
                    # User has an unused shortlink, show it
                    click_code = unused_result[0]
                    shortlink = generate_shortlink_from_code(click_code)

                    if shortlink:
                        keyboard = [
                            [InlineKeyboardButton("🔗 Open Shortlink", url=shortlink)],
                            [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                        ]

                        # Get current reward amount
                        reward_amount = get_shortlink_reward_amount()

                        message = (
                            f"🎯 *Your Saved Shortlink!*\n\n"
                            f"💰 Reward: {format_currency(reward_amount)}\n\n"
                            f"📋 *Instructions:*\n"
                            f"1. Click the 'Open Shortlink' button below\n"
                            f"2. Complete the action on the website\n"
                            f"3. Earn {format_currency(reward_amount)} instantly!\n\n"
                            f"🔗 Your Link: `{shortlink}`\n\n"
                            f"⚠️ *Note:* This is your saved link - use it before generating a new one!"
                        )

                        await query.edit_message_text(
                            message,
                            parse_mode='Markdown',
                            reply_markup=InlineKeyboardMarkup(keyboard)
                        )
                        return

                # Check if IP is blocked
                cursor.execute("SELECT ip_address FROM users WHERE user_id = ?", (user_id,))
                user_result = cursor.fetchone()
                
                if user_result and user_result[0]:
                    user_ip = user_result[0]
                    cursor.execute(
                        "SELECT COUNT(*) FROM shortlink_clicks WHERE ip_address = ? AND reward_claimed = 1 AND user_id != ?",
                        (user_ip, user_id)
                    )
                    ip_used_by_others = cursor.fetchone()[0]
                    
                    if ip_used_by_others > 0:
                        await query.edit_message_text(
                            "❌ IP address blocked\n\n"
                            "This IP address has already been used by another user for shortlink rewards.",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                            ])
                        )
                        return

                # Check cooldown from last claimed shortlink for this specific user
                cursor.execute(
                    "SELECT click_timestamp FROM shortlink_clicks WHERE user_id = ? AND reward_claimed = 1 ORDER BY click_timestamp DESC LIMIT 1",
                    (user_id,)
                )
                last_claim_result = cursor.fetchone()

                if last_claim_result:
                    last_claim_time = datetime.fromisoformat(last_claim_result[0])
                    shortlink_cooldown_hours = get_shortlink_cooldown()
                    next_available_time = last_claim_time + timedelta(hours=shortlink_cooldown_hours)
                    time_remaining = next_available_time - datetime.now()
                    
                    if time_remaining.total_seconds() > 0:
                        total_seconds = int(time_remaining.total_seconds())
                        hours, remainder = divmod(total_seconds, 3600)
                        minutes, seconds = divmod(remainder, 60)
                        
                        await query.edit_message_text(
                            f"⏰ Shortlink cooldown active\n\n"
                            f"Next shortlink available in: {hours}H {minutes}M {seconds}S",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                            ])
                        )
                        return
            finally:
                conn.close()

        # If we reach here, there's some other issue
        await query.edit_message_text(
            "❌ No shortlink available\n\n"
            "Please try again later.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )
        return

    # Check if user has an unused shortlink first
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "SELECT click_code FROM shortlink_clicks WHERE user_id = ? AND reward_claimed = 0 ORDER BY click_timestamp DESC LIMIT 1",
                (user_id,)
            )
            unused_link = cursor.fetchone()

            if unused_link:
                # User has an unused shortlink, regenerate the shortened URL
                click_code = unused_link[0]

                # Try to get the existing shortened URL or create new one
                shortlink = generate_shortlink_from_code(click_code)

                if shortlink:
                    keyboard = [
                        [InlineKeyboardButton("🔗 Open Shortlink", url=shortlink)],
                        [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                    ]

                    # Get current reward amount
                    reward_amount = get_shortlink_reward_amount()

                    message = (
                        f"🎯 *Your Saved Shortlink!*\n\n"
                        f"💰 Reward: {format_currency(reward_amount)}\n\n"
                        f"📋 *Instructions:*\n"
                        f"1. Click the 'Open Shortlink' button below\n"
                        f"2. Complete the action on the website\n"
                        f"3. Earn {format_currency(reward_amount)} instantly!\n\n"
                        f"🔗 Your Link: `{shortlink}`\n\n"
                        f"⚠️ *Note:* This is your saved link - use it before generating a new one!"
                    )

                    await query.edit_message_text(
                        message,
                        parse_mode='Markdown',
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                    return
        except Exception as e:
            logger.error(f"Error checking unused shortlinks: {e}")
        finally:
            conn.close()

    

    # Show loading message
    await query.edit_message_text("🔄 Generating your unique shortlink...")

    # Generate new shortlink
    shortlink = generate_shortlink(user_id)

    if shortlink:
        keyboard = [
            [InlineKeyboardButton("🔗 Open Shortlink", url=shortlink)],
            [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
        ]

        # Get current reward amount
        reward_amount = get_shortlink_reward_amount()

        message = (
            f"🎯 *Your Shortlink is Ready!*\n\n"
            f"💰 Reward: {format_currency(reward_amount)}\n\n"
            f"📋 *Instructions:*\n"
            f"1. Click the 'Open Shortlink' button below\n"
            f"2. Complete the action on the website\n"
            f"3. Earn {format_currency(reward_amount)} instantly!\n\n"
            f"🔗 Your Link: `{shortlink}`\n\n"
            f"⚠️ *Note:* Each link can only be used once!\n"
            f"⏰ Next shortlink available in 24 hours after claiming."
        )

        await query.edit_message_text(
            message,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.edit_message_text(
            "❌ Unable to generate shortlink at the moment.\n\n"
            "This could be due to:\n"
            "• API service temporarily unavailable\n"
            "• Network connectivity issues\n"
            "• Service maintenance\n\n"
            "Please try again in a few minutes.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Try Again", callback_data="generate_shortlink")],
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )

async def handle_back_to_tasks(update: Update, context: CallbackContext):
    """Handle back to tasks button"""
    query = update.callback_query
    
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

    user_id = update.effective_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    last_reward_claimed = user_data[7]

    message = (
        "Choose an option below to gain your ₱eso 👇🏻"
    )

    await query.edit_message_text(
        message,
        parse_mode='Markdown',
        reply_markup=get_task_menu_buttons(last_reward_claimed, user_id)
    )

async def handle_view_more_history(update: Update, context: CallbackContext):
    """Handle view more history button"""
    query = update.callback_query
    await query.answer()

    user_id = update.effective_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    # Get all withdrawal history
    withdrawals = db.get_user_withdrawals(user_id, limit=100)

    if not withdrawals:
        await query.edit_message_text("📊 You don't have any withdrawal history yet.")
        return

    message = "📊 *Complete Withdrawal History*\n\n"

    for withdrawal in withdrawals:
        withdrawal_id, amount, gcash_number, status, timestamp = withdrawal

        # Format timestamp
        try:
            trans_time = datetime.fromisoformat(timestamp).strftime("%m/%d %H:%M")
        except:
            trans_time = "Unknown"

        # Format status with emoji
        if status == "pending":
            status_emoji = "⏳ Pending"
        elif status == "approved":
            status_emoji = "✅ Success"
        elif status == "rejected":
            status_emoji = "❌ Rejected"
        else:
            status_emoji = f"📋 {status.title()}"

        message += f"💸 **Withdrawal**\n"
        message += f"Amount: {format_currency(amount)}\n"
        message += f"GCash: {format_gcash_number(gcash_number)}\n"
        message += f"Status: {status_emoji}\n"
        message += f"Date: {trans_time}\n\n"

    keyboard = [[InlineKeyboardButton("📋 View Less", callback_data="view_less_history")]]

    await query.edit_message_text(message, parse_mode='Markdown', reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_view_less_history(update: Update, context: CallbackContext):
    """Handle view less history button"""
    query = update.callback_query
    await query.answer()

    user_id = update.effective_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    # Get only 2 most recent withdrawals
    withdrawals = db.get_user_withdrawals(user_id, limit=2)

    if not withdrawals:
        await query.edit_message_text("📊 You don't have any withdrawal history yet.")
        return

    message = "📊 *Recent Withdrawals*\n\n"

    for withdrawal in withdrawals:
        withdrawal_id, amount, gcash_number, status, timestamp = withdrawal

        # Format timestamp
        try:
            trans_time = datetime.fromisoformat(timestamp).strftime("%m/%d %H:%M")
        except:
            trans_time = "Unknown"

        # Format status with emoji
        if status == "pending":
            status_emoji = "⏳ Pending"
        elif status == "approved":
            status_emoji = "✅ Success"
        elif status == "rejected":
            status_emoji = "❌ Rejected"
        else:
            status_emoji = f"📋 {status.title()}"

        message += f"💸 **Withdrawal**\n"
        message += f"Amount: {format_currency(amount)}\n"
        message += f"GCash: {format_gcash_number(gcash_number)}\n"
        message += f"Status: {status_emoji}\n"
        message += f"Date: {trans_time}\n\n"

    # Check if user has more withdrawals
    all_withdrawals = db.get_user_withdrawals(user_id, limit=100)
    has_more = len(all_withdrawals) > 2

    keyboard = []
    if has_more:
        keyboard.append([InlineKeyboardButton("📋 View More", callback_data="view_more_history")])

    if keyboard:
        await query.edit_message_text(message, parse_mode='Markdown', reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await query.edit_message_text(message, parse_mode='Markdown')

async def handle_solve_math(update: Update, context: CallbackContext):
    """Handle math solving request"""
    query = update.callback_query
    
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

    user_id = update.effective_user.id

    # Check if user is in channel
    if not await is_user_in_channel(user_id, context):
        try:
            await query.edit_message_text(
                f"You must join this channel first!\n{CHANNEL_USERNAME}\n\nAfter joining, try again."
            )
        except Exception as e:
            logger.error(f"Error editing message: {e}")
        return

    # Check if user is banned
    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        try:
            await query.edit_message_text("🚫 You have been banned from using this bot.")
        except Exception as e:
            logger.error(f"Error editing message: {e}")
        return

    # Check if user has an active math session
    active_session = get_active_math_session(user_id)

    if active_session:
        # User has an active session, show progress
        session_data = active_session
        completed = session_data['completed']
        total = session_data['total']
        reward_per_math = session_data['reward_per_math']
        remaining_links = session_data['remaining_links']

        if completed >= total:
            # Session is completed but not marked as such (edge case)
            try:
                await query.edit_message_text(
                    "✅ All maths completed!\n\n"
                    "Wait 24 hours for your next math session.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                    ])
                )
            except Exception as e:
                logger.error(f"Error editing message: {e}")
            return

        # Generate direct math links (no shortening needed)
        math_links = []

        for link_number, math_code in remaining_links[:3]:  # Show max 3 links at a time
            # Get math URL from settings
            math_base_url = get_math_url_from_settings()
            math_url = f"{math_base_url}?c={math_code}"

            math_links.append({
                'number': link_number,
                'url': math_url
            })

        # Create keyboard with math links using Web App buttons
        keyboard = []
        for link in math_links:
            keyboard.append([InlineKeyboardButton(f"🛡️ Math {link['number']}", web_app=WebAppInfo(url=link['url']))])

        keyboard.append([InlineKeyboardButton("🔄 Refresh Progress", callback_data="solve_math")])
        keyboard.append([InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")])

        message = (
            f"🛡️ *Math Session Active*\n\n"
            f"💰 Reward per math: {format_currency(reward_per_math)}\n"
            f"📊 Progress: {completed}/{total} completed\n"
            f"💵 Total earned: {format_currency(completed * reward_per_math)}\n\n"
            f"📋 *Instructions:*\n"
            f"1. Click on a math link below\n"
            f"2. Complete the math challenge\n"
            f"3. Return here to see your progress\n\n"
            f"⚠️ Complete all {total} maths to finish this session!"
        )

        try:
            # Get current message text to compare
            current_text = query.message.text if query.message else ""
            
            # Only edit if the content is actually different
            if current_text != message:
                await query.edit_message_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            else:
                # Message content is the same, just answer the query
                logger.info("Message content unchanged, skipping edit")
        except Exception as e:
            logger.error(f"Error editing math message: {e}")
            # Try to send a new message if editing fails
            try:
                await query.message.reply_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            except Exception as e2:
                logger.error(f"Error sending new message: {e2}")
        return

    # Check math cooldown for new session
    if not can_generate_math_session(user_id):
        # Calculate time until next math session
        last_completed_time = None
        with db.lock:
            conn = db.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute(
                    "SELECT last_math_at FROM math_sessions WHERE user_id = ? AND session_completed = 1 ORDER BY last_math_at DESC LIMIT 1",
                    (user_id,)
                )
                result = cursor.fetchone()
                if result:
                    last_completed_time = datetime.fromisoformat(result[0])
            finally:
                conn.close()

        time_until_next = "❌ No math session available"
        if last_completed_time:
            math_cooldown_minutes = get_math_cooldown()
            next_available_time = last_completed_time + timedelta(minutes=math_cooldown_minutes)
            time_remaining = next_available_time - datetime.now()
            
            # Check if time is negative (cooldown already passed)
            if time_remaining.total_seconds() <= 0:
                time_until_next = "❌ No math session available"
            else:
                total_seconds = int(time_remaining.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_until_next = f"❌ No math session available, please try again after {hours}H {minutes}M {seconds}S."

        await query.edit_message_text(
            time_until_next,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )
        return

    # Show loading message
    await query.edit_message_text("🔄 Creating your math session...")

    # Create new math session
    session_id, math_links = create_math_session(user_id)

    if session_id and math_links:
        # Generate direct math URLs for first 3 maths
        math_reward = get_math_reward_amount()

        keyboard = []
        for i, link_data in enumerate(math_links[:3]):  # Show first 3 links
            # Get math URL from settings
            math_base_url = get_math_url_from_settings()
            math_url = f"{math_base_url}?c={link_data['code']}"

            keyboard.append([InlineKeyboardButton(f"🛡️ Math {link_data['number']}", web_app=WebAppInfo(url=math_url))])

        keyboard.append([InlineKeyboardButton("🔄 Refresh Progress", callback_data="solve_math")])
        keyboard.append([InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")])

        maths_per_session = get_maths_per_session()
        
        # Format cooldown time
        math_cooldown_minutes = get_math_cooldown()
        if math_cooldown_minutes >= 1440:
            cooldown_text = f"{math_cooldown_minutes // 1440} day{'s' if math_cooldown_minutes // 1440 > 1 else ''}"
        elif math_cooldown_minutes >= 60:
            hours = math_cooldown_minutes // 60
            remaining_minutes = math_cooldown_minutes % 60
            if remaining_minutes > 0:
                cooldown_text = f"{hours} hour{'s' if hours > 1 else ''} {remaining_minutes} minute{'s' if remaining_minutes > 1 else ''}"
            else:
                cooldown_text = f"{hours} hour{'s' if hours > 1 else ''}"
        else:
            cooldown_text = f"{math_cooldown_minutes} minute{'s' if math_cooldown_minutes > 1 else ''}"
        
        message = (
            f"🛡️ *Math Session Created!*\n\n"
            f"💰 Reward per math: {format_currency(math_reward)}\n"
            f"📊 Total maths: {maths_per_session}\n"
            f"💵 Total potential earnings: {format_currency(math_reward * maths_per_session)}\n\n"
            f"📋 *Instructions:*\n"
            f"1. Click on a math link below\n"
            f"2. Complete the math challenge\n"
            f"3. Return here for the next math\n\n"
            f"⚠️ *Note:* Complete all {maths_per_session} to finish the session!\n"
            f"⏰ Next session available in {cooldown_text} after completion."
        )

        await query.edit_message_text(
            message,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.edit_message_text(
            "❌ Unable to create math session at the moment.\n\n"
            "Please try again in a few minutes.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Try Again", callback_data="solve_math")],
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )

async def handle_solve_captcha(update: Update, context: CallbackContext):
    """Handle captcha solving request"""
    query = update.callback_query
    
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

    user_id = update.effective_user.id

    # Check if user is in channel
    if not await is_user_in_channel(user_id, context):
        try:
            await query.edit_message_text(
                f"You must join this channel first!\n{CHANNEL_USERNAME}\n\nAfter joining, try again."
            )
        except Exception as e:
            logger.error(f"Error editing message: {e}")
        return

    # Check if user is banned
    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        try:
            await query.edit_message_text("🚫 You have been banned from using this bot.")
        except Exception as e:
            logger.error(f"Error editing message: {e}")
        return

    # Check if user has an active captcha session
    active_session = get_active_captcha_session(user_id)

    if active_session:
        # User has an active session, show progress
        session_data = active_session
        completed = session_data['completed']
        total = session_data['total']
        reward_per_captcha = session_data['reward_per_captcha']
        remaining_tasks = session_data['remaining_tasks']

        if completed >= total:
            # Session is completed but not marked as such (edge case)
            try:
                await query.edit_message_text(
                    "✅ All captchas completed!\n\n"
                    "Wait 24 hours for your next captcha session.",
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                    ])
                )
            except Exception as e:
                logger.error(f"Error editing message: {e}")
            return

        # Generate direct captcha links (no shortening needed)
        captcha_links = []

        for task_number, captcha_code in remaining_tasks[:3]:  # Show max 3 links at a time
            # Get captcha URL from settings
            captcha_base_url = get_captcha_url_from_settings()
            captcha_url = f"{captcha_base_url}?c={captcha_code}"

            captcha_links.append({
                'number': task_number,
                'url': captcha_url
            })

        # Create keyboard with captcha links using Web App buttons
        keyboard = []
        for link in captcha_links:
            keyboard.append([InlineKeyboardButton(f"🔐 Captcha {link['number']}", web_app=WebAppInfo(url=link['url']))])

        keyboard.append([InlineKeyboardButton("🔄 Refresh Progress", callback_data="solve_captcha")])
        keyboard.append([InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")])

        message = (
            f"🔐 *Captcha Session Active*\n\n"
            f"💰 Reward per captcha: {format_currency(reward_per_captcha)}\n"
            f"📊 Progress: {completed}/{total} completed\n"
            f"💵 Total earned: {format_currency(completed * reward_per_captcha)}\n\n"
            f"📋 *Instructions:*\n"
            f"1. Click on a captcha link below\n"
            f"2. Complete the captcha challenge (4 oblong answers)\n"
            f"3. Return here to see your progress\n\n"
            f"⚠️ Complete all {total} captchas to finish this session!"
        )

        try:
            # Get current message text to compare
            current_text = query.message.text if query.message else ""
            
            # Only edit if the content is actually different
            if current_text != message:
                await query.edit_message_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            else:
                # Message content is the same, just answer the query
                logger.info("Message content unchanged, skipping edit")
        except Exception as e:
            logger.error(f"Error editing captcha message: {e}")
            # Try to send a new message if editing fails
            try:
                await query.message.reply_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
            except Exception as e2:
                logger.error(f"Error sending new message: {e2}")
        return

    # Check captcha cooldown for new session
    if not can_generate_captcha_session(user_id):
        # Calculate time until next captcha session
        last_completed_time = None
        with db.lock:
            conn = db.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute(
                    "SELECT last_captcha_at FROM captcha_sessions WHERE user_id = ? AND session_completed = 1 ORDER BY last_captcha_at DESC LIMIT 1",
                    (user_id,)
                )
                result = cursor.fetchone()
                if result:
                    last_completed_time = datetime.fromisoformat(result[0])
            finally:
                conn.close()

        time_until_next = "❌ No captcha session available"
        if last_completed_time:
            captcha_cooldown_minutes = get_captcha_cooldown()
            next_available_time = last_completed_time + timedelta(minutes=captcha_cooldown_minutes)
            time_remaining = next_available_time - datetime.now()
            
            # Check if time is negative (cooldown already passed)
            if time_remaining.total_seconds() <= 0:
                time_until_next = "❌ No captcha session available"
            else:
                total_seconds = int(time_remaining.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_until_next = f"❌ No captcha session available, please try again after {hours}H {minutes}M {seconds}S."

        await query.edit_message_text(
            time_until_next,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )
        return

    # Show loading message
    await query.edit_message_text("🔄 Creating your captcha session...")

    # Create new captcha session
    session_id, captcha_tasks = create_captcha_session(user_id)

    if session_id and captcha_tasks:
        # Generate direct captcha URLs for first 3 captchas
        captcha_reward = get_captcha_reward_amount()

        keyboard = []
        for i, task_data in enumerate(captcha_tasks[:3]):  # Show first 3 links
            # Get captcha URL from settings
            captcha_base_url = get_captcha_url_from_settings()
            captcha_url = f"{captcha_base_url}?c={task_data['code']}"

            keyboard.append([InlineKeyboardButton(f"🔐 Captcha {task_data['number']}", web_app=WebAppInfo(url=captcha_url))])

        keyboard.append([InlineKeyboardButton("🔄 Refresh Progress", callback_data="solve_captcha")])
        keyboard.append([InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")])

        captchas_per_session = get_captchas_per_session()
        
        # Format cooldown time
        captcha_cooldown_minutes = get_captcha_cooldown()
        if captcha_cooldown_minutes >= 1440:
            cooldown_text = f"{captcha_cooldown_minutes // 1440} day{'s' if captcha_cooldown_minutes // 1440 > 1 else ''}"
        elif captcha_cooldown_minutes >= 60:
            hours = captcha_cooldown_minutes // 60
            remaining_minutes = captcha_cooldown_minutes % 60
            if remaining_minutes > 0:
                cooldown_text = f"{hours} hour{'s' if hours > 1 else ''} {remaining_minutes} minute{'s' if remaining_minutes > 1 else ''}"
            else:
                cooldown_text = f"{hours} hour{'s' if hours > 1 else ''}"
        else:
            cooldown_text = f"{captcha_cooldown_minutes} minute{'s' if captcha_cooldown_minutes > 1 else ''}"
        
        message = (
            f"🔐 *Captcha Session Created!*\n\n"
            f"💰 Reward per captcha: {format_currency(captcha_reward)}\n"
            f"📊 Total captchas: {captchas_per_session}\n"
            f"💵 Total potential earnings: {format_currency(captcha_reward * captchas_per_session)}\n\n"
            f"📋 *Instructions:*\n"
            f"1. Click on a captcha link below\n"
            f"2. Complete the captcha challenge (4 oblong answers)\n"
            f"3. Return here for the next captcha\n\n"
            f"⚠️ *Note:* Complete all {captchas_per_session} to finish the session!\n"
            f"⏰ Next session available in {cooldown_text} after completion."
        )

        await query.edit_message_text(
            message,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.edit_message_text(
            "❌ Unable to create captcha session at the moment.\n\n"
            "Please try again in a few minutes.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Try Again", callback_data="solve_captcha")],
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )

async def handle_toggle_notification(update: Update, context: CallbackContext):
    """Handle notification preference toggle"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    callback_data = query.data

    # Parse callback data: toggle_notif_{type}_{new_value}
    parts = callback_data.split('_')
    if len(parts) < 3:
        await query.answer("Invalid request", show_alert=True)
        return

    # Handle different notification types properly
    if parts[2] == "daily":
        notification_type = "daily_reward"
        new_value = int(parts[4]) if len(parts) > 4 else int(parts[3])
    elif parts[2] == "shortlink":
        notification_type = "shortlink"
        new_value = int(parts[3])
    elif parts[2] == "math":
        notification_type = "math"
        new_value = int(parts[3])
    elif parts[2] == "watch":
        notification_type = "watch_ads"
        new_value = int(parts[4]) if len(parts) > 4 else int(parts[3])
    elif parts[2] == "captcha":
        notification_type = "captcha"
        new_value = int(parts[3])
    else:
        await query.answer("Invalid notification type", show_alert=True)
        return

    # Update notification preference
    success = db.update_user_notification(user_id, notification_type, bool(new_value))

    if success:
        # Get updated preferences
        daily_notif, shortlink_notif, math_notif, ads_notif, captcha_notif = db.get_user_notifications(user_id)

        # Update the message with new button states
        message = "🔔 *Notification Settings*\n\nUse the buttons below to turn on/off the desired notifications 👇"

        keyboard = [
            [
                InlineKeyboardButton(
                    f"{'✅' if daily_notif else '❎'} Daily Reward", 
                    callback_data=f"toggle_notif_daily_reward_{1-daily_notif}"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if shortlink_notif else '❎'} Shortlink", 
                    callback_data=f"toggle_notif_shortlink_{1-shortlink_notif}"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if math_notif else '❎'} Math", 
                    callback_data=f"toggle_notif_math_{1-math_notif}"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if captcha_notif else '❎'} Captcha", 
                    callback_data=f"toggle_notif_captcha_{1-captcha_notif}"
                )
            ],
            [
                InlineKeyboardButton(
                    f"{'✅' if ads_notif else '❎'} Ads", 
                    callback_data=f"toggle_notif_watch_ads_{1-ads_notif}"
                )
            ]
        ]

        await query.edit_message_text(
            message,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.answer("Error updating notification preference", show_alert=True)

async def handle_back_to_settings(update: Update, context: CallbackContext):
    """Handle back to settings button"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    gcash_number = user_data[8]  # gcash_number field
    gcash_status = f"📱 Current: {format_gcash_number(gcash_number)}" if gcash_number else "📱 Not set"

    message = (
        f"⚙️ *Settings Menu*\n\n"
        f"GCash Number: {gcash_status}\n\n"
        f"Choose an option below:"
    )

    await query.edit_message_text(
        message,
        parse_mode='Markdown',
        reply_markup=settings_keyboard()
    )

async def handle_referral_statistics(update: Update, context: CallbackContext):
    """Handle referral statistics display"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    referrals = user_data[4]  # referrals field
    referral_stats = db.get_referral_earnings(user_id)
    total_referral_earnings = referral_stats['total_earnings']
    referral_transactions = referral_stats['transaction_count']

    message = (
        f"📊 *Your Referral Statistics*\n\n"
        f"👥 Total Referrals: {referrals}\n"
        f"💰 Total Earned from Referrals: {format_currency(total_referral_earnings)}\n"
        f"📈 Referral Transactions: {referral_transactions}\n\n"
        f"💡 Keep inviting friends to earn more!"
    )

    keyboard = [[InlineKeyboardButton("↩️ Back to Invite", callback_data="back_to_invite")]]

    await query.edit_message_text(
        message,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_referral_list(update: Update, context: CallbackContext):
    """Handle referral list display with pagination"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    callback_data = query.data

    # Extract page number from callback data
    page = int(callback_data.split('_')[-1])

    # Get user's referrals with their earnings
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            # Get all users referred by this user
            cursor.execute(
                """SELECT u.user_id, u.first_name, u.username, u.created_at,
                          COALESCE(SUM(t.amount), 0) as total_earned
                   FROM users u
                   LEFT JOIN transactions t ON u.user_id = t.user_id AND t.type != 'referral_bonus'
                   WHERE u.referred_by = ?
                   GROUP BY u.user_id, u.first_name, u.username, u.created_at
                   ORDER BY u.created_at DESC""",
                (user_id,)
            )
            referrals = cursor.fetchall()
        except Exception as e:
            logger.error(f"Error getting referral list: {e}")
            referrals = []
        finally:
            conn.close()

    if not referrals:
        message = "👥 *Your Referrals*\n\nYou haven't referred anyone yet.\nStart sharing your referral link!"
        keyboard = [[InlineKeyboardButton("↩️ Back to Invite", callback_data="back_to_invite")]]
    else:
        # Pagination setup
        items_per_page = 5
        total_pages = (len(referrals) + items_per_page - 1) // items_per_page
        start_idx = (page - 1) * items_per_page
        end_idx = start_idx + items_per_page
        page_referrals = referrals[start_idx:end_idx]

        message = f"👥 *Your Referrals* (Page {page}/{total_pages})\n\n"

        for i, (ref_id, first_name, username, created_at, total_earned) in enumerate(page_referrals, start_idx + 1):
            # Calculate referral bonus earned from this user (10% of their earnings)
            referral_bonus = total_earned * 0.10
            
            # Format creation date
            try:
                created_date = datetime.fromisoformat(created_at).strftime("%m/%d/%Y")
            except:
                created_date = "Unknown"

            username_text = f"@{username}" if username else "No username"
            
            # Escape special Markdown characters in names
            safe_first_name = first_name.replace('*', '\\*').replace('_', '\\_').replace('`', '\\`').replace('[', '\\[').replace(']', '\\]')
            safe_username_text = username_text.replace('*', '\\*').replace('_', '\\_').replace('`', '\\`').replace('[', '\\[').replace(']', '\\]')
            
            message += f"{i}. *{safe_first_name}* ({safe_username_text})\n"
            message += f"   📅 Joined: {created_date}\n"
            message += f"   💰 Your bonus: {format_currency(referral_bonus)}\n\n"

        # Create pagination buttons
        keyboard = []
        nav_buttons = []
        
        if page > 1:
            nav_buttons.append(InlineKeyboardButton("◀️ Previous", callback_data=f"referral_list_{page-1}"))
        if page < total_pages:
            nav_buttons.append(InlineKeyboardButton("Next ▶️", callback_data=f"referral_list_{page+1}"))
        
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton("↩️ Back to Invite", callback_data="back_to_invite")])

    await query.edit_message_text(
        message,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_back_to_invite(update: Update, context: CallbackContext):
    """Handle back to invite menu"""
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await query.edit_message_text("⚠️ Account error. Please use /start to register.")
        return

    referrals = user_data[4]  # referrals field
    referral_link = f"https://t.me/{BOT_USERNAME.replace('@', '')}?start={user_id}"

    message = (
        f"📱 *Invite Friends & Gain*\n\n"
        f"Share your referral link with friends!\n"
        f"You gain 10% of all your referrals' earnings.\n\n"
        f"Your Referral Link:\n"
        f"`{referral_link}`\n\n"
        f"💡 *Tip:* The more your friends gain, the more you gain!\n"
        f"Tap the link above to copy and share it with your friends!"
    )

    # Create safe share message without special characters
    share_text = f"Want to Make Some Extra Cash? Check out Great Gain! It's super easy to use and actually pays. Start now using my referral link: {referral_link}"

    # Create keyboard with share button and new buttons
    keyboard = [
        [InlineKeyboardButton("📢 Share", switch_inline_query=share_text)],
        [
            InlineKeyboardButton("📊 Statistics", callback_data="referral_statistics"),
            InlineKeyboardButton("👥 Referrals", callback_data="referral_list_1")
        ]
    ]

    await query.edit_message_text(
        message,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def handle_watch_ads(update: Update, context: CallbackContext):
    """Handle watch ads request"""
    query = update.callback_query
    
    try:
        await query.answer()
    except Exception as e:
        logger.error(f"Error answering callback query: {e}")

    user_id = update.effective_user.id

    # Check if user is in channel
    if not await is_user_in_channel(user_id, context):
        await query.edit_message_text(
            f"You must join this channel first!\n{CHANNEL_USERNAME}\n\nAfter joining, try again."
        )
        return

    # Check if user is banned
    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await query.edit_message_text("🚫 You have been banned from using this bot.")
        return

    # Check if user has an unused watch ads link first
    with db.lock:
        conn = db.get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "SELECT ad_code FROM watch_ads WHERE user_id = ? AND reward_claimed = 0 ORDER BY created_at DESC LIMIT 1",
                (user_id,)
            )
            unused_link = cursor.fetchone()

            if unused_link:
                # User has an unused watch ads link
                ad_code = unused_link[0]
                watch_ads_url = f"{get_watch_ads_url_from_settings()}?ad={ad_code}"

                keyboard = [
                    [InlineKeyboardButton("👁️ Watch Ads", web_app=WebAppInfo(url=watch_ads_url))],
                    [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
                ]

                reward_amount = get_watch_ads_reward_amount()

                message = (
                    f"👁️ *Watch Ads*\n\n"
                    f"📋 *Instructions:*\n"
                    f"1. Tap the 'Watch Ads' button below to open the app\n"
                    f"2. Watch rewarded ads or popup ads to earn money\n"
                    f"3. Click the wallet icon 💰 and transfer your earnings to the bot\n"
                    f"4. Your bot balance will be updated after transfer!"
                )

                await query.edit_message_text(
                    message,
                    parse_mode='Markdown',
                    reply_markup=InlineKeyboardMarkup(keyboard)
                )
                return
        except Exception as e:
            logger.error(f"Error checking unused watch ads: {e}")
        finally:
            conn.close()

    # Check watch ads cooldown for new generation
    if not can_generate_watch_ads(user_id):
        # Calculate time until next watch ads
        last_claimed_time = None
        with db.lock:
            conn = db.get_connection()
            cursor = conn.cursor()
            try:
                cursor.execute(
                    "SELECT claimed_at FROM watch_ads WHERE user_id = ? AND reward_claimed = 1 ORDER BY claimed_at DESC LIMIT 1",
                    (user_id,)
                )
                result = cursor.fetchone()
                if result:
                    last_claimed_time = datetime.fromisoformat(result[0])
            finally:
                conn.close()

        time_until_next = "❌ No watch ads available"
        if last_claimed_time:
            watch_ads_cooldown_minutes = get_watch_ads_cooldown()
            next_available_time = last_claimed_time + timedelta(minutes=watch_ads_cooldown_minutes)
            time_remaining = next_available_time - datetime.now()
            
            # Check if time is negative (cooldown already passed)
            if time_remaining.total_seconds() <= 0:
                time_until_next = "❌ No watch ads available"
            else:
                total_seconds = int(time_remaining.total_seconds())
                hours, remainder = divmod(total_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_until_next = f"❌ No watch ads available, please try again after {hours}H {minutes}M {seconds}S."

        await query.edit_message_text(
            time_until_next,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )
        return

    # Show loading message
    await query.edit_message_text("🔄 Preparing your watch ads link...")

    # Generate new watch ads link
    ad_code = create_watch_ads_code(user_id)

    if ad_code:
        watch_ads_url = f"{get_watch_ads_url_from_settings()}?ad={ad_code}"

        keyboard = [
            [InlineKeyboardButton("👁️ Watch Ads", web_app=WebAppInfo(url=watch_ads_url))],
            [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
        ]

        reward_amount = get_watch_ads_reward_amount()

        message = (
            f"👁️ *Watch Ads*\n\n"
            f"📋 *Instructions:*\n"
            f"1. Tap the 'Watch Ads' button below to open the app\n"
            f"2. Watch rewarded ads or popup ads to earn money\n"
            f"3. Click the wallet icon 💰 and transfer your earnings to the bot\n"
            f"4. Your bot balance will be updated after transfer!"
        )

        await query.edit_message_text(
            message,
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await query.edit_message_text(
            "❌ Unable to generate watch ads link at the moment.\n\n"
            "Please try again in a few minutes.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Try Again", callback_data="watch_ads")],
                [InlineKeyboardButton("↩️ Back to Tasks", callback_data="back_to_tasks")]
            ])
        )

# =============================================================================
# WALLET HANDLERS
# =============================================================================

async def settings_menu(update: Update, context: CallbackContext):
    """Show settings menu"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")
        return

    gcash_number = user_data[8]  # gcash_number field
    gcash_status = f"📱 Current: {format_gcash_number(gcash_number)}" if gcash_number else "📱 Not set"

    message = (
        f"⚙️ *Settings Menu*\n\n"
        f"GCash Number: {gcash_status}\n\n"
        f"Choose an option below:"
    )

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=settings_keyboard()
    )

async def update_gcash_start(update: Update, context: CallbackContext):
    """Start GCash number update process"""
    message = (
        "📱 *Update GCash Number*\n\n"
        "Please enter your GCash number (11 digits starting with 09):\n\n"
        "Example: 09123456789"
    )

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=cancel_keyboard()
    )

    return GCASH_NUMBER

async def update_gcash_number(update: Update, context: CallbackContext):
    """Handle GCash number input"""
    gcash_number = update.message.text.strip()

    if gcash_number == "❌ Cancel":
        await update.message.reply_text("❌ Cancelled.", reply_markup=settings_keyboard())
        return ConversationHandler.END

    if not validate_gcash_number(gcash_number):
        await update.message.reply_text(
            "❌ Invalid GCash number format!\n\n"
            "Requirements:\n"
            "• Exactly 11 digits\n"
            "• Must start with 09\n"
            "• Numbers only (no letters or symbols)\n\n"
            "Example: 09123456789",
            reply_markup=cancel_keyboard()
        )
        return GCASH_NUMBER

    # Clean the number (remove spaces and dashes only)
    clean_number = re.sub(r'[ -]', '', gcash_number)
    user_id = update.effective_user.id

    if db.update_gcash_number(user_id, clean_number):
        await update.message.reply_text(
            f"✅ GCash number updated successfully!\n\n"
            f"New number: {format_gcash_number(clean_number)}",
            reply_markup=settings_keyboard()
        )
    else:
        await update.message.reply_text(
            "❌ Error updating GCash number. Please try again.",
            reply_markup=settings_keyboard()
        )

    return ConversationHandler.END

async def notifications_menu(update: Update, context: CallbackContext):
    """Show notifications settings menu"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")
        return

    # Get current notification preferences
    daily_notif, shortlink_notif, math_notif, ads_notif, captcha_notif = db.get_user_notifications(user_id)

    message = "🔔 *Notification Settings*\n\nUse the buttons below to turn on/off the desired notifications 👇"

    # Create inline keyboard with current status
    keyboard = [
        [
            InlineKeyboardButton(
                f"{'✅' if daily_notif else '❎'} Daily Reward", 
                callback_data=f"toggle_notif_daily_reward_{1-daily_notif}"
            )
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if shortlink_notif else '❎'} Shortlink", 
                callback_data=f"toggle_notif_shortlink_{1-shortlink_notif}"
            )
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if math_notif else '❎'} Math", 
                callback_data=f"toggle_notif_math_{1-math_notif}"
            )
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if captcha_notif else '❎'} Captcha", 
                callback_data=f"toggle_notif_captcha_{1-captcha_notif}"
            )
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if ads_notif else '❎'} Ads", 
                callback_data=f"toggle_notif_watch_ads_{1-ads_notif}"
            )
        ]
    ]

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def back_to_menu(update: Update, context: CallbackContext):
    """Return to main menu"""
    user_id = update.effective_user.id
    is_admin_user = is_admin(user_id)

    await update.message.reply_text(
        "↩️ Returned to main menu.",
        reply_markup=main_menu_keyboard(is_admin_user)
    )

async def withdraw_start(update: Update, context: CallbackContext):
    """Start withdrawal process"""
    user_id = update.effective_user.id

    if not await is_user_in_channel(user_id, context):
        message = f"You must join this channel to use this bot👇🏻\n{CHANNEL_USERNAME}\nAfter joining, click '✅ Done'."
        await update.message.reply_text(message, reply_markup=not_joined_reply_keyboard())
        return ConversationHandler.END

    user_data = db.get_user(user_id)
    if check_user_banned(user_data):
        await update.message.reply_text("🚫 You have been banned from using this bot.")
        return ConversationHandler.END

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please use /start to register.")
        return ConversationHandler.END

    # Check if withdrawals are enabled
    if not are_withdrawals_enabled():
        disabled_message = get_withdrawal_disabled_message()
        await update.message.reply_text(f"🚫 {disabled_message}")
        return ConversationHandler.END

    balance = user_data[3]  # balance field
    gcash_number = user_data[8]  # gcash_number field
    minimum_withdrawal = get_minimum_withdrawal_amount()

    if not gcash_number:
        await update.message.reply_text(
            "❌ You need to set your GCash number first!\n\n"
            "Go to ⚙️ Settings → 📱 Update GCash Number"
        )
        return ConversationHandler.END

    if balance < minimum_withdrawal:
        await update.message.reply_text(
            f"❌ Insufficient balance!\n\n"
            f"Your balance: {format_currency(balance)}\n"
            f"Minimum withdrawal: {format_currency(minimum_withdrawal)}"
        )
        return ConversationHandler.END

    message = (
        f"💸 *Withdrawal Request*\n\n"
        f"Current Balance: {format_currency(balance)}\n"
        f"GCash Number: {format_gcash_number(gcash_number)}\n"
        f"Minimum: {format_currency(minimum_withdrawal)}\n\n"
        f"Enter withdrawal amount or use shortcuts:"
    )

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=get_withdraw_amount_keyboard()
    )

    return WITHDRAW_AMOUNT

async def withdraw_amount_input(update: Update, context: CallbackContext):
    """Handle withdrawal amount input"""
    amount_text = update.message.text.strip()

    if amount_text == "❌ Cancel":
        user_id = update.effective_user.id
        is_admin_user = is_admin(user_id)
        await update.message.reply_text("❌ Withdrawal cancelled.", reply_markup=main_menu_keyboard(is_admin_user))
        return ConversationHandler.END

    user_id = update.effective_user.id
    user_data = db.get_user(user_id)

    if not user_data:
        await update.message.reply_text("⚠️ Account error. Please restart the process.")
        return ConversationHandler.END

    balance = user_data[3]  # balance field
    amount = parse_amount(amount_text, balance)
    minimum_withdrawal = get_minimum_withdrawal_amount()

    is_valid, error_message = is_valid_withdrawal_amount(amount, balance, minimum_withdrawal)

    if not is_valid:
        await update.message.reply_text(
            f"❌ {error_message}\n\n"
            f"Please enter a valid amount:",
            reply_markup=get_withdraw_amount_keyboard()
        )
        return WITHDRAW_AMOUNT

    # Store amount in context for confirmation
    context.user_data['withdrawal_amount'] = amount

    gcash_number = user_data[8]  # gcash_number field
    new_balance = balance - amount

    message = (
        f"💸 *Confirm Withdrawal*\n\n"
        f"Amount: {format_currency(amount)}\n"
        f"To: {format_gcash_number(gcash_number)}\n"
        f"Remaining Balance: {format_currency(new_balance)}\n\n"
        f"⚠️ This action cannot be undone.\n"
        f"Please confirm your withdrawal:"
    )

    await update.message.reply_text(
        message,
        parse_mode='Markdown',
        reply_markup=get_confirmation_keyboard()
    )

    return WITHDRAW_CONFIRM

async def withdraw_confirm(update: Update, context: CallbackContext):
    """Handle withdrawal confirmation"""
    confirmation = update.message.text.strip().upper()

    if confirmation in ["❌ CANCEL", "CANCEL", "❌ Cancel"]:
        user_id = update.effective_user.id
        is_admin_user = is_admin(user_id)
        await update.message.reply_text("❌ Withdrawal cancelled.", reply_markup=main_menu_keyboard(is_admin_user))
        return ConversationHandler.END

    if confirmation not in ["CONFIRM", "✅ CONFIRM", "✅ Confirm", "CONFIRM"]:
        await update.message.reply_text(
            "❌ Invalid confirmation.\n\n"
            "Please use the buttons below to confirm or cancel:",
            reply_markup=get_confirmation_keyboard()
        )
        return WITHDRAW_CONFIRM

    user_id = update.effective_user.id
    user_data = db.get_user(user_id)
    amount = context.user_data.get('withdrawal_amount')

    if not user_data or not amount:
        await update.message.reply_text("⚠️ Error processing withdrawal. Please try again.")
        return ConversationHandler.END

    gcash_number = user_data[8]  # gcash_number field

    # Create withdrawal request
    withdrawal_id = db.create_withdrawal_request(user_id, amount, gcash_number)

    if withdrawal_id:
        # Notify user
        message = (
            f"✅ *Withdrawal Request Submitted*\n\n"
            f"Request ID: #{withdrawal_id}\n"
            f"Amount: {format_currency(amount)}\n"
            f"GCash: {format_gcash_number(gcash_number)}\n\n"
            f"⏳ Your request is being processed.\n"
            f"You'll be notified when it's approved."
        )

        await update.message.reply_text(
            message,
            parse_mode='Markdown',
            reply_markup=main_menu_keyboard(False)
        )

        # Withdrawal notifications are now handled via web admin interface

    else:
        await update.message.reply_text(
            "❌ Error processing withdrawal request. Please try again later.",
            reply_markup=main_menu_keyboard(False)
        )

    return ConversationHandler.END

async def cancel_operation(update: Update, context: CallbackContext):
    """Cancel any ongoing operation"""
    user_id = update.effective_user.id
    is_admin_user = is_admin(user_id)

    await update.message.reply_text(
        "❌ Operation cancelled.",
        reply_markup=main_menu_keyboard(is_admin_user)
    )
    return ConversationHandler.END

async def add_admin(update: Update, context: CallbackContext):
    """Admin command to add new admins"""
    user_id = update.effective_user.id
    
    # Check if user is admin
    if not is_admin(user_id):
        await update.message.reply_text("❌ This command is only available to administrators.")
        return
    
    # Check if username argument provided
    if not context.args or len(context.args) != 1:
        await update.message.reply_text(
            "❓ Usage: /addadmin @username\n\n"
            "Example: /addadmin @myanwell"
        )
        return
    
    username_input = context.args[0].strip()
    # Remove @ if present
    username = username_input.replace('@', '')
    
    # Search for user in database
    conn = None
    try:
        conn = db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, username, first_name FROM users WHERE username = ?", (username,))
        user_data = cursor.fetchone()
        
        if not user_data:
            await update.message.reply_text(
                f"❌ User @{username} not found in database.\n\n"
                f"The user must interact with the bot first using /start before they can be made admin."
            )
            return
        
        target_user_id = user_data[0]
        target_first_name = user_data[2] or 'Unknown'
        
        # Check if already admin
        if target_user_id in ADMIN_IDS:
            await update.message.reply_text(f"ℹ️ @{username} ({target_first_name}) is already an admin.")
            return
        
        # Add to persistent storage
        if db.add_admin(target_user_id, username, target_first_name, user_id):
            # Add to memory if not already there
            if target_user_id not in ADMIN_IDS:
                ADMIN_IDS.append(target_user_id)
        
        await update.message.reply_text(
            f"✅ Successfully added @{username} ({target_first_name}) as admin!\n\n"
            f"User ID: {target_user_id}\n"
            f"Total admins: {len(ADMIN_IDS)}"
        )
        
        # Notify the new admin
        try:
            await context.bot.send_message(
                chat_id=target_user_id,
                text=f"🎉 Congratulations! You have been added as an admin for {BOT_USERNAME}.\n\n"
                     f"You now have administrative privileges in @greatgain."
            )
        except Exception as e:
            logger.error(f"Could not notify new admin {target_user_id}: {e}")
        
    except Exception as e:
        logger.error(f"Error adding admin: {e}")
        await update.message.reply_text(f"❌ Error adding admin: {str(e)}")
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass

# =============================================================================
# UNKNOWN HANDLERS
# =============================================================================

async def handle_unknown(update: Update, context: CallbackContext):
    """Handle unknown commands"""
    await update.message.reply_text(
        "❓ Unknown command. Please use the menu buttons or /start to begin."
    )

# =============================================================================
# MAIN BOT SETUP
# =============================================================================

def vacuum_database():
    """Vacuum database to reduce size and fragmentation"""
    try:
        conn = sqlite3.connect(DATABASE_NAME)
        conn.execute('VACUUM')
        conn.close()
        logger.info("Database vacuumed successfully")
    except Exception as e:
        logger.error(f"Error vacuuming database: {e}")

def cleanup_old_data():
    """Clean up old expired data to save space"""
    try:
        conn = sqlite3.connect(DATABASE_NAME)
        cursor = conn.cursor()
        
        # Remove old shortlink clicks older than 30 days
        thirty_days_ago = (datetime.now() - timedelta(days=30)).isoformat()
        cursor.execute("DELETE FROM shortlink_clicks WHERE click_timestamp < ?", (thirty_days_ago,))
        
        # Remove old completed math sessions older than 7 days
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        cursor.execute("DELETE FROM math_sessions WHERE session_completed = 1 AND last_math_at < ?", (week_ago,))
        cursor.execute("DELETE FROM math_links WHERE session_id NOT IN (SELECT session_id FROM math_sessions)")
        
        # Remove old watch ads older than 7 days
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 1 AND claimed_at < ?", (week_ago,))
        
        conn.commit()
        conn.close()
        logger.info("Old data cleaned up successfully")
    except Exception as e:
        logger.error(f"Error cleaning up old data: {e}")

def main():
    """Start the bot"""
    try:
        # Clean up database before starting
        cleanup_old_data()
        vacuum_database()
        
        # Load admins from database
        load_admins_from_database()
        
        # Create the Application and pass it your bot's token with timeout settings
        application = Application.builder().token(TOKEN).connect_timeout(30).read_timeout(30).write_timeout(30).build()

        # Initialize notification scheduler
        scheduler = BackgroundScheduler()
        # Check for notifications every 30 minutes
        scheduler.add_job(
            func=check_and_send_notifications,
            trigger="interval",
            minutes=30,
            id='notification_checker'
        )
        # Clean up database daily at 2 AM
        scheduler.add_job(
            func=lambda: (cleanup_old_data(), vacuum_database()),
            trigger="cron",
            hour=2,
            id='database_cleanup'
        )
        scheduler.start()

    # Basic command handlers
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("addadmin", add_admin))

        # Conversation handler for GCash number update
        gcash_conv_handler = ConversationHandler(
            entry_points=[MessageHandler(filters.Regex('^📱 Update GCash Number$'), update_gcash_start)],
            states={
                GCASH_NUMBER: [MessageHandler(filters.TEXT & ~filters.COMMAND, update_gcash_number)],
            },
            fallbacks=[MessageHandler(filters.Regex('^❌ Cancel$'), cancel_operation)]
        )

        # Conversation handler for withdrawals
        withdrawal_conv_handler = ConversationHandler(
            entry_points=[MessageHandler(filters.Regex('^💸 Withdraw$'), withdraw_start)],
            states={
                WITHDRAW_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, withdraw_amount_input)],
                WITHDRAW_CONFIRM: [MessageHandler(filters.TEXT & ~filters.COMMAND, withdraw_confirm)],
            },
            fallbacks=[MessageHandler(filters.Regex('^❌ Cancel$'), cancel_operation)]
        )

        # Add conversation handlers
        application.add_handler(gcash_conv_handler)
        application.add_handler(withdrawal_conv_handler)

        # Main menu message handlers
        application.add_handler(MessageHandler(filters.Regex('^❇️ Gain ₱eso$'), gain_peso))
        application.add_handler(MessageHandler(filters.Regex('^💰 Balance$'), check_balance))
        application.add_handler(MessageHandler(filters.Regex('^📨 Invite$'), invite_friends))
        application.add_handler(MessageHandler(filters.Regex('^📊 History$'), check_history))
        application.add_handler(MessageHandler(filters.Regex('^⚙️ Settings$'), settings_menu))
        application.add_handler(MessageHandler(filters.Regex('^📞 Contact Support$'), contact_support))
        application.add_handler(MessageHandler(filters.Regex('^✅ Done$'), done_button))

        # Settings menu handlers
        application.add_handler(MessageHandler(filters.Regex('^🔔 Notifications$'), notifications_menu))
        application.add_handler(MessageHandler(filters.Regex('^↩️ Back to Menu$'), back_to_menu))

        # Callback query handlers for inline buttons
        application.add_handler(CallbackQueryHandler(handle_daily_reward, pattern='^daily_reward$'))
        application.add_handler(CallbackQueryHandler(handle_daily_claimed, pattern='daily_claimed$'))
        application.add_handler(CallbackQueryHandler(handle_generate_shortlink, pattern='generate_shortlink$'))
        application.add_handler(CallbackQueryHandler(handle_back_to_tasks, pattern='back_to_tasks$'))
        application.add_handler(CallbackQueryHandler(handle_view_more_history, pattern='view_more_history$'))
        application.add_handler(CallbackQueryHandler(handle_view_less_history, pattern='view_less_history$'))
        application.add_handler(CallbackQueryHandler(handle_solve_math, pattern='solve_math$'))
        application.add_handler(CallbackQueryHandler(handle_solve_captcha, pattern='solve_captcha$'))
        application.add_handler(CallbackQueryHandler(handle_watch_ads, pattern='watch_ads$'))
        application.add_handler(CallbackQueryHandler(handle_toggle_notification, pattern='^toggle_notif_'))
        application.add_handler(CallbackQueryHandler(handle_back_to_settings, pattern='^back_to_settings$'))
        application.add_handler(CallbackQueryHandler(handle_referral_statistics, pattern='^referral_statistics$'))
        application.add_handler(CallbackQueryHandler(handle_referral_list, pattern='^referral_list_'))
        application.add_handler(CallbackQueryHandler(handle_back_to_invite, pattern='^back_to_invite$'))

        # Unknown message handler (should be last)
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_unknown))

        # Error handler
        async def error_handler(update, context):
            """Log errors caused by updates"""
            import traceback
            logger.error(f'Update {update} caused error {context.error}')
            logger.error(f'Full traceback: {traceback.format_exc()}')
            
            # Handle specific timeout errors
            if "timed out" in str(context.error).lower() or "timeout" in str(context.error).lower():
                logger.warning("Timeout error detected - this is usually temporary")
            
            # Handle query too old errors
            if "query is too old" in str(context.error).lower():
                logger.warning("Query too old error - callback query expired")

        application.add_error_handler(error_handler)

        # Start the bot
        logger.info("Starting greatgain Bot...")

        # Start polling for updates
        logger.info("Starting bot polling...")
        application.run_polling()
        
    except Exception as e:
        logger.error(f"Bot failed to start: {e}")
        print(f"❌ Bot error: {e}")
    finally:
        # Cleanup
        try:
            if 'scheduler' in locals():
                scheduler.shutdown()
        except:
            pass

if __name__ == '__main__':
    main()
