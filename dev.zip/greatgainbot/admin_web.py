#!/usr/bin/env python3
"""
GreatGain Bot Web Admin Interface
"""

import os
import sqlite3
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = os.getenv('WEB_ADMIN_SECRET', 'your-secret-key-change-this')

# Configuration
DATABASE_NAME = 'bot_users.db'
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')  # Change this!

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE_NAME, check_same_thread=False)
    init_database(conn)
    return conn

def init_database(conn):
    """Initialize database tables if they don't exist"""
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        balance REAL DEFAULT 0,
        referrals INTEGER DEFAULT 0,
        referred_by INTEGER DEFAULT NULL,
        last_login TEXT,
        last_reward_claimed TEXT,
        gcash_number TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        is_banned INTEGER DEFAULT 0,
        ip_address TEXT
    )
    ''')

    # Add ip_address column if it doesn't exist (for existing databases)
    try:
        cursor.execute("ALTER TABLE users ADD COLUMN ip_address TEXT")
    except:
        pass  # Column already exists

    # Create transactions table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        type TEXT,
        amount REAL,
        description TEXT,
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create withdrawals table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS withdrawals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount REAL,
        gcash_number TEXT,
        status TEXT DEFAULT 'pending',
        timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        admin_note TEXT,
        completed_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create shortlink_clicks table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS shortlink_clicks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        click_code TEXT UNIQUE,
        reward_claimed INTEGER DEFAULT 0,
        click_timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        ip_address TEXT,
        user_agent TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create math_sessions table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS math_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        session_id TEXT UNIQUE,
        maths_completed INTEGER DEFAULT 0,
        total_maths INTEGER DEFAULT 5,
        reward_per_math REAL DEFAULT 0.0671,
        session_completed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_math_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create math_links table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS math_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        link_number INTEGER,
        math_code TEXT UNIQUE,
        completed INTEGER DEFAULT 0,
        completed_at TEXT,
        ip_address TEXT,
        user_agent TEXT,
        FOREIGN KEY (session_id) REFERENCES math_sessions (session_id)
    )
    ''')

    # Create math_tasks table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS math_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        math_code TEXT UNIQUE,
        math_number INTEGER,
        reward_claimed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        claimed_at TEXT,
        ip_address TEXT,
        user_agent TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create captcha_sessions table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS captcha_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        session_id TEXT UNIQUE,
        captchas_completed INTEGER DEFAULT 0,
        total_captchas INTEGER DEFAULT 5,
        reward_per_captcha REAL DEFAULT 0.0671,
        session_completed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_captcha_at TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create captcha_tasks table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS captcha_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        task_number INTEGER,
        captcha_code TEXT UNIQUE,
        completed INTEGER DEFAULT 0,
        completed_at TEXT,
        ip_address TEXT,
        user_agent TEXT,
        FOREIGN KEY (session_id) REFERENCES captcha_sessions (session_id)
    )
    ''')

    # Create custom tasks table for admin-managed tasks
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS custom_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        url TEXT NOT NULL,
        reward REAL DEFAULT 0,
        icon TEXT DEFAULT '📌',
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        cooldown_hours INTEGER DEFAULT 24,
        steps TEXT DEFAULT ''
    )
    ''')
    
    # Migration: Add steps column if it doesn't exist
    try:
        cursor.execute("SELECT steps FROM custom_tasks LIMIT 1")
    except:
        cursor.execute("ALTER TABLE custom_tasks ADD COLUMN steps TEXT DEFAULT ''")
    
    # Migration: Add category column if it doesn't exist
    try:
        cursor.execute("SELECT category FROM custom_tasks LIMIT 1")
    except:
        cursor.execute("ALTER TABLE custom_tasks ADD COLUMN category TEXT DEFAULT 'General'")

    # Create task_completions table to track user task completions
    # UNIQUE(user_id, task_id) ensures one active completion per user/task
    # Old completions beyond cooldown are replaced with new ones
    # ip_address tracks which IP completed the task to prevent multi-account abuse
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS task_completions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        task_id INTEGER NOT NULL,
        completed_at TEXT NOT NULL,
        reward_claimed REAL NOT NULL DEFAULT 0,
        ip_address TEXT,
        FOREIGN KEY (user_id) REFERENCES users (user_id),
        FOREIGN KEY (task_id) REFERENCES custom_tasks (id),
        UNIQUE(user_id, task_id)
    )
    ''')
    
    # Migration: Add ip_address column if it doesn't exist (for existing databases)
    try:
        cursor.execute("SELECT ip_address FROM task_completions LIMIT 1")
    except:
        cursor.execute("ALTER TABLE task_completions ADD COLUMN ip_address TEXT")
    
    # Migration: Enforce UNIQUE constraint on existing databases
    # First, deduplicate any existing duplicate records (keep most recent completion)
    cursor.execute('''
    DELETE FROM task_completions 
    WHERE id NOT IN (
        SELECT MAX(id)
        FROM task_completions 
        GROUP BY user_id, task_id
    )
    ''')
    
    # Create UNIQUE INDEX to enforce constraint on existing tables
    # This will fail silently if the constraint already exists from table creation
    try:
        cursor.execute('''
        CREATE UNIQUE INDEX IF NOT EXISTS idx_task_completions_unique 
        ON task_completions(user_id, task_id)
        ''')
    except:
        pass  # Index already exists from UNIQUE constraint or was already created

    # Create taskcenter_balance table to track task center ad earnings
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS taskcenter_balance (
        user_id INTEGER PRIMARY KEY,
        balance REAL DEFAULT 0,
        total_earned REAL DEFAULT 0,
        last_updated TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create taskcenter_ads table to track ad views in task center
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS taskcenter_ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        ads_watched INTEGER DEFAULT 0,
        last_watched TEXT,
        date TEXT,
        UNIQUE(user_id, date),
        FOREIGN KEY (user_id) REFERENCES users (user_id)
    )
    ''')

    # Create settings table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    ''')

    # Insert default settings if they don't exist
    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('shortlink_reward_amount', '0.0724')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_reward_amount', '0.0671')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_per_session', '5')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('watch_ads_reward_amount', '0.0532')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('base_url', 'https://example.com')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('reward_page_url', 'https://example.com/reward')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_page_url', 'https://example.com/math')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('watch_ads_page_url', 'https://example.com/watch_ads')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('captcha_page_url', 'https://example.com/captcha')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('captcha_reward_amount', '0.0671')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('captcha_per_session', '5')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('captcha_cooldown_minutes', '1440')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('minimum_withdrawal', '100')
    ''')
    
    # Migration: Update existing minimum_withdrawal to 100 if it's still the old default
    cursor.execute('''
        UPDATE settings 
        SET value = '100' 
        WHERE key = 'minimum_withdrawal' AND value = '0.35'
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('daily_reward_amount', '0.0053')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('daily_reward_cooldown', '24')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('shortlink_cooldown', '24')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('math_cooldown', '24')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('watch_ads_cooldown', '1')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('watch_ads_cooldown_minutes', '60')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('withdrawals_enabled', '1')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('withdrawal_disabled_message', 'Withdrawals are temporarily disabled for maintenance. Please try again later.')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('taskcenter_ad_reward', '0.05')
    ''')

    cursor.execute('''
        INSERT OR IGNORE INTO settings (key, value) 
        VALUES ('taskcenter_ads_limit', '10')
    ''')

    conn.commit()

def format_currency(amount):
    """Format currency"""
    if amount == 0:
        return "₱0"
    elif amount == int(amount):
        return f"₱{int(amount)}"
    else:
        return f"₱{amount:.4f}".rstrip('0').rstrip('.')

def format_datetime(timestamp_str):
    """Format datetime string"""
    try:
        dt = datetime.fromisoformat(timestamp_str)
        return dt.strftime("%Y-%m-%d %H:%M")
    except:
        return timestamp_str

@app.route('/')
def main_page():
    """Main landing page"""
    return render_template('main.html')

@app.route('/reward')
def reward_page():
    """Serve the reward claiming page"""
    return send_from_directory('..', 'reward.html')

@app.route('/reward.html')
def reward_page_redirect():
    """Redirect .html version to clean URL"""
    return redirect(url_for('reward_page'), code=301)

@app.route('/math')
def math_page():
    """Serve the math solving page"""
    return send_from_directory('..', 'math.html')

@app.route('/math.html')
def math_page_redirect():
    """Redirect .html version to clean URL"""
    return redirect(url_for('math_page'), code=301)

@app.route('/watch_ads')
def watch_ads_page():
    """Serve the watch ads page"""
    return send_from_directory('..', 'watch_ads.html')

@app.route('/watch_ads.html')
def watch_ads_page_redirect():
    """Redirect .html version to clean URL"""
    return redirect(url_for('watch_ads_page'), code=301)

@app.route('/captcha')
def captcha_page():
    """Serve the captcha solving page"""
    return send_from_directory('..', 'captcha.html')

@app.route('/captcha.html')
def captcha_page_redirect():
    """Redirect .html version to clean URL"""
    return redirect(url_for('captcha_page'), code=301)

@app.route('/taskcenter')
def taskcenter_page():
    """Serve the task center page"""
    return send_from_directory('..', 'taskcenter.html')

@app.route('/taskcenter.html')
def taskcenter_page_redirect():
    """Redirect .html version to clean URL"""
    return redirect(url_for('taskcenter_page'), code=301)

@app.route('/@dminpanel')
def dashboard():
    """Admin dashboard"""
    conn = get_db()
    cursor = conn.cursor()

    # Get statistics
    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE is_banned = 0")
    active_users = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
    banned_users = cursor.fetchone()[0]

    cursor.execute("SELECT SUM(balance) FROM users")
    total_balance_result = cursor.fetchone()[0]
    total_balance = total_balance_result if total_balance_result else 0

    cursor.execute("SELECT SUM(referrals) FROM users")
    total_referrals_result = cursor.fetchone()[0]
    total_referrals = total_referrals_result if total_referrals_result else 0

    cursor.execute("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")
    pending_withdrawals = cursor.fetchone()[0]

    cursor.execute("SELECT SUM(amount) FROM withdrawals WHERE status = 'pending'")
    pending_amount_result = cursor.fetchone()[0]
    pending_amount = pending_amount_result if pending_amount_result else 0

    conn.close()

    stats = {
        'total_users': total_users,
        'active_users': active_users,
        'banned_users': banned_users,
        'total_balance': format_currency(total_balance),
        'total_referrals': total_referrals,
        'pending_withdrawals': pending_withdrawals,
        'pending_amount': format_currency(pending_amount)
    }

    return render_template('dashboard.html', stats=stats)

@app.route('/users')
def users():
    """User management page"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '').strip()
    per_page = 20
    offset = (page - 1) * per_page

    conn = get_db()
    cursor = conn.cursor()

    # Build search query
    if search:
        # Search by user_id (if numeric), username, or first_name
        search_conditions = []
        search_params = []

        # Check if search term is numeric for user_id search
        if search.isdigit():
            search_conditions.append("user_id = ?")
            search_params.append(int(search))

        # Search in username (remove @ if present)
        username_search = search.replace('@', '')
        search_conditions.append("username LIKE ?")
        search_params.append(f'%{username_search}%')

        # Search in first_name
        search_conditions.append("first_name LIKE ?")
        search_params.append(f'%{search}%')

        where_clause = "WHERE (" + " OR ".join(search_conditions) + ")"

        # Get users with search and pagination
        cursor.execute(f"""
            SELECT user_id, username, first_name, balance, referrals, created_at, is_banned
            FROM users 
            {where_clause}
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        """, search_params + [per_page, offset])

        users_data = cursor.fetchall()

        # Get total count for pagination with search
        cursor.execute(f"SELECT COUNT(*) FROM users {where_clause}", search_params)
        total_users = cursor.fetchone()[0]
    else:
        # Get users with pagination (no search)
        cursor.execute("""
            SELECT user_id, username, first_name, balance, referrals, created_at, is_banned
            FROM users 
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        """, (per_page, offset))

        users_data = cursor.fetchall()

        # Get total count for pagination
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]

    # Get pending withdrawals for all displayed users
    user_ids = [user[0] for user in users_data]
    pending_withdrawals = {}

    if user_ids:
        placeholders = ','.join('?' * len(user_ids))
        cursor.execute(f"""
            SELECT user_id, COUNT(*) as count, SUM(amount) as total_amount
            FROM withdrawals 
            WHERE user_id IN ({placeholders}) AND status = 'pending'
            GROUP BY user_id
        """, user_ids)

        for user_id, count, total_amount in cursor.fetchall():
            pending_withdrawals[user_id] = {
                'count': count,
                'total_amount': format_currency(total_amount)
            }

    conn.close()

    # Format users data
    users_list = []
    for user in users_data:
        user_id = user[0]
        pending_info = pending_withdrawals.get(user_id, {'count': 0, 'total_amount': format_currency(0)})

        users_list.append({
            'user_id': user_id,
            'username': user[1] or 'No username',
            'first_name': user[2] or 'Unknown',
            'balance': format_currency(user[3]),
            'referrals': user[4],
            'created_at': format_datetime(user[5]) if user[5] else 'Unknown',
            'is_banned': bool(user[6]),
            'status': '🚫 Banned' if user[6] else '✅ Active',
            'pending_withdrawals_count': pending_info['count'],
            'pending_withdrawals_amount': pending_info['total_amount']
        })

    # Calculate pagination info
    total_pages = (total_users + per_page - 1) // per_page

    return render_template('users.html', 
                         users=users_list, 
                         page=page, 
                         total_pages=total_pages,
                         total_users=total_users,
                         search=search)

@app.route('/withdrawals')
def withdrawals():
    """Withdrawal management page"""
    status_filter = request.args.get('status', 'pending')

    conn = get_db()
    cursor = conn.cursor()

    # Get withdrawals
    cursor.execute("""
        SELECT w.id, w.user_id, u.username, u.first_name, w.amount, w.gcash_number, 
               w.status, w.timestamp, w.admin_note, w.completed_at
        FROM withdrawals w
        JOIN users u ON w.user_id = u.user_id
        WHERE w.status = ?
        ORDER BY w.timestamp DESC
    """, (status_filter,))

    withdrawals_data = cursor.fetchall()
    conn.close()

    # Format withdrawals data
    withdrawals_list = []
    for w in withdrawals_data:
        withdrawals_list.append({
            'id': w[0],
            'user_id': w[1],
            'username': w[2] or 'No username',
            'first_name': w[3] or 'Unknown',
            'amount': format_currency(w[4]),
            'gcash_number': w[5],
            'status': w[6],
            'timestamp': format_datetime(w[7]) if w[7] else 'Unknown',
            'admin_note': w[8] or '',
            'completed_at': format_datetime(w[9]) if w[9] else ''
        })

    return render_template('withdrawals.html', 
                         withdrawals=withdrawals_list,
                         current_status=status_filter)

@app.route('/add_balance', methods=['GET', 'POST'])
def add_balance():
    """Add balance to user"""
    if request.method == 'POST':
        search_term = request.form.get('search_term', '').strip()
        amount = request.form.get('amount')

        try:
            if not amount:
                flash('Amount is required', 'error')
                return redirect(url_for('add_balance'))
            amount = float(amount)

            if amount <= 0:
                flash('Amount must be positive', 'error')
                return redirect(url_for('add_balance'))

            conn = get_db()
            cursor = conn.cursor()

            # Search for user by ID, username, or name
            user = None
            user_id = None

            # Try to find by user ID first
            if search_term.isdigit():
                cursor.execute("SELECT user_id, first_name, username FROM users WHERE user_id = ?", (int(search_term),))
                user = cursor.fetchone()
                if user:
                    user_id = user[0]

            # If not found by ID, search by username (with or without @)
            if not user:
                username_search = search_term.replace('@', '')
                cursor.execute("SELECT user_id, first_name, username FROM users WHERE username = ?", (username_search,))
                user = cursor.fetchone()
                if user:
                    user_id = user[0]

            # If still not found, search by first name
            if not user:
                cursor.execute("SELECT user_id, first_name, username FROM users WHERE first_name LIKE ?", (f'%{search_term}%',))
                user = cursor.fetchone()
                if user:
                    user_id = user[0]

            if not user:
                flash(f'User "{search_term}" not found', 'error')
                conn.close()
                return redirect(url_for('add_balance'))

            # Add balance
            cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))

            # Log transaction
            cursor.execute("""
                INSERT INTO transactions (user_id, type, amount, description)
                VALUES (?, ?, ?, ?)
            """, (user_id, 'admin_bonus', amount, f'Balance added by admin via web interface'))

            conn.commit()
            conn.close()

            user_name = user[1] or 'Unknown'
            username = user[2] or 'no_username'
            flash(f'Successfully added {format_currency(amount)} to {user_name} (@{username})', 'success')

        except ValueError:
            flash('Invalid amount format', 'error')
        except Exception as e:
            flash(f'Error: {str(e)}', 'error')

        return redirect(url_for('add_balance'))

    return render_template('add_balance.html')

@app.route('/broadcast', methods=['GET', 'POST'])
def broadcast():
    """Send broadcast message to all users"""
    if request.method == 'POST':
        message = request.form.get('message', '').strip()

        if not message:
            flash('Message cannot be empty', 'error')
            return redirect(url_for('broadcast'))

        try:
            import requests
            import time

            # Get bot token (same as main bot)
            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'
            if not bot_token:
                flash('Bot token not found. Please check environment configuration.', 'error')
                return redirect(url_for('broadcast'))

            # Get all active users from database
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute("SELECT user_id, first_name FROM users WHERE is_banned = 0")
            users = cursor.fetchall()
            conn.close()

            if not users:
                flash('No active users found to send message to.', 'warning')
                return redirect(url_for('broadcast'))

            # Send message to all users with rate limiting
            success_count = 0
            failed_count = 0
            total_users = len(users)

            for i, user in enumerate(users):
                user_id = user[0]
                try:
                    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                    data = {
                        'chat_id': user_id,
                        'text': f"📢 Broadcast Message\n\n{message}",
                        'parse_mode': 'HTML'
                    }

                    response = requests.post(url, data=data, timeout=15)
                    response_data = response.json()

                    if response.status_code == 200 and response_data.get('ok'):
                        success_count += 1
                    else:
                        failed_count += 1
                        print(f"Failed to send to user {user_id}: {response_data}")

                    # Rate limiting: sleep between requests to avoid hitting Telegram limits
                    if i < total_users - 1:  # Don't sleep after the last message
                        time.sleep(0.05)  # 50ms delay between messages

                except requests.exceptions.Timeout:
                    failed_count += 1
                    print(f"Timeout sending to user {user_id}")
                except requests.exceptions.RequestException as e:
                    failed_count += 1
                    print(f"Request error sending to user {user_id}: {e}")
                except Exception as e:
                    failed_count += 1
                    print(f"Unexpected error sending to user {user_id}: {e}")

            # Provide detailed feedback
            total_sent = success_count + failed_count
            if success_count > 0:
                if failed_count == 0:
                    flash(f'✅ Broadcast sent successfully to all {success_count} users!', 'success')
                else:
                    flash(f'✅ Broadcast sent to {success_count} users. {failed_count} failed (likely blocked the bot or deleted their account).', 'success')
            else:
                flash(f'❌ Failed to send broadcast to any users. Please check bot token and network connection.', 'error')

        except ImportError:
            flash('Error: requests module not available. Please check your environment.', 'error')
        except Exception as e:
            flash(f'Unexpected error sending broadcast: {str(e)}', 'error')

        return redirect(url_for('broadcast'))

    # GET request - show broadcast form
    # Get user count for display
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users WHERE is_banned = 0")
        active_user_count = cursor.fetchone()[0]
        conn.close()
    except:
        active_user_count = 0

    return render_template('broadcast.html', active_user_count=active_user_count)

@app.route('/tasks', methods=['GET', 'POST'])
def manage_tasks():
    """Task management page for admins"""
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'create':
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()
            url = request.form.get('url', '').strip()
            reward = request.form.get('reward', '0')
            icon = request.form.get('icon', '📌').strip()
            cooldown_hours = request.form.get('cooldown_hours', '24')
            steps_raw = request.form.get('steps', '').strip()
            category = request.form.get('category', 'General').strip()
            
            if not title or not url:
                flash('Title and URL are required', 'error')
                return redirect(url_for('manage_tasks'))
            
            try:
                import json
                reward = float(reward)
                cooldown_hours = int(cooldown_hours)
                
                # Convert newline-separated steps to JSON array
                steps_json = ''
                if steps_raw:
                    steps_lines = [line.strip() for line in steps_raw.split('\n') if line.strip()]
                    steps_array = [
                        {'step_number': i + 1, 'instruction': line}
                        for i, line in enumerate(steps_lines)
                    ]
                    steps_json = json.dumps(steps_array)
                
                conn = get_db()
                cursor = conn.cursor()
                
                cursor.execute("""
                    INSERT INTO custom_tasks (title, description, url, reward, icon, cooldown_hours, steps, category) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (title, description, url, reward, icon, cooldown_hours, steps_json, category))
                
                conn.commit()
                conn.close()
                
                flash('Task created successfully!', 'success')
            except ValueError:
                flash('Invalid reward or cooldown value', 'error')
            except Exception as e:
                flash(f'Error creating task: {str(e)}', 'error')
                
        elif action == 'toggle':
            task_id = request.form.get('task_id')
            try:
                conn = get_db()
                cursor = conn.cursor()
                
                cursor.execute("UPDATE custom_tasks SET is_active = 1 - is_active WHERE id = ?", (task_id,))
                
                conn.commit()
                conn.close()
                
                flash('Task status updated!', 'success')
            except Exception as e:
                flash(f'Error updating task: {str(e)}', 'error')
                
        elif action == 'delete':
            task_id = request.form.get('task_id')
            try:
                conn = get_db()
                cursor = conn.cursor()
                
                cursor.execute("DELETE FROM custom_tasks WHERE id = ?", (task_id,))
                
                conn.commit()
                conn.close()
                
                flash('Task deleted successfully!', 'success')
            except Exception as e:
                flash(f'Error deleting task: {str(e)}', 'error')
        
        return redirect(url_for('manage_tasks'))
    
    # GET request - show task management page
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, title, description, url, reward, icon, is_active, cooldown_hours, created_at, steps, category FROM custom_tasks ORDER BY created_at DESC")
        tasks = cursor.fetchall()
        
        import json
        tasks_list = []
        for task in tasks:
            steps_raw = task[9] if len(task) > 9 else ''
            category = task[10] if len(task) > 10 else 'General'
            
            # Parse JSON steps if available
            steps_parsed = []
            if steps_raw:
                try:
                    steps_parsed = json.loads(steps_raw)
                except:
                    # If not JSON, treat as plain text (legacy support)
                    steps_parsed = []
            
            tasks_list.append({
                'id': task[0],
                'title': task[1],
                'description': task[2],
                'url': task[3],
                'reward': task[4],
                'icon': task[5],
                'is_active': task[6],
                'cooldown_hours': task[7],
                'created_at': task[8],
                'steps': steps_parsed,
                'category': category
            })
        
        conn.close()
        
        return render_template('tasks_management.html', tasks=tasks_list)
    except Exception as e:
        flash(f'Error loading tasks: {str(e)}', 'error')
        return render_template('tasks_management.html', tasks=[])

@app.route('/api/approve_withdrawal/<int:withdrawal_id>')
def approve_withdrawal(withdrawal_id):
    """Approve withdrawal via API"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        # Get withdrawal details first
        cursor.execute("""
            SELECT w.user_id, w.amount, w.gcash_number, w.status, u.first_name, u.username
            FROM withdrawals w
            JOIN users u ON w.user_id = u.user_id
            WHERE w.id = ?
        """, (withdrawal_id,))
        withdrawal = cursor.fetchone()

        if not withdrawal:
            return jsonify({'success': False, 'message': 'Withdrawal not found'})

        if withdrawal[3] != 'pending':
            return jsonify({'success': False, 'message': 'Withdrawal already processed'})

        cursor.execute("""
            UPDATE withdrawals 
            SET status = 'approved', admin_note = ?, completed_at = ?
            WHERE id = ?
        """, ('Approved via web interface', datetime.now().isoformat(), withdrawal_id))

        conn.commit()
        conn.close()

        # Send notification to user via Telegram
        try:
            import requests

            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'
            user_id = withdrawal[0]
            amount = withdrawal[1]
            gcash_number = withdrawal[2]

            message = f"✅ Withdrawal Approved!\n\n" \
                     f"Amount: ₱{amount:,.2f}\n" \
                     f"GCash: {gcash_number}\n" \
                     f"Your funds have been processed successfully!"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': user_id,
                'text': message
            }
            requests.post(url, data=data, timeout=10)
        except Exception:
            pass  # Don't fail if notification fails

        return jsonify({'success': True, 'message': f'Withdrawal #{withdrawal_id} approved'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reject_withdrawal/<int:withdrawal_id>', methods=['GET', 'POST'])
def reject_withdrawal(withdrawal_id):
    """Reject withdrawal via API"""
    try:
        # Get rejection message from POST request
        rejection_message = ''
        if request.method == 'POST' and request.is_json:
            data = request.get_json()
            rejection_message = data.get('message', '').strip()
        
        conn = get_db()
        cursor = conn.cursor()

        # Get withdrawal details
        cursor.execute("SELECT user_id, amount FROM withdrawals WHERE id = ?", (withdrawal_id,))
        result = cursor.fetchone()

        if not result:
            return jsonify({'success': False, 'message': 'Withdrawal not found'})

        user_id, amount = result

        # Refund balance
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))

        # Prepare admin note
        admin_note = rejection_message if rejection_message else 'Rejected via web interface'

        # Update withdrawal status
        cursor.execute("""
            UPDATE withdrawals 
            SET status = 'rejected', admin_note = ?, completed_at = ?
            WHERE id = ?
        """, (admin_note, datetime.now().isoformat(), withdrawal_id))

        # Log refund transaction
        cursor.execute("""
            INSERT INTO transactions (user_id, type, amount, description)
            VALUES (?, ?, ?, ?)
        """, (user_id, 'withdrawal_refund', amount, 'Withdrawal rejected - refund'))

        conn.commit()
        conn.close()

        # Send notification to user about rejection
        try:
            import requests
            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'

            # Build notification message
            notification_text = f"❌ Withdrawal Rejected\n\n" \
                     f"Amount: ₱{amount:,.2f}\n" \
                     f"Your funds have been refunded to your balance.\n"
            
            if rejection_message:
                notification_text += f"\nReason: {rejection_message}\n"
            
            notification_text += f"\nPlease contact support if you have questions."

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': user_id,
                'text': notification_text
            }
            requests.post(url, data=data, timeout=10)
        except Exception:
            pass  # Don't fail if notification fails

        return jsonify({'success': True, 'message': f'Withdrawal #{withdrawal_id} rejected and refunded'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/ban_user/<int:user_id>')
def ban_user(user_id):
    """Ban user via API"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("UPDATE users SET is_banned = 1 WHERE user_id = ?", (user_id,))
        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': f'User {user_id} banned'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/unban_user/<int:user_id>')
def unban_user(user_id):
    """Unban user via API"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("UPDATE users SET is_banned = 0 WHERE user_id = ?", (user_id,))
        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': f'User {user_id} unbanned'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reset_cooldowns')
def reset_cooldowns():
    """Reset all user cooldowns for all tasks"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        # Reset daily rewards
        cursor.execute("UPDATE users SET last_reward_claimed = NULL")

        # Reset shortlink claims
        cursor.execute("DELETE FROM shortlink_clicks")

        # Reset math sessions
        cursor.execute("DELETE FROM math_sessions")
        cursor.execute("DELETE FROM math_links")

        # Reset watch ads
        #cursor.execute("DELETE FROM watch_ads")

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'All user cooldowns have been reset successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reset_daily_rewards')
def reset_daily_rewards():
    """Reset only daily reward cooldowns"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("UPDATE users SET last_reward_claimed = NULL")

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Daily reward cooldowns have been reset successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reset_shortlinks')
def reset_shortlinks():
    """Reset only shortlink cooldowns"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("DELETE FROM shortlink_clicks")

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Shortlink cooldowns have been reset successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reset_math')
def reset_math():
    """Reset only math cooldowns"""
    try:
        conn = sqlite3.connect('bot_users.db')
        cursor = conn.cursor()

        # Reset math sessions by marking all as completed and setting last_math_at to old date
        old_date = (datetime.now() - timedelta(minutes=1441)).isoformat()  # 1441 minutes ago (just over 24 hours)
        cursor.execute(
            "UPDATE math_sessions SET session_completed = 1, last_math_at = ? WHERE session_completed = 0",
            (old_date,)
        )

        # Also reset completed sessions to allow new ones
        cursor.execute(
            "UPDATE math_sessions SET last_math_at = ? WHERE session_completed = 1",
            (old_date,)
        )

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Math cooldowns reset for all users'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/api/reset_watch_ads')
def reset_watch_ads():
    """Reset only watch ads cooldowns"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        #cursor.execute("DELETE FROM watch_ads")

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Watch ads cooldowns have been reset successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/reset_captcha')
def reset_captcha():
    """Reset only captcha cooldowns"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        old_date = (datetime.now() - timedelta(minutes=1441)).isoformat()
        cursor.execute(
            "UPDATE captcha_sessions SET session_completed = 1, last_captcha_at = ? WHERE session_completed = 0",
            (old_date,)
        )

        cursor.execute(
            "UPDATE captcha_sessions SET last_captcha_at = ? WHERE session_completed = 1",
            (old_date,)
        )

        conn.commit()
        conn.close()

        return jsonify({'success': True, 'message': 'Captcha cooldowns reset for all users'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/api/cleanup_database')
def cleanup_database():
    """Clean up old data and vacuum database"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        # Remove old data older than 30 days
        thirty_days_ago = (datetime.now() - timedelta(days=30)).isoformat()

        # Clean shortlink clicks
        cursor.execute("DELETE FROM shortlink_clicks WHERE click_timestamp < ?", (thirty_days_ago,))
        deleted_shortlinks = cursor.rowcount

        # Clean old completed math sessions
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        cursor.execute("DELETE FROM math_sessions WHERE session_completed = 1 AND last_math_at < ?", (week_ago,))
        deleted_sessions = cursor.rowcount

        cursor.execute("DELETE FROM math_links WHERE session_id NOT IN (SELECT session_id FROM math_sessions)")
        deleted_links = cursor.rowcount

        #```python
        # Clean old watch ads
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 1 AND claimed_at < ?", (week_ago,))
        deleted_ads = cursor.rowcount

        conn.commit()

        # Vacuum database
        cursor.execute("VACUUM")

        conn.close()

        return jsonify({
            'success': True, 
            'message': f'Database cleaned: {deleted_shortlinks} shortlinks, {deleted_sessions} sessions, {deleted_links} links, {deleted_ads} ads removed. Database vacuumed.'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/cleanup_expired_watch_ads')
def cleanup_expired_watch_ads():
    """Clean up expired watch ads entries"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        # Remove expired watch ads (older than 24 hours and unclaimed)
        twenty_four_hours_ago = (datetime.now() - timedelta(hours=24)).isoformat()
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 0 AND created_at < ?", (twenty_four_hours_ago,))
        deleted_unclaimed = cursor.rowcount

        # Remove old claimed watch ads (older than 7 days)
        week_ago = (datetime.now() - timedelta(days=7)).isoformat()
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 1 AND claimed_at < ?", (week_ago,))
        deleted_claimed = cursor.rowcount

        conn.commit()
        conn.close()

        return jsonify({
            'success': True, 
            'message': f'Watch ads cleanup complete: {deleted_unclaimed} expired unclaimed ads, {deleted_claimed} old claimed ads removed.'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/cleanup_all_expired')
def cleanup_all_expired():
    """Clean up all types of expired data in one click"""
    try:
        conn = get_db()
        cursor = conn.cursor()

        # Current timestamps
        now = datetime.now()
        twenty_four_hours_ago = (now - timedelta(hours=24)).isoformat()
        week_ago = (now - timedelta(days=7)).isoformat()
        thirty_days_ago = (now - timedelta(days=30)).isoformat()

        # Clean expired unclaimed watch ads (older than 24 hours)
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 0 AND created_at < ?", (twenty_four_hours_ago,))
        expired_watch_ads = cursor.rowcount

        # Clean old claimed watch ads (older than 7 days)
        cursor.execute("DELETE FROM watch_ads WHERE reward_claimed = 1 AND claimed_at < ?", (week_ago,))
        old_watch_ads = cursor.rowcount

        # Clean expired unclaimed shortlinks (older than 24 hours)
        cursor.execute("DELETE FROM shortlink_clicks WHERE reward_claimed = 0 AND click_timestamp < ?", (twenty_four_hours_ago,))
        expired_shortlinks = cursor.rowcount

        # Clean old claimed shortlinks (older than 30 days)
        cursor.execute("DELETE FROM shortlink_clicks WHERE reward_claimed = 1 AND click_timestamp < ?", (thirty_days_ago,))
        old_shortlinks = cursor.rowcount

        # Clean incomplete math sessions (older than 24 hours)
        cursor.execute("DELETE FROM math_sessions WHERE session_completed = 0 AND created_at < ?", (twenty_four_hours_ago,))
        incomplete_math_sessions = cursor.rowcount

        # Clean old completed math sessions (older than 7 days)
        cursor.execute("DELETE FROM math_sessions WHERE session_completed = 1 AND last_math_at < ?", (week_ago,))
        old_math_sessions = cursor.rowcount

        # Clean orphaned math links
        cursor.execute("DELETE FROM math_links WHERE session_id NOT IN (SELECT session_id FROM math_sessions)")
        orphaned_math_links = cursor.rowcount

        # Clean old transactions (older than 90 days) - keep important ones
        ninety_days_ago = (now - timedelta(days=90)).isoformat()
        cursor.execute("DELETE FROM transactions WHERE type NOT IN ('withdrawal_request', 'withdrawal_refund') AND timestamp < ?", (ninety_days_ago,))
        old_transactions = cursor.rowcount

        conn.commit()

        # Vacuum database to reclaim space
        cursor.execute("VACUUM")

        conn.close()

        total_removed = (expired_watch_ads + old_watch_ads + expired_shortlinks + 
                        old_shortlinks + incomplete_math_sessions + old_math_sessions + 
                        orphaned_math_links + old_transactions)

        return jsonify({
            'success': True, 
            'message': f'Complete cleanup finished! Removed {total_removed} expired entries: {expired_watch_ads} expired ads, {old_watch_ads} old ads, {expired_shortlinks} expired shortlinks, {old_shortlinks} old shortlinks, {incomplete_math_sessions} incomplete math sessions, {old_math_sessions} old math sessions, {orphaned_math_links} orphaned links, {old_transactions} old transactions. Database optimized.'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})



@app.route('/leaderboard')
def leaderboard():
    """Leaderboard page showing top users by referrals or balance"""
    sort_by = request.args.get('sort', 'referrals')

    conn = get_db()
    cursor = conn.cursor()

    # Get top users by referrals or balance
    if sort_by == 'balance':
        cursor.execute("""
            SELECT user_id, username, first_name, referrals, balance, created_at, is_banned
            FROM users 
            WHERE balance > 0
            ORDER BY balance DESC, referrals DESC
            LIMIT 50
        """)
    else:
        cursor.execute("""
            SELECT user_id, username, first_name, referrals, balance, created_at, is_banned
            FROM users 
            ORDER BY referrals DESC, balance DESC
            LIMIT 50
        """)

    users_data = cursor.fetchall()
    conn.close()

    # Format users data
    leaderboard_users = []
    for i, user in enumerate(users_data):
        leaderboard_users.append({
            'rank': i + 1,
            'user_id': user[0],
            'username': user[1] or 'No username',
            'first_name': user[2] or 'Unknown',
            'referrals': user[3],
            'balance': format_currency(user[4]),
            'created_at': format_datetime(user[5]) if user[5] else 'Unknown',
            'is_banned': bool(user[6]),
            'status': '🚫 Banned' if user[6] else '✅ Active'
        })

    return render_template('leaderboard.html', users=leaderboard_users, sort_by=sort_by)

@app.route('/settings', methods=['GET', 'POST'])
def settings():
    """Settings management page"""
    if request.method == 'POST':
        try:
            # Get form data
            new_reward = request.form.get('shortlink_reward')
            new_base_url = request.form.get('base_url')
            new_math_reward = request.form.get('math_reward')
            new_math_per_session = request.form.get('math_per_session')
            new_watch_ads_reward = request.form.get('watch_ads_reward')
            watch_ads_description = request.form.get('watch_ads_description')
            rewarded_ads_reward = request.form.get('rewarded_ads_reward')
            rewarded_ads_limit = request.form.get('rewarded_ads_limit')
            popup_ads_reward = request.form.get('popup_ads_reward')
            popup_ads_limit = request.form.get('popup_ads_limit')
            watch_ads_reset_hour = request.form.get('watch_ads_reset_hour')
            taskcenter_ad_reward = request.form.get('taskcenter_ad_reward')
            new_captcha_reward = request.form.get('captcha_reward')
            new_captcha_per_session = request.form.get('captcha_per_session')
            new_minimum_withdrawal = request.form.get('minimum_withdrawal')
            new_daily_reward = request.form.get('daily_reward')
            task_center_url = request.form.get('task_center_url')

            # Get cooldown settings
            daily_cooldown = request.form.get('daily_cooldown')
            shortlink_cooldown = request.form.get('shortlink_cooldown')
            math_cooldown_minutes = request.form.get('math_cooldown_minutes')
            watch_ads_cooldown_minutes = request.form.get('watch_ads_cooldown_minutes')
            captcha_cooldown_minutes = request.form.get('captcha_cooldown_minutes')

            # Get withdrawal settings
            withdrawals_enabled = request.form.get('withdrawals_enabled') == 'on'
            withdrawal_disabled_message = request.form.get('withdrawal_disabled_message', '').strip()

            if not new_reward:
                flash('Shortlink reward amount is required', 'error')
                return redirect(url_for('settings'))

            if not new_base_url:
                flash('Base URL is required', 'error')
                return redirect(url_for('settings'))

            if not new_math_reward:
                flash('Math reward amount is required', 'error')
                return redirect(url_for('settings'))

            if not new_math_per_session:
                flash('Maths per session is required', 'error')
                return redirect(url_for('settings'))

            if not new_watch_ads_reward:
                flash('Watch ads reward (bot links) is required', 'error')
                return redirect(url_for('settings'))
            
            if not rewarded_ads_reward or not popup_ads_reward:
                flash('Watch ads web page reward amounts are required', 'error')
                return redirect(url_for('settings'))
            
            if not rewarded_ads_limit or not popup_ads_limit:
                flash('Watch ads limits are required', 'error')
                return redirect(url_for('settings'))
            
            if not taskcenter_ad_reward:
                flash('Task Center ad reward is required', 'error')
                return redirect(url_for('settings'))

            if not new_minimum_withdrawal:
                flash('Minimum withdrawal amount is required', 'error')
                return redirect(url_for('settings'))

            if not new_daily_reward:
                flash('Daily reward amount is required', 'error')
                return redirect(url_for('settings'))

            if not daily_cooldown:
                flash('Daily reward cooldown is required', 'error')
                return redirect(url_for('settings'))

            if not shortlink_cooldown:
                flash('Shortlink cooldown is required', 'error')
                return redirect(url_for('settings'))

            if not math_cooldown_minutes:
                flash('Math cooldown is required', 'error')
                return redirect(url_for('settings'))

            if not new_captcha_reward:
                flash('Captcha reward amount is required', 'error')
                return redirect(url_for('settings'))

            if not new_captcha_per_session:
                flash('Captchas per session is required', 'error')
                return redirect(url_for('settings'))

            if not captcha_cooldown_minutes:
                flash('Captcha cooldown is required', 'error')
                return redirect(url_for('settings'))

            if not withdrawal_disabled_message:
                withdrawal_disabled_message = 'Withdrawals are temporarily disabled for maintenance. Please try again later.'

            try:
                reward_amount = float(new_reward)
                math_reward_amount = float(new_math_reward)
                math_per_session = int(new_math_per_session)
                watch_ads_reward_amount = float(new_watch_ads_reward)
                rewarded_ads_reward_amount = float(rewarded_ads_reward)
                rewarded_ads_limit_val = int(rewarded_ads_limit)
                popup_ads_reward_amount = float(popup_ads_reward)
                popup_ads_limit_val = int(popup_ads_limit)
                watch_ads_reset_hour_val = int(watch_ads_reset_hour or '0')
                taskcenter_ad_reward_amount = float(taskcenter_ad_reward)
                captcha_reward_amount = float(new_captcha_reward)
                captcha_per_session = int(new_captcha_per_session)
                minimum_withdrawal_amount = float(new_minimum_withdrawal)
                daily_reward_amount = float(new_daily_reward)

                # Parse cooldown values
                daily_cooldown_hours = int(daily_cooldown)
                shortlink_cooldown_hours = int(shortlink_cooldown)
                math_cooldown_minutes = int(math_cooldown_minutes)
                watch_ads_cooldown_minutes = int(watch_ads_cooldown_minutes) if watch_ads_cooldown_minutes else 60  # Default 60 minutes
                captcha_cooldown_minutes = int(captcha_cooldown_minutes)
                watch_ads_cooldown_hours = watch_ads_cooldown_minutes / 60.0  # Convert to hours for backward compatibility

                if reward_amount < 0:
                    flash('Shortlink reward amount must be positive', 'error')
                    return redirect(url_for('settings'))

                if math_reward_amount < 0:
                    flash('Math reward amount must be positive', 'error')
                    return redirect(url_for('settings'))

                if math_per_session < 1 or math_per_session > 20:
                    flash('Maths per session must be between 1 and 20', 'error')
                    return redirect(url_for('settings'))

                if watch_ads_reward_amount < 0:
                    flash('Watch ads reward (bot links) must be positive', 'error')
                    return redirect(url_for('settings'))
                
                if rewarded_ads_reward_amount < 0 or popup_ads_reward_amount < 0:
                    flash('Watch ads web page reward amounts must be positive', 'error')
                    return redirect(url_for('settings'))
                
                if rewarded_ads_limit_val < 1 or popup_ads_limit_val < 1:
                    flash('Watch ads limits must be at least 1', 'error')
                    return redirect(url_for('settings'))
                
                if watch_ads_reset_hour_val < 0 or watch_ads_reset_hour_val > 23:
                    flash('Watch ads reset hour must be between 0 and 23', 'error')
                    return redirect(url_for('settings'))
                
                if taskcenter_ad_reward_amount < 0:
                    flash('Task Center ad reward must be positive', 'error')
                    return redirect(url_for('settings'))

                if minimum_withdrawal_amount < 0:
                    flash('Minimum withdrawal amount must be positive', 'error')
                    return redirect(url_for('settings'))

                if daily_reward_amount < 0:
                    flash('Daily reward amount must be positive', 'error')
                    return redirect(url_for('settings'))

                if daily_cooldown_hours < 1:
                    flash('Daily reward cooldown must be at least 1 hour', 'error')
                    return redirect(url_for('settings'))

                if shortlink_cooldown_hours < 1:
                    flash('Shortlink cooldown must be at least 1 hour', 'error')
                    return redirect(url_for('settings'))

                if math_cooldown_minutes < 1:
                    flash('Math cooldown must be at least 1 minute', 'error')
                    return redirect(url_for('settings'))

                if watch_ads_cooldown_minutes and watch_ads_cooldown_minutes < 1:
                    flash('Watch ads cooldown must be at least 1 minute', 'error')
                    return redirect(url_for('settings'))

                if captcha_reward_amount < 0:
                    flash('Captcha reward amount must be positive', 'error')
                    return redirect(url_for('settings'))

                if captcha_per_session < 1 or captcha_per_session > 20:
                    flash('Captchas per session must be between 1 and 20', 'error')
                    return redirect(url_for('settings'))

                if captcha_cooldown_minutes < 1:
                    flash('Captcha cooldown must be at least 1 minute', 'error')
                    return redirect(url_for('settings'))

                # Validate base URL format
                if not new_base_url.startswith(('http://', 'https://')):
                    flash('Base URL must start with http:// or https://', 'error')
                    return redirect(url_for('settings'))

                # Remove trailing slash if present
                new_base_url = new_base_url.rstrip('/')
                
                # Validate and set default task center URL
                if not task_center_url:
                    task_center_url = 'https://t.me/greatgainbot/taskcenter'
                elif not task_center_url.startswith(('http://', 'https://')):
                    flash('Task Center URL must start with http:// or https://', 'error')
                    return redirect(url_for('settings'))

                # Update the settings in database
                conn = get_db()
                cursor = conn.cursor()

                # Create settings table if it doesn't exist
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS settings (
                        key TEXT PRIMARY KEY,
                        value TEXT
                    )
                ''')

                # Insert or update the shortlink reward amount
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('shortlink_reward_amount', ?)
                ''', (str(reward_amount),))

                # Insert or update the math reward amount
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('math_reward_amount', ?)
                ''', (str(math_reward_amount),))

                # Insert or update the maths per session
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('math_per_session', ?)
                ''', (str(math_per_session),))

                # Insert or update the watch ads reward for bot links
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('watch_ads_reward_amount', ?)
                ''', (str(watch_ads_reward_amount),))
                
                # Insert or update the watch ads web page settings
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('watch_ads_description', ?)
                ''', (watch_ads_description,))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('rewarded_ads_reward', ?)
                ''', (str(rewarded_ads_reward_amount),))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('rewarded_ads_limit', ?)
                ''', (str(rewarded_ads_limit_val),))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('popup_ads_reward', ?)
                ''', (str(popup_ads_reward_amount),))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('popup_ads_limit', ?)
                ''', (str(popup_ads_limit_val),))
                
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('watch_ads_reset_hour', ?)
                ''', (str(watch_ads_reset_hour_val),))
                
                # Insert or update the taskcenter ad reward
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('taskcenter_ad_reward', ?)
                ''', (str(taskcenter_ad_reward_amount),))

                # Insert or update the base URL
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('base_url', ?)
                ''', (new_base_url,))

                # Update individual page URLs based on base URL for backward compatibility
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('reward_page_url', ?)
                ''', (f"{new_base_url}/reward",))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('math_page_url', ?)
                ''', (f"{new_base_url}/math",))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('watch_ads_page_url', ?)
                ''', (f"{new_base_url}/watch_ads",))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('captcha_page_url', ?)
                ''', (f"{new_base_url}/captcha",))
                
                # Insert or update task center URL
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('task_center_url', ?)
                ''', (task_center_url,))

                # Insert or replace minimum withdrawal amount
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('minimum_withdrawal', ?)
                ''', (str(minimum_withdrawal_amount),))

                # Insert or update daily reward amount
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('daily_reward_amount', ?)
                ''', (str(daily_reward_amount),))

                # Insert or update cooldown settings
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('daily_reward_cooldown', ?)
                ''', (str(daily_cooldown_hours),))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('shortlink_cooldown', ?)
                ''', (str(shortlink_cooldown_hours),))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('math_cooldown_minutes', ?)
                ''', (str(math_cooldown_minutes),))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('watch_ads_cooldown_minutes', ?)
                ''', (str(watch_ads_cooldown_minutes),))

                # Insert or update the captcha reward amount
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('captcha_reward_amount', ?)
                ''', (str(captcha_reward_amount),))

                # Insert or update the captchas per session
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('captcha_per_session', ?)
                ''', (str(captcha_per_session),))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('captcha_cooldown_minutes', ?)
                ''', (str(captcha_cooldown_minutes),))

                # Insert or update withdrawal settings
                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('withdrawals_enabled', ?)
                ''', ('1' if withdrawals_enabled else '0',))

                cursor.execute('''
                    INSERT OR REPLACE INTO settings (key, value) 
                    VALUES ('withdrawal_disabled_message', ?)
                ''', (withdrawal_disabled_message,))

                conn.commit()
                conn.close()

                # Clear any potential caching by forcing a fresh database read
                try:
                    test_conn = get_db()
                    test_cursor = test_conn.cursor()
                    test_cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_reward_amount'")
                    verify_result = test_cursor.fetchone()
                    test_conn.close()
                except:
                    pass

                flash('Settings updated successfully!', 'success')

            except ValueError:
                flash('Invalid reward amount format', 'error')

        except Exception as e:
            flash(f'Error updating settings: {str(e)}', 'error')

        return redirect(url_for('settings'))

    # GET request - show current settings
    conn = get_db()
    cursor = conn.cursor()

    # Get current shortlink reward amount
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_reward_amount'")
        result = cursor.fetchone()
        current_reward = float(result[0]) if result else 0.0724  # Default value
    except:
        current_reward = 0.0724  # Default value

    # Get current math reward amount
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'math_reward_amount'")
        result = cursor.fetchone()
        current_math_reward = float(result[0]) if result else 0.0671  # Default value
    except:
        current_math_reward = 0.0671  # Default value

    # Get current maths per session
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'math_per_session'")
        result = cursor.fetchone()
        current_math_per_session = int(result[0]) if result else 5  # Default value
    except:
        current_math_per_session = 5  # Default value

    # Get current watch ads reward for bot links
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reward_amount'")
        result = cursor.fetchone()
        current_watch_ads_reward = float(result[0]) if result else 0.0532
    except:
        current_watch_ads_reward = 0.0532
    
    # Get current watch ads web page settings
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_description'")
        result = cursor.fetchone()
        current_watch_ads_description = result[0] if result else 'Watch ads to earn rewards! Complete rewarded ads or pop-up ads to increase your balance.'
    except:
        current_watch_ads_description = 'Watch ads to earn rewards! Complete rewarded ads or pop-up ads to increase your balance.'
    
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'rewarded_ads_reward'")
        result = cursor.fetchone()
        current_rewarded_ads_reward = float(result[0]) if result else 0.00069
    except:
        current_rewarded_ads_reward = 0.00069
    
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'rewarded_ads_limit'")
        result = cursor.fetchone()
        current_rewarded_ads_limit = int(result[0]) if result else 50
    except:
        current_rewarded_ads_limit = 50
    
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'popup_ads_reward'")
        result = cursor.fetchone()
        current_popup_ads_reward = float(result[0]) if result else 0.00069
    except:
        current_popup_ads_reward = 0.00069
    
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'popup_ads_limit'")
        result = cursor.fetchone()
        current_popup_ads_limit = int(result[0]) if result else 100
    except:
        current_popup_ads_limit = 100
    
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reset_hour'")
        result = cursor.fetchone()
        current_watch_ads_reset_hour = int(result[0]) if result else 8
    except:
        current_watch_ads_reset_hour = 8
    
    # Get current taskcenter ad reward
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ad_reward'")
        result = cursor.fetchone()
        current_taskcenter_ad_reward = float(result[0]) if result else 0.05
    except:
        current_taskcenter_ad_reward = 0.05

    # Get current base URL
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'base_url'")
        result = cursor.fetchone()
        current_base_url = result[0] if result else "https://example.com"
    except:
        current_base_url = "https://example.com"

    # Get current minimum withdrawal
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'minimum_withdrawal'")
        result = cursor.fetchone()
        current_minimum_withdrawal = float(result[0]) if result else 0.35
    except:
        current_minimum_withdrawal = 0.35

    # Get current daily reward
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'daily_reward_amount'")
        result = cursor.fetchone()
        current_daily_reward = float(result[0]) if result else 0.0053
    except:
        current_daily_reward = 0.0053

    # Get current cooldown settings
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'daily_reward_cooldown'")
        result = cursor.fetchone()
        current_daily_cooldown = int(result[0]) if result else 24
    except:
        current_daily_cooldown = 24

    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_cooldown'")
        result = cursor.fetchone()
        current_shortlink_cooldown = int(result[0]) if result else 24
    except:
        current_shortlink_cooldown = 24

    # Get current math cooldown
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'math_cooldown_minutes'")
        result = cursor.fetchone()
        current_math_cooldown_minutes = int(result[0]) if result else 1440  # Default 1440 minutes (24 hours)
    except:
        current_math_cooldown_minutes = 1440  # Default 1440 minutes (24 hours)

    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_cooldown_minutes'")
        result = cursor.fetchone()
        current_watch_ads_cooldown_minutes = int(result[0]) if result else 60
    except:
        current_watch_ads_cooldown_minutes = 60

    # Get current captcha reward amount
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_reward_amount'")
        result = cursor.fetchone()
        current_captcha_reward = float(result[0]) if result else 0.0671  # Default value
    except:
        current_captcha_reward = 0.0671  # Default value

    # Get current captchas per session
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_per_session'")
        result = cursor.fetchone()
        current_captcha_per_session = int(result[0]) if result else 5  # Default value
    except:
        current_captcha_per_session = 5  # Default value

    # Get current captcha cooldown
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_cooldown_minutes'")
        result = cursor.fetchone()
        current_captcha_cooldown_minutes = int(result[0]) if result else 1440  # Default 1440 minutes (24 hours)
    except:
        current_captcha_cooldown_minutes = 1440  # Default 1440 minutes (24 hours)

    # Get current withdrawal settings
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'withdrawals_enabled'")
        result = cursor.fetchone()
        current_withdrawals_enabled = bool(int(result[0])) if result else True
    except:
        current_withdrawals_enabled = True

    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'withdrawal_disabled_message'")
        result = cursor.fetchone()
        current_withdrawal_disabled_message = result[0] if result else 'Withdrawals are temporarily disabled for maintenance. Please try again later.'
    except:
        current_withdrawal_disabled_message = 'Withdrawals are temporarily disabled for maintenance. Please try again later.'
    
    # Get current task center URL
    try:
        cursor.execute("SELECT value FROM settings WHERE key = 'task_center_url'")
        result = cursor.fetchone()
        current_task_center_url = result[0] if result else 'https://t.me/greatgainbot/taskcenter'
    except:
        current_task_center_url = 'https://t.me/greatgainbot/taskcenter'

    conn.close()

    return render_template('settings.html', 
                         current_reward=current_reward, 
                         current_math_reward=current_math_reward,
                         current_math_per_session=current_math_per_session,
                         current_watch_ads_reward=current_watch_ads_reward,
                         current_watch_ads_description=current_watch_ads_description,
                         current_rewarded_ads_reward=current_rewarded_ads_reward,
                         current_rewarded_ads_limit=current_rewarded_ads_limit,
                         current_popup_ads_reward=current_popup_ads_reward,
                         current_popup_ads_limit=current_popup_ads_limit,
                         current_watch_ads_reset_hour=current_watch_ads_reset_hour,
                         current_taskcenter_ad_reward=current_taskcenter_ad_reward,
                         current_captcha_reward=current_captcha_reward,
                         current_captcha_per_session=current_captcha_per_session,
                         current_base_url=current_base_url,
                         current_minimum_withdrawal=current_minimum_withdrawal,
                         current_daily_reward=current_daily_reward,
                         current_daily_cooldown=current_daily_cooldown,
                         current_shortlink_cooldown=current_shortlink_cooldown,
                         current_math_cooldown_minutes=current_math_cooldown_minutes,
                         current_watch_ads_cooldown_minutes=current_watch_ads_cooldown_minutes,
                         current_captcha_cooldown_minutes=current_captcha_cooldown_minutes,
                         current_withdrawals_enabled=current_withdrawals_enabled,
                         current_withdrawal_disabled_message=current_withdrawal_disabled_message,
                         current_task_center_url=current_task_center_url)

@app.route('/api/claim-shortlink-reward', methods=['POST'])
def claim_shortlink_reward():
    """Handle shortlink reward claiming from the reward page"""
    try:
        data = request.get_json()

        if not data or 'code' not in data:
            return jsonify({
                'success': False, 
                'title': 'Invalid Request', 
                'message': 'No reward code provided'
            })

        code = data['code']
        ip_address = data.get('ip_address', '')
        user_agent = data.get('user_agent', '')

        conn = get_db()
        cursor = conn.cursor()

        # Check if code exists and not claimed
        cursor.execute(
            "SELECT user_id, reward_claimed FROM shortlink_clicks WHERE click_code = ?",
            (code,)
        )
        result = cursor.fetchone()

        if not result:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Invalid Link', 
                'message': 'This reward link is invalid or expired.'
            })

        user_id, reward_claimed = result

        if reward_claimed:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Already Claimed', 
                'message': 'You have already claimed this reward.'
            })

        # Check if this IP address has been used by a DIFFERENT user to claim shortlink rewards
        if ip_address:
            cursor.execute(
                "SELECT COUNT(*) FROM shortlink_clicks WHERE ip_address = ? AND reward_claimed = 1 AND user_id != ?",
                (ip_address, user_id)
            )
            ip_claim_count = cursor.fetchone()[0]

            if ip_claim_count > 0:
                conn.close()
                return jsonify({
                    'success': False, 
                    'title': 'IP Already Used', 
                    'message': 'This IP address has already been used by another user to claim a shortlink reward.'
                })

        # Update user's IP address if not set
        cursor.execute("SELECT ip_address FROM users WHERE user_id = ?", (user_id,))
        user_ip_result = cursor.fetchone()
        if user_ip_result and not user_ip_result[0] and ip_address:
            cursor.execute("UPDATE users SET ip_address = ? WHERE user_id = ?", (ip_address, user_id))

        # Mark as claimed and update tracking info
        cursor.execute(
            "UPDATE shortlink_clicks SET reward_claimed = 1, ip_address = ?, user_agent = ? WHERE click_code = ?",
            (ip_address, user_agent, code)
        )

        # Get shortlink reward amount from settings
        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_reward_amount'")
        reward_result = cursor.fetchone()
        SHORTLINK_REWARD_AMOUNT = float(reward_result[0]) if reward_result else 0.0724

        cursor.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (SHORTLINK_REWARD_AMOUNT, user_id)
        )

        # Log transaction
        cursor.execute(
            "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
            (user_id, 'shortlink_reward', SHORTLINK_REWARD_AMOUNT, 'Shortlink click reward')
        )

        # Give referral bonus for shortlink reward
        cursor.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
        referrer_result = cursor.fetchone()
        if referrer_result and referrer_result[0]:
            referrer_id = referrer_result[0]
            referral_bonus = SHORTLINK_REWARD_AMOUNT * 0.10  # 10% referral bonus
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id=?",
                (referral_bonus, referrer_id)
            )
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (referrer_id, 'referral_bonus', referral_bonus, f'10% referral bonus from user {user_id}')
            )

        conn.commit()
        conn.close()

        # Send notification to user via Telegram
        try:
            import requests

            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'

            message = f"🎉 Shortlink Reward Claimed!\n\n" \
                     f"You earned: ₱{SHORTLINK_REWARD_AMOUNT:g}\n" \
                     f"Check your balance in the bot!"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': user_id,
                'text': message
            }
            requests.post(url, data=data, timeout=5)
        except Exception:
            pass  # Don't fail if notification fails

        return jsonify({
            'success': True, 
            'amount': SHORTLINK_REWARD_AMOUNT
        })

    except Exception as e:
        return jsonify({
            'success': False, 
            'title': 'Error', 
            'message': 'Unable to process reward. Please try again.'
        })

@app.route('/api/get-math-reward-amount', methods=['GET'])
def get_math_reward_amount():
    """Get current math reward amount"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'math_reward_amount'")
        result = cursor.fetchone()
        conn.close()

        amount = float(result[0]) if result else 0.0671
        return jsonify({'success': True, 'amount': amount})
    except Exception as e:
        return jsonify({'success': False, 'amount': 0.0671})

@app.route('/api/get-watch-ads-reward-amount', methods=['GET'])
def get_watch_ads_reward_amount():
    """Get current watch ads reward amount"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reward_amount'")
        result = cursor.fetchone()
        conn.close()

        amount = float(result[0]) if result else 0.0532
        return jsonify({'success': True, 'amount': amount})
    except Exception as e:
        return jsonify({'success': False, 'amount': 0.0532})

@app.route('/api/get-captcha-reward-amount', methods=['GET'])
def get_captcha_reward_amount():
    """Get current captcha reward amount"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_reward_amount'")
        result = cursor.fetchone()
        conn.close()

        amount = float(result[0]) if result else 0.0671
        return jsonify({'success': True, 'amount': amount})
    except Exception as e:
        return jsonify({'success': False, 'amount': 0.0671})

@app.route('/api/claim-watch-ads-reward', methods=['POST'])
def claim_watch_ads_reward():
    """Handle watch ads reward claiming from the ads page"""
    try:
        data = request.get_json()

        if not data or 'ad' not in data:
            return jsonify({
                'success': False, 
                'title': 'Invalid Request', 
                'message': 'No ad code provided'
            })

        ad_code = data['ad']
        ip_address = data.get('ip_address', '')
        user_agent = data.get('user_agent', '')

        conn = get_db()
        cursor = conn.cursor()

        # Check if ad code exists and not claimed
        cursor.execute(
            "SELECT user_id, reward_claimed FROM watch_ads WHERE ad_code = ?",
            (ad_code,)
        )
        result = cursor.fetchone()

        if not result:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Invalid Link', 
                'message': 'This watch ads link is invalid or expired.'
            })

        user_id, reward_claimed = result

        if reward_claimed:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Already Claimed', 
                'message': 'You have already claimed this reward.'
            })

        # Mark as claimed and update tracking info
        cursor.execute(
            "UPDATE watch_ads SET reward_claimed = 1, claimed_at = ?, ip_address = ?, user_agent = ? WHERE ad_code = ?",
            (datetime.now().isoformat(), ip_address, user_agent, ad_code)
        )

        # Get watch ads reward amount from settings
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reward_amount'")
        reward_result = cursor.fetchone()
        WATCH_ADS_REWARD_AMOUNT = float(reward_result[0]) if reward_result else 0.0532

        cursor.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (WATCH_ADS_REWARD_AMOUNT, user_id)
        )

        # Log transaction
        cursor.execute(
            "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
            (user_id, 'watch_ads_reward', WATCH_ADS_REWARD_AMOUNT, 'Watch ads reward')
        )

        # Give referral bonus for watch ads reward
        cursor.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
        referrer_result = cursor.fetchone()
        if referrer_result and referrer_result[0]:
            referrer_id = referrer_result[0]
            referral_bonus = WATCH_ADS_REWARD_AMOUNT * 0.10  # 10% referral bonus
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id=?",
                (referral_bonus, referrer_id)
            )
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (referrer_id, 'referral_bonus', referral_bonus, f'10% referral bonus from user {user_id}')
            )

        conn.commit()
        conn.close()

        # Send notification to user via Telegram
        try:
            import requests

            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'

            message = f"👁️ Watch Ads Reward Claimed!\n\n" \
                     f"You earned: ₱{WATCH_ADS_REWARD_AMOUNT:g}\n" \
                     f"Check your balance in the bot!"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            data = {
                'chat_id': user_id,
                'text': message
            }
            requests.post(url, data=data, timeout=5)
        except Exception:
            pass  # Don't fail if notification fails

        return jsonify({
            'success': True, 
            'amount': WATCH_ADS_REWARD_AMOUNT
        })

    except Exception as e:
        return jsonify({
            'success': False, 
            'title': 'Error', 
            'message': 'Unable to process reward. Please try again.'
        })

@app.route('/api/watch-ads-settings', methods=['GET'])
def get_watch_ads_settings():
    """Get watch ads page settings"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT key, value FROM settings WHERE key IN ('watch_ads_description', 'rewarded_ads_limit', 'popup_ads_limit', 'rewarded_ads_reward', 'popup_ads_reward', 'watch_ads_reset_hour')")
        settings_rows = cursor.fetchall()
        conn.close()
        
        settings = {}
        defaults = {
            'watch_ads_description': 'Watch ads to earn rewards! Complete rewarded ads or pop-up ads to increase your balance.',
            'rewarded_ads_limit': '50',
            'popup_ads_limit': '100',
            'rewarded_ads_reward': '0.0500',
            'popup_ads_reward': '0.0300',
            'watch_ads_reset_hour': '8'
        }
        
        for key, value in settings_rows:
            settings[key.replace('watch_ads_', '').replace('rewarded_ads_', 'rewarded_').replace('popup_ads_', 'popup_')] = value
        
        for key, default_value in defaults.items():
            simple_key = key.replace('watch_ads_', '').replace('rewarded_ads_', 'rewarded_').replace('popup_ads_', 'popup_')
            if simple_key not in settings:
                settings[simple_key] = default_value
        
        return jsonify({'success': True, 'settings': settings})
    except Exception as e:
        return jsonify({'success': False, 'settings': {}})

@app.route('/api/watch-ads-stats', methods=['GET'])
def get_watch_ads_stats():
    """Get user watch ads statistics for today"""
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        conn = get_db()
        cursor = conn.cursor()
        
        from datetime import datetime
        today = datetime.now().strftime('%Y-%m-%d')
        
        cursor.execute("SELECT rewarded_ads_watched, popup_ads_watched, web_balance FROM daily_watch_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user_result = cursor.fetchone()
        
        # If no record for today, get balance from most recent day
        if not result:
            cursor.execute("SELECT web_balance FROM daily_watch_ads WHERE user_id = ? ORDER BY date DESC LIMIT 1", (user_id,))
            prev_result = cursor.fetchone()
            web_balance = prev_result[0] if prev_result else 0
        else:
            web_balance = result[2]
        
        conn.close()
        
        bot_balance = user_result[0] if user_result else 0
        
        stats = {
            'rewarded_watched': result[0] if result else 0,
            'popup_watched': result[1] if result else 0,
            'balance': web_balance,
            'bot_balance': bot_balance
        }
        
        return jsonify({'success': True, 'stats': stats})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/claim-watch-ad', methods=['POST'])
def claim_watch_ad():
    """Handle watch ad reward claiming"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        ad_type = data.get('ad_type')
        
        if not user_id or not ad_type:
            return jsonify({'success': False, 'message': 'Missing parameters'})
        
        from datetime import datetime
        conn = get_db()
        cursor = conn.cursor()
        
        today = datetime.now().strftime('%Y-%m-%d')
        
        cursor.execute("SELECT value FROM settings WHERE key = ?", (f'{ad_type}_ads_limit',))
        limit_result = cursor.fetchone()
        limit = int(limit_result[0]) if limit_result else (50 if ad_type == 'rewarded' else 100)
        
        cursor.execute("SELECT value FROM settings WHERE key = ?", (f'{ad_type}_ads_reward',))
        reward_result = cursor.fetchone()
        reward = float(reward_result[0]) if reward_result else (0.0500 if ad_type == 'rewarded' else 0.0300)
        
        cursor.execute("SELECT rewarded_ads_watched, popup_ads_watched, web_balance FROM daily_watch_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        if result:
            rewarded_count = result[0]
            popup_count = result[1]
            web_balance = result[2]
        else:
            # New day - reset counters but keep balance from previous day
            rewarded_count = 0
            popup_count = 0
            # Get the most recent balance from any previous day
            cursor.execute("SELECT web_balance FROM daily_watch_ads WHERE user_id = ? ORDER BY date DESC LIMIT 1", (user_id,))
            prev_result = cursor.fetchone()
            web_balance = prev_result[0] if prev_result else 0
        
        current_count = rewarded_count if ad_type == 'rewarded' else popup_count
        
        if current_count >= limit:
            conn.close()
            return jsonify({'success': False, 'message': f'Daily limit reached for {ad_type} ads'})
        
        new_balance = web_balance + reward
        
        if result:
            if ad_type == 'rewarded':
                cursor.execute("UPDATE daily_watch_ads SET rewarded_ads_watched = rewarded_ads_watched + 1, web_balance = ? WHERE user_id = ? AND date = ?", (new_balance, user_id, today))
            else:
                cursor.execute("UPDATE daily_watch_ads SET popup_ads_watched = popup_ads_watched + 1, web_balance = ? WHERE user_id = ? AND date = ?", (new_balance, user_id, today))
        else:
            rewarded_val = 1 if ad_type == 'rewarded' else 0
            popup_val = 1 if ad_type == 'popup' else 0
            cursor.execute("INSERT INTO daily_watch_ads (user_id, date, rewarded_ads_watched, popup_ads_watched, web_balance) VALUES (?, ?, ?, ?, ?)", (user_id, today, rewarded_val, popup_val, new_balance))
        
        # Give 10% referral bonus to referrer
        cursor.execute("SELECT referred_by FROM users WHERE user_id = ?", (user_id,))
        referrer_result = cursor.fetchone()
        if referrer_result and referrer_result[0]:
            referrer_id = referrer_result[0]
            referral_bonus = reward * 0.10  # 10% bonus
            
            # Add referral bonus to referrer's main balance
            cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (referral_bonus, referrer_id))
            
            # Log the transaction
            cursor.execute("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)", 
                         (referrer_id, 'referral_bonus', referral_bonus, f'10% referral bonus from user {user_id} watching {ad_type} ad'))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'amount': reward})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/transfer-balance-to-bot', methods=['POST'])
def transfer_balance_to_bot():
    """Transfer web balance to bot balance"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        from datetime import datetime
        conn = get_db()
        cursor = conn.cursor()
        
        today = datetime.now().strftime('%Y-%m-%d')
        
        cursor.execute("SELECT web_balance FROM daily_watch_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        if not result or result[0] <= 0:
            conn.close()
            return jsonify({'success': False, 'message': 'No balance to transfer'})
        
        web_balance = result[0]
        
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (web_balance, user_id))
        cursor.execute("UPDATE daily_watch_ads SET web_balance = 0 WHERE user_id = ? AND date = ?", (user_id, today))
        cursor.execute("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)", (user_id, 'watch_ads_transfer', web_balance, 'Transferred from watch ads balance'))
        
        conn.commit()
        conn.close()
        
        # Send notification to user
        try:
            import requests
            bot_token = '7897314168:AAH5LAiXGNGtoU7cVvByYp_XHjRVuZrZf2A'
            message = f"✅ *Transfer Successful!*\n\n" \
                     f"💰 Amount: ₱{web_balance:.4f}\n\n" \
                     f"Your watch ads balance has been transferred to your bot balance.\n" \
                     f"You can now claim daily rewards and make withdrawals!"
            
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            notification_data = {
                'chat_id': user_id,
                'text': message,
                'parse_mode': 'Markdown'
            }
            requests.post(url, json=notification_data, timeout=5)
        except Exception as notification_error:
            print(f"Failed to send notification: {notification_error}")
        
        return jsonify({'success': True, 'amount': web_balance})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/claim-math-reward', methods=['POST'])
def claim_math_reward():
    """Handle math reward claiming from the math page"""
    try:
        data = request.get_json()

        if not data or 'math' not in data:
            return jsonify({
                'success': False, 
                'title': 'Invalid Request', 
                'message': 'No math code provided'
            })

        math_code = data['math']
        ip_address =data.get('ip_address', '')
        user_agent = data.get('user_agent', '')
        ad_watched = data.get('ad_watched', False)

        # Check if ad was actually watched
        if not ad_watched:
            return jsonify({
                'success': False, 
                'title': 'AdBlocker Detected', 
                'message': 'Please disable your adblocker and watch the ad to earn rewards.'
            })

        conn = get_db()
        cursor = conn.cursor()

        # Check if math code exists and not claimed
        cursor.execute(
            """SELECT cl.session_id, cl.link_number, cl.completed, cs.user_id, cs.reward_per_math
               FROM math_links cl
               JOIN math_sessions cs ON cl.session_id = cs.session_id
               WHERE cl.math_code = ?""",
            (math_code,)
        )
        result = cursor.fetchone()

        if not result:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Invalid Math', 
                'message': 'This math link is invalid or expired.'
            })

        session_id, link_number, completed, user_id, reward_amount = result

        if completed:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Already Completed', 
                'message': 'You have already completed this math.'
            })

        # Mark math as completed
        cursor.execute(
            "UPDATE math_links SET completed = 1, completed_at = ?, ip_address = ?, user_agent = ? WHERE math_code = ?",
            (format_datetime(datetime.now().isoformat()), ip_address, user_agent, math_code)
        )

        # Update session progress
        cursor.execute(
            "UPDATE math_sessions SET maths_completed = maths_completed + 1, last_math_at = ? WHERE session_id = ?",
            (datetime.now().isoformat(), session_id)
        )

        # Add reward to user balance
        cursor.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (reward_amount, user_id)
        )

        # Log transaction
        cursor.execute(
            "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
            (user_id, 'math_reward', reward_amount, f'Math {link_number}/5 completed')
        )

        # Give referral bonus for math reward
        cursor.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
        referrer_result = cursor.fetchone()
        if referrer_result and referrer_result[0]:
            referrer_id = referrer_result[0]
            referral_bonus = reward_amount * 0.10  # 10% referral bonus
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id=?",
                (referral_bonus, referrer_id)
            )
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (referrer_id, 'referral_bonus', referral_bonus, f'10% referral bonus from user {user_id}')
            )

        # Check if session is completed (all maths done)
        cursor.execute(
            "SELECT maths_completed, total_maths FROM math_sessions WHERE session_id = ?",
            (session_id,)
        )
        session_data = cursor.fetchone()
        completed_count = session_data[0]
        total_maths = session_data[1]

        if completed_count >= total_maths:
            cursor.execute(
                "UPDATE math_sessions SET session_completed = 1 WHERE session_id = ?",
                (session_id,)
            )

        conn.commit()
        conn.close()

        # Send notification to user via Telegram
        try:
            import requests

            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'

            if completed_count >= total_maths:
                message = f"🎉 Math Session Completed!\n\n" \
                         f"You completed math {link_number}/{total_maths}\n" \
                         f"This session earned: ₱{reward_amount * total_maths:g}\n" \
                         f"Next session available in 24 hours!"
            else:
                message = f"🛡️ Math Completed!\n\n" \
                         f"You completed math {link_number}/{total_maths}\n" \
                         f"You earned: ₱{reward_amount:g}\n" \
                         f"Progress: {completed_count}/{total_maths}"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            notification_data = {
                'chat_id': user_id,
                'text': message
            }
            requests.post(url, data=notification_data, timeout=5)
        except Exception:
            pass  # Don't fail if notification fails

        return jsonify({
            'success': True, 
            'amount': reward_amount,
            'math_number': link_number,
            'completed_count': completed_count,
            'total_maths': total_maths,
            'session_completed': completed_count >= total_maths
        })

    except Exception as e:
        return jsonify({
            'success': False, 
            'title': 'Error', 
            'message': 'Unable to process math. Please try again.'
        })

@app.route('/api/claim-captcha-reward', methods=['POST'])
def claim_captcha_reward():
    """Handle captcha reward claiming from the captcha page"""
    try:
        data = request.get_json()

        if not data or 'captcha' not in data:
            return jsonify({
                'success': False, 
                'title': 'Invalid Request', 
                'message': 'No captcha code provided'
            })

        captcha_code = data['captcha']
        ip_address = data.get('ip_address', '')
        user_agent = data.get('user_agent', '')
        ad_watched = data.get('ad_watched', False)

        if not ad_watched:
            return jsonify({
                'success': False, 
                'title': 'AdBlocker Detected', 
                'message': 'Please disable your adblocker and watch the ad to earn rewards.'
            })

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute(
            """SELECT ct.session_id, ct.task_number, ct.completed, cs.user_id, cs.reward_per_captcha
               FROM captcha_tasks ct
               JOIN captcha_sessions cs ON ct.session_id = cs.session_id
               WHERE ct.captcha_code = ?""",
            (captcha_code,)
        )
        result = cursor.fetchone()

        if not result:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Invalid Captcha', 
                'message': 'This captcha link is invalid or expired.'
            })

        session_id, task_number, completed, user_id, reward_amount = result

        if completed:
            conn.close()
            return jsonify({
                'success': False, 
                'title': 'Already Completed', 
                'message': 'You have already completed this captcha.'
            })

        cursor.execute(
            "UPDATE captcha_tasks SET completed = 1, completed_at = ?, ip_address = ?, user_agent = ? WHERE captcha_code = ?",
            (datetime.now().isoformat(), ip_address, user_agent, captcha_code)
        )

        cursor.execute(
            "UPDATE captcha_sessions SET captchas_completed = captchas_completed + 1, last_captcha_at = ? WHERE session_id = ?",
            (datetime.now().isoformat(), session_id)
        )

        cursor.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (reward_amount, user_id)
        )

        cursor.execute(
            "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
            (user_id, 'captcha_reward', reward_amount, f'Captcha {task_number}/5 completed')
        )

        cursor.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,))
        referrer_result = cursor.fetchone()
        if referrer_result and referrer_result[0]:
            referrer_id = referrer_result[0]
            referral_bonus = reward_amount * 0.10
            cursor.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id=?",
                (referral_bonus, referrer_id)
            )
            cursor.execute(
                "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)",
                (referrer_id, 'referral_bonus', referral_bonus, f'10% referral bonus from user {user_id}')
            )

        cursor.execute(
            "SELECT captchas_completed, total_captchas FROM captcha_sessions WHERE session_id = ?",
            (session_id,)
        )
        session_data = cursor.fetchone()
        completed_count = session_data[0]
        total_captchas = session_data[1]

        if completed_count >= total_captchas:
            cursor.execute(
                "UPDATE captcha_sessions SET session_completed = 1 WHERE session_id = ?",
                (session_id,)
            )

        conn.commit()
        conn.close()

        try:
            import requests

            bot_token = '7776843072:AAHiXTAxi31mJYUcwmyBknQgx26qYUYRE2w'

            if completed_count >= total_captchas:
                message = f"🎉 Captcha Session Completed!\n\n" \
                         f"You completed captcha {task_number}/{total_captchas}\n" \
                         f"This session earned: ₱{reward_amount * total_captchas:g}\n" \
                         f"Next session available in 24 hours!"
            else:
                message = f"🔐 Captcha Completed!\n\n" \
                         f"You completed captcha {task_number}/{total_captchas}\n" \
                         f"You earned: ₱{reward_amount:g}\n" \
                         f"Progress: {completed_count}/{total_captchas}"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            notification_data = {
                'chat_id': user_id,
                'text': message
            }
            requests.post(url, data=notification_data, timeout=5)
        except Exception:
            pass

        return jsonify({
            'success': True, 
            'amount': reward_amount,
            'captcha_number': task_number,
            'completed_count': completed_count,
            'total_captchas': total_captchas,
            'session_completed': completed_count >= total_captchas
        })

    except Exception as e:
        return jsonify({
            'success': False, 
            'title': 'Error', 
            'message': 'Unable to process captcha. Please try again.'
        })

@app.route('/api/get-task-center-data', methods=['POST'])
def get_task_center_data():
    """Get task center data for a user including stats and task availability"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID is required'})
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get user balance and stats
        cursor.execute("""
            SELECT balance, referrals, created_at 
            FROM users 
            WHERE user_id = ?
        """, (user_id,))
        user_data = cursor.fetchone()
        
        if not user_data:
            conn.close()
            return jsonify({'success': False, 'message': 'User not found'})
        
        balance, referrals, created_at = user_data
        
        # Get completed tasks count
        cursor.execute("""
            SELECT COUNT(*) 
            FROM transactions 
            WHERE user_id = ? AND type IN ('daily_reward', 'shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward')
        """, (user_id,))
        completed_tasks = cursor.fetchone()[0]
        
        # Get total earned
        cursor.execute("""
            SELECT COALESCE(SUM(amount), 0) 
            FROM transactions 
            WHERE user_id = ? AND type IN ('daily_reward', 'shortlink_reward', 'math_reward', 'watch_ads_reward', 'captcha_reward')
        """, (user_id,))
        total_earned = cursor.fetchone()[0]
        
        # Get reward amounts from settings
        cursor.execute("SELECT value FROM settings WHERE key = 'daily_reward_amount'")
        daily_reward = float(cursor.fetchone()[0]) if cursor.fetchone() else 0.0724
        
        cursor.execute("SELECT value FROM settings WHERE key = 'shortlink_reward_amount'")
        shortlink_reward = float(cursor.fetchone()[0]) if cursor.fetchone() else 0.0724
        
        cursor.execute("SELECT value FROM settings WHERE key = 'math_reward_amount'")
        math_reward = float(cursor.fetchone()[0]) if cursor.fetchone() else 0.0671
        
        cursor.execute("SELECT value FROM settings WHERE key = 'watch_ads_reward_amount'")
        watch_ads_reward = float(cursor.fetchone()[0]) if cursor.fetchone() else 0.0724
        
        cursor.execute("SELECT value FROM settings WHERE key = 'captcha_reward_amount'")
        captcha_reward = float(cursor.fetchone()[0]) if cursor.fetchone() else 0.0671
        
        # Check task availability (simplified - you can add actual cooldown logic)
        # For now, we'll assume all tasks are available
        daily_available = True
        shortlink_available = True
        math_available = True
        watch_ads_available = True
        captcha_available = True
        
        # Calculate daily streak (simplified)
        daily_streak = 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'balance': balance,
            'completed_tasks': completed_tasks,
            'total_earned': total_earned,
            'daily_streak': daily_streak,
            'referrals': referrals,
            'daily_reward': daily_reward,
            'shortlink_reward': shortlink_reward,
            'math_reward': math_reward,
            'watch_ads_reward': watch_ads_reward,
            'captcha_reward': captcha_reward,
            'daily_available': daily_available,
            'shortlink_available': shortlink_available,
            'math_available': math_available,
            'watch_ads_available': watch_ads_available,
            'captcha_available': captcha_available
        })
        
    except Exception as e:
        print(f"Error in get_task_center_data: {e}")
        return jsonify({'success': False, 'message': str(e)})

# Task Center API Endpoints
@app.route('/api/get-user-balance', methods=['GET'])
def get_user_balance():
    """Get user balance and taskcenter balance"""
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user_result = cursor.fetchone()
        bot_balance = user_result[0] if user_result else 0
        
        cursor.execute("SELECT balance FROM taskcenter_balance WHERE user_id = ?", (user_id,))
        taskcenter_result = cursor.fetchone()
        taskcenter_balance = taskcenter_result[0] if taskcenter_result else 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'balance': bot_balance,
            'taskcenter_balance': taskcenter_balance
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/transfer-taskcenter-balance', methods=['POST'])
def transfer_taskcenter_balance():
    """Transfer taskcenter balance to main bot balance with 1/10,000 conversion rate"""
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        amount_to_transfer = data.get('amount')
        
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        if not amount_to_transfer or amount_to_transfer < 100:
            return jsonify({'success': False, 'message': 'Minimum transfer amount is ₱100'})
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT balance FROM taskcenter_balance WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result or result[0] <= 0:
            conn.close()
            return jsonify({'success': False, 'message': 'No balance to transfer'})
        
        current_taskcenter_balance = result[0]
        
        # Check if user has enough balance
        if amount_to_transfer > current_taskcenter_balance:
            conn.close()
            return jsonify({'success': False, 'message': 'Insufficient Task Center balance'})
        
        # Convert the specified amount to bot balance by dividing by 10,000
        bot_balance_to_add = amount_to_transfer / 10000
        
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (bot_balance_to_add, user_id))
        cursor.execute("UPDATE taskcenter_balance SET balance = balance - ? WHERE user_id = ?", (amount_to_transfer, user_id))
        cursor.execute("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)", 
                      (user_id, 'taskcenter_transfer', bot_balance_to_add, f'Transferred from Task Center (₱{int(amount_to_transfer)} ÷ 10,000)'))
        
        conn.commit()
        conn.close()
        
        # Send notification to user via Telegram bot
        try:
            import requests
            import os
            bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
            
            if bot_token:
                message = f"✅ Transfer Successful!\n\n" \
                         f"Task Center Balance Transferred: ₱{int(amount_to_transfer)}\n" \
                         f"Converted to Bot Balance: ₱{bot_balance_to_add:.4f}\n" \
                         f"(₱{int(amount_to_transfer)} ÷ 10,000)\n\n" \
                         f"Your balance is now available in the bot!"
                
                url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                data_telegram = {
                    'chat_id': user_id,
                    'text': message
                }
                requests.post(url, data=data_telegram, timeout=10)
        except Exception as e:
            # Don't fail the transfer if notification fails
            print(f"Failed to send notification: {e}")
        
        return jsonify({
            'success': True, 
            'amount': bot_balance_to_add,
            'original_amount': amount_to_transfer,
            'converted_amount': bot_balance_to_add
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/tasks', methods=['GET'])
def get_custom_tasks():
    """Get all active custom tasks - excludes completed tasks from display"""
    try:
        user_id = request.args.get('user_id', '')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, title, description, url, reward, icon, cooldown_hours, steps, category FROM custom_tasks WHERE is_active = 1 ORDER BY created_at DESC")
        tasks = cursor.fetchall()
        
        import json
        from datetime import datetime, timedelta
        
        tasks_list = []
        for task in tasks:
            task_id = task[0]
            steps_raw = task[7] if len(task) > 7 else ''
            category = task[8] if len(task) > 8 else 'General'
            
            # Skip completed tasks - check both user_id and IP address
            if user_id:
                # Get user's IP address (prioritize Cloudflare header)
                user_ip = request.headers.get('CF-Connecting-IP') or request.headers.get('X-Forwarded-For', request.remote_addr)
                if user_ip and ',' in user_ip:
                    user_ip = user_ip.split(',')[0].strip()
                
                # Check if task was completed by this user OR this IP address
                # Note: ip_address IS NOT NULL ensures we only block when IP is known
                cursor.execute("""
                    SELECT completed_at FROM task_completions 
                    WHERE task_id = ? AND (
                        user_id = ? OR 
                        (ip_address = ? AND ip_address IS NOT NULL)
                    )
                    ORDER BY completed_at DESC LIMIT 1
                """, (task_id, user_id, user_ip))
                completion = cursor.fetchone()
                
                if completion:
                    # Task already completed, check if cooldown has passed
                    completed_at = datetime.fromisoformat(completion[0])
                    cooldown_hours = task[6]
                    next_available = completed_at + timedelta(hours=cooldown_hours)
                    
                    if datetime.now() < next_available:
                        # Still on cooldown, skip this task (don't show it)
                        continue
            
            # Parse JSON steps if available
            steps_parsed = []
            if steps_raw:
                try:
                    steps_parsed = json.loads(steps_raw)
                except:
                    # If not JSON, treat as plain text (legacy support)
                    steps_parsed = []
            
            task_data = {
                'id': task_id,
                'title': task[1],
                'description': task[2],
                'url': task[3],
                'reward': task[4],
                'icon': task[5],
                'cooldown_hours': task[6],
                'steps': steps_parsed,
                'category': category,
                'can_claim': True
            }
            
            tasks_list.append(task_data)
        
        conn.close()
        
        return jsonify({'success': True, 'tasks': tasks_list})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/claim-task-reward', methods=['POST'])
def claim_task_reward():
    """Claim reward for completing a custom task - with IP-based abuse prevention"""
    conn = None
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        task_id = data.get('task_id')
        
        if not user_id or not task_id:
            return jsonify({'success': False, 'message': 'Missing parameters'})
        
        # Get user's IP address (prioritize Cloudflare header)
        user_ip = request.headers.get('CF-Connecting-IP') or request.headers.get('X-Forwarded-For', request.remote_addr)
        if user_ip and ',' in user_ip:
            user_ip = user_ip.split(',')[0].strip()
        
        from datetime import datetime, timedelta
        conn = get_db()
        cursor = conn.cursor()
        
        # Start transaction with immediate locking to prevent race conditions
        conn.execute("BEGIN IMMEDIATE")
        
        cursor.execute("SELECT reward, cooldown_hours FROM custom_tasks WHERE id = ? AND is_active = 1", (task_id,))
        task = cursor.fetchone()
        
        if not task:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'message': 'Task not found or inactive'})
        
        reward = task[0]
        cooldown_hours = task[1]
        
        # Check last completion by BOTH user_id AND ip_address to prevent multi-account abuse
        # Note: ip_address IS NOT NULL ensures we only block when IP is known
        cursor.execute("""
            SELECT completed_at, user_id, ip_address FROM task_completions 
            WHERE task_id = ? AND (
                user_id = ? OR 
                (ip_address = ? AND ip_address IS NOT NULL)
            )
            ORDER BY completed_at DESC LIMIT 1
        """, (task_id, user_id, user_ip))
        last_completion = cursor.fetchone()
        
        # Enforce cooldown
        if last_completion:
            completed_at = datetime.fromisoformat(last_completion[0])
            next_available = completed_at + timedelta(hours=cooldown_hours)
            
            if datetime.now() < next_available:
                conn.rollback()
                conn.close()
                remaining_seconds = int((next_available - datetime.now()).total_seconds())
                remaining_hours = remaining_seconds // 3600
                remaining_minutes = (remaining_seconds % 3600) // 60
                
                # Different message if IP was already used
                if last_completion[2] == user_ip and last_completion[1] != user_id:
                    return jsonify({
                        'success': False, 
                        'message': 'This task was already completed from your network. Please try again later.'
                    })
                
                return jsonify({
                    'success': False, 
                    'message': f'Task on cooldown. Available in {remaining_hours}h {remaining_minutes}m'
                })
        
        # Ensure taskcenter_balance exists
        cursor.execute("INSERT OR IGNORE INTO taskcenter_balance (user_id, balance, total_earned) VALUES (?, 0, 0)", (user_id,))
        
        # Update balance atomically
        cursor.execute("""
            UPDATE taskcenter_balance 
            SET balance = balance + ?, total_earned = total_earned + ? 
            WHERE user_id = ?
        """, (reward, reward, user_id))
        
        # Record completion using INSERT OR REPLACE to update cooldown timestamp
        # The UNIQUE(user_id, task_id) constraint prevents concurrent duplicate claims
        # Store IP address to prevent multi-account abuse
        current_time = datetime.now().isoformat()
        
        cursor.execute("""
            INSERT OR REPLACE INTO task_completions (user_id, task_id, reward_claimed, completed_at, ip_address) 
            VALUES (?, ?, ?, ?, ?)
        """, (user_id, task_id, reward, current_time, user_ip))
        
        # Log transaction
        cursor.execute("""
            INSERT INTO transactions (user_id, type, amount, description) 
            VALUES (?, ?, ?, ?)
        """, (user_id, 'task_reward', reward, f'Completed custom task #{task_id}'))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'reward': reward})
        
    except Exception as e:
        if conn:
            try:
                conn.rollback()
                conn.close()
            except:
                pass
        print(f"Error claiming task reward: {e}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again.'})

@app.route('/api/get-taskcenter-reward-amount', methods=['GET'])
def get_taskcenter_reward_amount():
    """Get reward amount for taskcenter ads"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ad_reward'")
        result = cursor.fetchone()
        conn.close()
        
        reward = float(result[0]) if result else 0.05
        return jsonify({'success': True, 'amount': reward})
    except Exception as e:
        return jsonify({'success': False, 'amount': 0.05})

@app.route('/api/get-taskcenter-ads-progress', methods=['GET'])
def get_taskcenter_ads_progress():
    """Get user's taskcenter ad watching progress for today"""
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        from datetime import datetime
        today = datetime.now().strftime('%Y-%m-%d')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ads_limit'")
        limit_result = cursor.fetchone()
        limit = int(limit_result[0]) if limit_result else 10
        
        cursor.execute("SELECT ads_watched FROM taskcenter_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        ads_watched = result[0] if result else 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'ads_watched': ads_watched,
            'limit': limit,
            'remaining': max(0, limit - ads_watched)
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/claim-taskcenter-ad-reward', methods=['POST'])
def claim_taskcenter_ad_reward():
    """Claim reward for watching ad in task center"""
    conn = None
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        from datetime import datetime
        today = datetime.now().strftime('%Y-%m-%d')
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Start transaction with immediate locking
        conn.execute("BEGIN IMMEDIATE")
        
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ads_limit'")
        limit_result = cursor.fetchone()
        limit = int(limit_result[0]) if limit_result else 10
        
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ad_reward'")
        reward_result = cursor.fetchone()
        reward = float(reward_result[0]) if reward_result else 0.05
        
        cursor.execute("SELECT ads_watched, last_watched FROM taskcenter_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        ads_watched = result[0] if result else 0
        last_watched = result[1] if result and result[1] else None
        
        # Check 2-minute cooldown
        if last_watched:
            try:
                last_watch_time = datetime.fromisoformat(last_watched)
                time_since_last = (datetime.now() - last_watch_time).total_seconds()
                cooldown_seconds = 120  # 2 minutes
                
                if time_since_last < cooldown_seconds:
                    remaining = int(cooldown_seconds - time_since_last)
                    conn.rollback()
                    conn.close()
                    return jsonify({
                        'success': False, 
                        'message': f'Please wait {remaining} seconds before watching another ad',
                        'on_cooldown': True,
                        'remaining_seconds': remaining
                    })
            except:
                pass
        
        # Check daily limit
        if ads_watched >= limit:
            conn.rollback()
            conn.close()
            return jsonify({'success': False, 'message': f'Daily ad limit reached ({limit}/{limit})'})
        
        # Update or insert ad watch record
        if result:
            cursor.execute("""
                UPDATE taskcenter_ads 
                SET ads_watched = ads_watched + 1, last_watched = ? 
                WHERE user_id = ? AND date = ?
            """, (datetime.now().isoformat(), user_id, today))
        else:
            cursor.execute("""
                INSERT INTO taskcenter_ads (user_id, ads_watched, last_watched, date) 
                VALUES (?, 1, ?, ?)
            """, (user_id, datetime.now().isoformat(), today))
        
        # Ensure taskcenter_balance exists
        cursor.execute("INSERT OR IGNORE INTO taskcenter_balance (user_id, balance, total_earned) VALUES (?, 0, 0)", (user_id,))
        
        # Update balance atomically
        cursor.execute("""
            UPDATE taskcenter_balance 
            SET balance = balance + ?, total_earned = total_earned + ? 
            WHERE user_id = ?
        """, (reward, reward, user_id))
        
        # Log transaction
        cursor.execute("""
            INSERT INTO transactions (user_id, type, amount, description) 
            VALUES (?, ?, ?, ?)
        """, (user_id, 'taskcenter_ad', reward, 'Watched ad in Task Center'))
        
        # Get updated balance
        cursor.execute("SELECT balance FROM taskcenter_balance WHERE user_id = ?", (user_id,))
        balance_result = cursor.fetchone()
        new_balance = balance_result[0] if balance_result else 0
        
        conn.commit()
        conn.close()
        
        new_count = ads_watched + 1
        return jsonify({
            'success': True, 
            'reward': reward,
            'balance': new_balance,
            'ads_watched': new_count,
            'remaining': limit - new_count
        })
        
    except Exception as e:
        if conn:
            conn.rollback()
            conn.close()
        print(f"Error claiming taskcenter ad reward: {e}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again.'})

@app.route('/api/check-taskcenter-cooldown', methods=['GET'])
def check_taskcenter_cooldown():
    """Check if user can watch taskcenter ads"""
    try:
        user_id = request.args.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID required'})
        
        from datetime import datetime
        today = datetime.now().strftime('%Y-%m-%d')
        
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute("SELECT value FROM settings WHERE key = 'taskcenter_ads_limit'")
        limit_result = cursor.fetchone()
        limit = int(limit_result[0]) if limit_result else 10
        
        cursor.execute("SELECT ads_watched, last_watched FROM taskcenter_ads WHERE user_id = ? AND date = ?", (user_id, today))
        result = cursor.fetchone()
        
        ads_watched = result[0] if result else 0
        last_watched = result[1] if result and result[1] else None
        
        # Check 2-minute cooldown
        on_cooldown = False
        remaining_seconds = 0
        
        if last_watched:
            try:
                last_watch_time = datetime.fromisoformat(last_watched)
                time_since_last = (datetime.now() - last_watch_time).total_seconds()
                cooldown_seconds = 120  # 2 minutes
                
                if time_since_last < cooldown_seconds:
                    on_cooldown = True
                    remaining_seconds = int(cooldown_seconds - time_since_last)
            except:
                pass
        
        can_watch = ads_watched < limit and not on_cooldown
        
        conn.close()
        
        return jsonify({
            'success': True,
            'can_watch': can_watch,
            'ads_watched': ads_watched,
            'limit': limit,
            'on_cooldown': on_cooldown,
            'remaining_seconds': remaining_seconds
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f"Starting web server on port {port}")
    app.run(host='0.0.0.0', port=port, debug=False)