import subprocess

import sys

import os

import time

import signal

import platform

import requests

import shutil

import re

import threading

def kill_existing_processes():

    """Kill any existing bot or web processes"""

    try:

        os.system("pkill -f 'greatgain.py'")

        os.system("pkill -f 'admin_web.py'")

        time.sleep(2)

    except Exception as e:

        print(f"Note: {e}")

def run_script(script_name, port=None):

    """Run a Python script in a separate process."""

    env = os.environ.copy()

    if port:

        env['PORT'] = str(port)

    return subprocess.Popen([sys.executable, os.path.join('greatgainbot', script_name)], env=env)

def get_download_url():

    system = platform.system().lower()

    arch = platform.machine().lower()

    if system == "windows":

        filename = "cloudflared-windows-amd64.exe"

    elif system == "linux":

        filename = "cloudflared-linux-arm64" if "aarch64" in arch or "arm64" in arch else "cloudflared-linux-amd64"

    elif system == "darwin":

        filename = "cloudflared-darwin-amd64"

    else:

        raise Exception("Unsupported system")

    url = f"https://github.com/cloudflare/cloudflared/releases/latest/download/{filename}"

    return url, filename

def download_binary():

    url, filename = get_download_url()

    out_path = os.path.join("cloudflared_bin", "cloudflared" + (".exe" if filename.endswith(".exe") else ""))

    if os.path.exists(out_path):

        print(f"Cloudflared binary already exists at {out_path}")

        return out_path

    print(f"Downloading cloudflared from: {url}")

    r = requests.get(url, stream=True)

    if r.status_code != 200:

        raise Exception("Failed to download cloudflared")

    os.makedirs("cloudflared_bin", exist_ok=True)

    with open(out_path, "wb") as f:

        shutil.copyfileobj(r.raw, f)

    os.chmod(out_path, 0o755)

    print(f"Downloaded cloudflared binary to {out_path}")

    return out_path

def start_cloudflare_tunnel(cloudflared_path):

    print("Starting Cloudflare tunnel...")

    return subprocess.Popen(

        [cloudflared_path, "tunnel", "--config", ".cloudflared/config.yml", "run"],

        stdout=subprocess.PIPE,

        stderr=subprocess.STDOUT,

        text=True

    )

def print_tunnel_url(tunnel_process):

    """Monitors cloudflared output and prints public URL."""

    url_printed = False

    for line in tunnel_process.stdout:

        print(line, end="")

        if not url_printed and "dpdns.org" in line:

            match = re.search(r"https://[a-z0-9\-\.]*dpdns\.org", line)

            if match:

                time.sleep(1)

                print(f"\n🌐 Tunnel URL: {match.group()}\n")

                url_printed = True

        elif not url_printed and "greatgain.dpdns.org" in line.lower():

            print(f"\n🌐 Tunnel URL: https://greatgain.dpdns.org\n")

            url_printed = True

if __name__ == "__main__":

    LOCAL_PORT = 6021
   


    print("Initializing GreatGain Bot system...")

    kill_existing_processes()

    cloudflared_path = download_binary()

    print(f"Starting Admin Web Interface on port {LOCAL_PORT}...")

    web_process = run_script("admin_web.py", LOCAL_PORT)

    time.sleep(3)

    print("Starting Telegram bot...")

    bot_process = run_script("greatgain.py")

    tunnel_process = start_cloudflare_tunnel(cloudflared_path)

    threading.Thread(target=print_tunnel_url, args=(tunnel_process,), daemon=True).start()

    print("\n" + "=" * 50)

    print("🎉 GreatGain Bot System Started Successfully!")

    print("=" * 50)

    print("📱 Telegram Bot: Active")

    print(f"🌐 Web Admin: http://localhost:{LOCAL_PORT}/@dminpanel")

    print("🎁 Reward Page: Available at /reward")

    print("🌐 Cloudflare Tunnel: Starting... (Check logs below)")

    print("=" * 50)

    def signal_handler(signum, frame):

        print("\n\nShutting down GreatGain Bot system...")

        for p in [bot_process, web_process, tunnel_process]:

            try:

                p.terminate()

                p.wait(timeout=5)

            except Exception:

                p.kill()

        print("System shutdown complete.")

        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    signal.signal(signal.SIGTERM, signal_handler)

    try:

        while True:

            time.sleep(10)

            if bot_process.poll() is not None:

                print("⚠️ Telegram bot stopped unexpectedly. Restarting...")

                bot_process = run_script("greatgain.py")

            if web_process.poll() is not None:

                print("⚠️ Web server stopped unexpectedly. Restarting...")

                web_process = run_script("admin_web.py", LOCAL_PORT)

            if tunnel_process.poll() is not None:

                print("⚠️ Cloudflare tunnel stopped unexpectedly. Restarting...")

                tunnel_process = start_cloudflare_tunnel(cloudflared_path)

                threading.Thread(target=print_tunnel_url, args=(tunnel_process,), daemon=True).start()

    except KeyboardInterrupt:

        signal_handler(signal.SIGINT, None)